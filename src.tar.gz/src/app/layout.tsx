import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import Script from "next/script";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});


export const metadata: Metadata = {
  title: "NexusCut - Next-Gen AI Video Editor for Creators",
  description: "Create stunning videos with AI. Explore templates, tools, and the ultimate editor for TikTok, Shorts, and Reels.",
  openGraph: {
    title: "NexusCut - Next-Gen AI Video Editor",
    description: "Create stunning videos with AI. The best editor for TikTok, Shorts, and Reels.",
    url: "https://nexuscut.io",
    siteName: "NexusCut",
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "NexusCut - Next-Gen AI Video Editor",
    description: "Create stunning videos with AI. The best editor for TikTok, Shorts, and Reels.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "NexusCut",
  "operatingSystem": "WebBrowser",
  "applicationCategory": "MultimediaApplication",
  "offers": {
    "@type": "Offer",
    "price": "0",
    "priceCurrency": "USD"
  },
  "description": "Next-Gen AI Video Editor for vertical short-form content."
};

import { Suspense } from 'react';
import AffiliateTracker from '@/components/AffiliateTracker';

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
      suppressHydrationWarning
    >
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&family=Montserrat:wght@400;700;900&family=Oswald:wght@400;700&family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Roboto:wght@400;700;900&display=swap" rel="stylesheet" />
        <Script
          id="schema-org"
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        {/* Google tag (gtag.js) */}
        <Script 
          src="https://www.googletagmanager.com/gtag/js?id=G-1BZZ7X8ZH8" 
          strategy="afterInteractive" 
        />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-1BZZ7X8ZH8');
          `}
        </Script>
      </head>
      <body className="min-h-full flex flex-col bg-neutral-950 text-white" suppressHydrationWarning>
        <Suspense fallback={null}>
          <AffiliateTracker />
        </Suspense>
        <main className="flex-1">
          {children}
        </main>
      </body>
    </html>
  );
}
