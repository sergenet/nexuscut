import { MetadataRoute } from 'next';
import { blogPosts } from '@/lib/blogData';
import { academyLessons } from '@/lib/academyData';

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://nexuscut.io'; // Replace with real domain

  const staticRoutes = [
    '',
    '/editor',
    '/pricing',
    '/marketplace',
    '/affiliates',
    '/templates',
    '/brand',
    '/brand-kit',
    '/labs',
    '/compare/nexuscut-vs-nexusclips',
    '/tutorial',
    '/help',
    '/blog',
    '/academy',
    '/instagram-reels-editor',
    '/tiktok-video-editor',
    '/youtube-shorts-editor',
    '/products/desktop',
    '/products/mobile',
    '/products/online',
    '/products/pad',
    '/terms',
    '/privacy',
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: 'weekly' as any,
    priority: route === '' ? 1 : 0.8,
  }));

  const toolRoutes = [
    '/tools/ai-image-generator',
    '/tools/animated-subtitles',
    '/tools/audio-studio',
    '/tools/auto-captions',
    '/tools/nexus-animate',
    '/tools/nexus-dream',
    '/tools/remove-background',
    '/tools/subtitle-style-generator',
    '/tools/tiktok-caption-generator',
    '/tools/video-effects',
    '/tools/viral-hook-generator',
    '/tools/youtube-shorts-maker',
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: 'monthly' as any,
    priority: 0.8,
  }));

  const blogRoutes = blogPosts.map((post) => ({
    url: `${baseUrl}/blog/${post.slug}`,
    lastModified: new Date(post.date),
    changeFrequency: 'monthly' as any,
    priority: 0.7,
  }));

  const academyRoutes = academyLessons.map((lesson) => ({
    url: `${baseUrl}/academy/${lesson.slug}`,
    lastModified: new Date(),
    changeFrequency: 'monthly' as any,
    priority: 0.7,
  }));

  return [...staticRoutes, ...toolRoutes, ...blogRoutes, ...academyRoutes];
}
