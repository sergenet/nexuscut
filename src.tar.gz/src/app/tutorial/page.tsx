import React from 'react';
import Link from 'next/link';
import { ArrowLeft, BookOpen, Sparkles, Scissors, Wand2, Type, Music, Download } from 'lucide-react';

export default function TutorialPage() {
  return (
    <div className="min-h-screen bg-black text-neutral-300 font-sans">
      {/* Navbar */}
      <nav className="h-16 bg-neutral-950 border-b border-neutral-800 flex items-center px-8 sticky top-0 z-50">
        <Link href="/editor" className="flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors font-medium">
          <ArrowLeft className="w-5 h-5" />
          Back to Editor
        </Link>
        <div className="mx-auto flex items-center gap-3">
          <BookOpen className="w-6 h-6 text-white" />
          <h1 className="text-xl font-bold text-white tracking-tight">NexusCut Editor Guide</h1>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        <header className="mb-16 text-center">
          <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-6 tracking-tight">
            Master the <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-purple-500">NexusCut</span> Editor
          </h2>
          <p className="text-xl text-neutral-400">
            Learn how to turn raw clips into viral masterpieces using our powerful AI-driven tools.
          </p>
        </header>

        <div className="space-y-16">
          
          {/* Section 1: The Workspace */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 md:p-10 shadow-2xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-xl">
                <Scissors className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-white">1. Understanding the Workspace</h3>
            </div>
            <div className="space-y-4 text-lg text-neutral-300">
              <p>The editor is split into four main areas designed to give you complete control without the clutter:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Sidebar (Left):</strong> Your toolkit. Here you'll find your Media Library, AI Magic tools, Text, Audio, Transitions, and Effects.</li>
                <li><strong>Canvas (Center):</strong> The preview window. Drag videos to reposition them, use the corners to resize, and watch your edits in real-time.</li>
                <li><strong>Properties Panel (Right):</strong> Context-sensitive controls. Select any clip or text on the timeline to adjust its specific settings like opacity, font, volume, or transition durations.</li>
                <li><strong>Timeline (Bottom):</strong> The heart of your project. Layer your videos, audio, and text here. Drag clips to move them, and drag their edges to trim.</li>
              </ul>
            </div>
          </section>

          {/* Section 2: AI Magic & Growth Mode */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 md:p-10 shadow-2xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-xl">
                <Sparkles className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-white">2. Growth Mode & AI Magic</h3>
            </div>
            <div className="space-y-4 text-lg text-neutral-300">
              <p>We built NexusCut specifically for content creators. Instead of spending hours doing manual edits, use our AI tools:</p>
              <ul className="list-disc pl-6 space-y-3">
                <li>
                  <strong className="text-white">Growth Mode:</strong> Click the "Growth Mode" button at the top right of the editor. This powerful wizard analyzes your video and automatically applies trending caption styles (like Hormozi or MrBeast), sound effects, and B-roll to maximize viewer retention.
                </li>
                <li>
                  <strong className="text-white">Auto-Captions:</strong> Found in the "AI Magic" sidebar tab. Let our speech-to-text engine generate highly accurate captions for your video with a single click.
                </li>
                <li>
                  <strong className="text-white">Remove Background:</strong> Don't have a green screen? No problem. The AI Background Removal tool perfectly extracts you from your background so you can overlay yourself on gameplay or reaction footage.
                </li>
              </ul>
            </div>
          </section>

          {/* Section 3: Text & Styles */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 md:p-10 shadow-2xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-rose-500/20 text-rose-400 rounded-xl">
                <Type className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-white">3. Text and Captions</h3>
            </div>
            <div className="space-y-4 text-lg text-neutral-300">
              <p>Engaging text is the key to short-form content. Here is how to use it:</p>
              <ol className="list-decimal pl-6 space-y-2">
                <li>Open the <strong>Text</strong> tab in the sidebar.</li>
                <li>Click <strong>Add Title</strong> or choose one of our viral presets (Hormozi, MrBeast, Ali Abdaal).</li>
                <li>A text segment will appear on your timeline. Select it.</li>
                <li>Look at the <strong>Properties Panel</strong> on the right. Here you can edit the actual text, change fonts, adjust colors, and resize it.</li>
                <li>Drag the text directly on the Canvas to position it exactly where you want it.</li>
              </ol>
            </div>
          </section>

          {/* Section 4: AI Voice & Audio Generation (TTS) */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 md:p-10 shadow-2xl">
            <div className="flex items-center gap-4 mb-6">
               <div className="p-3 bg-blue-500/20 text-blue-400 rounded-xl">
                 <Music className="w-8 h-8" />
               </div>
               <h3 className="text-2xl font-bold text-white">4. AI Voice Generation (TTS)</h3>
            </div>
            <div className="space-y-4 text-lg text-neutral-300">
               <p>Give your videos a professional narrator without stepping into a recording booth. Our AI Voice (Text-to-Speech) tool is incredibly realistic.</p>
               <ol className="list-decimal pl-6 space-y-2">
                 <li>Open the <strong>Audio</strong> tab in the left sidebar.</li>
                 <li>Locate the <strong>AI Voice Generator (TTS)</strong> section.</li>
                 <li>Type your script into the text box.</li>
                 <li>Select your preferred voice actor from the dropdown menu (try "Adam" for a deep, cinematic voice or "Rachel" for an energetic tone).</li>
                 <li>Click <strong>Generate Voice</strong>.</li>
                 <li>An audio segment will be added directly to your timeline. You can click and drag it to align perfectly with your visuals.</li>
               </ol>
            </div>
          </section>

          {/* Section 5: Transitions & Effects */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 md:p-10 shadow-2xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-purple-500/20 text-purple-400 rounded-xl">
                <Wand2 className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-white">5. Transitions & Effects</h3>
            </div>
            <div className="space-y-4 text-lg text-neutral-300">
              <p>Keep your audience engaged by adding dynamic transitions between your clips.</p>
              <p>In the <strong>Transitions</strong> tab, you can drag and drop transitions directly onto a video clip in your timeline, or click the transition icon between clips. When you apply a transition, a <strong>Transition Audio FX (Whoosh)</strong> will automatically be added to the Audio FX track perfectly timed with the visual cut!</p>
              <p>The <strong>Effects</strong> tab includes visual modifiers like Glitch, VHS, and Blur. Drag them to the timeline to apply them over specific sections of your video.</p>
            </div>
          </section>

          {/* Section 6: Aspect Ratios & Exporting */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 md:p-10 shadow-2xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-blue-500/20 text-blue-400 rounded-xl">
                <Scissors className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-white">6. Aspect Ratios & Exporting</h3>
            </div>
            <div className="space-y-4 text-lg text-neutral-300">
              <p>Before you export, make sure your video is shaped correctly for your target platform.</p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Aspect Ratio Selector:</strong> In the top navigation bar, select your desired shape: <strong>9:16</strong> (TikTok/Reels), <strong>16:9</strong> (YouTube Desktop), or <strong>1:1</strong> (Instagram Post). The canvas preview will adjust instantly.</li>
                <li><strong>Manual Caption Placement:</strong> Did you know you can customize every single caption? Select a caption in the timeline, then use the Properties Panel to tweak its font, color, size, and X/Y position. Those changes are burned into the final export via Advanced SubStation Alpha (.ass) subtitles!</li>
              </ul>
            </div>
          </section>

          {/* Section 7: Audio */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 md:p-10 shadow-2xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
                <Music className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-white">7. Audio & Sound Effects</h3>
            </div>
            <div className="space-y-4 text-lg text-neutral-300">
              <p>Audio is half the experience. Control it with precision:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Upload your own music via the Media Library, or explore our built-in <strong>Audio</strong> tab for trending SFX like whooshes, pops, and risers.</li>
                <li><strong>AI Voice (TTS):</strong> Located inside the <strong>Audio</strong> tab on the left sidebar, simply type your script, pick a voice (like Alloy or Echo), and hit Generate to instantly add a realistic AI voiceover to your timeline.</li>
                <li>Select any clip (video or audio) on the timeline to reveal the volume slider in the Properties panel.</li>
                <li>Use the volume slider to create a perfect mix, or mute a video clip entirely to just use its visuals.</li>
              </ul>
            </div>
          </section>

          {/* Section 7: Exporting */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 md:p-10 shadow-2xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-xl">
                <Download className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-white">7. Exporting Your Video</h3>
            </div>
            <div className="space-y-4 text-lg text-neutral-300">
              <p>Once your masterpiece is ready, it's time to share it with the world.</p>
              <p>Click the <strong>Export Video</strong> button at the top right of the editor. NexusCut's high-performance cloud engine will render your video with all transitions, captions, and effects applied. The file will automatically download to your computer as a high-quality MP4 once rendering is complete.</p>
            </div>
          </section>

        </div>

        {/* Q&A Section */}
        <div className="mt-24">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">Frequently Asked Questions</h2>
          <div className="space-y-6">
            
            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6">
              <h4 className="text-xl font-bold text-white mb-2">Q: Why won't my video export?</h4>
              <p className="text-neutral-400">
                A: Ensure that you have at least one video clip in the main "Video" track. Our cloud rendering engine requires a base video track to compile the final file.
              </p>
            </div>

            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6">
              <h4 className="text-xl font-bold text-white mb-2">Q: How do I save my progress?</h4>
              <p className="text-neutral-400">
                A: You can save your project locally at any time by clicking "Save Local" in the top bar. This downloads a small project file. Next time you open NexusCut, simply click "Load Local" and upload that file to restore your timeline!
              </p>
            </div>

            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6">
              <h4 className="text-xl font-bold text-white mb-2">Q: Are my files deleted when I leave the editor?</h4>
              <p className="text-neutral-400">
                A: Your media library is cached locally in your browser to make editing incredibly fast. However, we highly recommend using the "Save Local" feature to ensure your timeline placement isn't lost if your browser clears its cache.
              </p>
            </div>

            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6">
              <h4 className="text-xl font-bold text-white mb-2">Q: Can I change the color of the Auto-Captions?</h4>
              <p className="text-neutral-400">
                A: Yes! Select the caption track on your timeline, and then look at the Properties panel on the right side of the screen. You can change the font, size, and color of all captions simultaneously.
              </p>
            </div>

          </div>
        </div>

        <div className="mt-16 text-center pb-20">
          <Link href="/editor" className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-white text-black font-bold text-lg hover:bg-neutral-200 transition-colors shadow-lg">
            Start Editing Now
          </Link>
        </div>

      </main>
    </div>
  );
}
