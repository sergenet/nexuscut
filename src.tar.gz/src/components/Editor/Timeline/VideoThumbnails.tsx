import React, { useEffect, useState } from 'react';

interface VideoThumbnailsProps {
  src: string;
  duration: number;
  width: number;
}

export default function VideoThumbnails({ src, duration, width }: VideoThumbnailsProps) {
  const [thumbnails, setThumbnails] = useState<string[]>([]);
  
  useEffect(() => {
    let active = true;
    if (!src) return;
    
    // Calculate how many thumbnails we need (e.g. 1 per 50 pixels)
    const numThumbnails = Math.max(1, Math.floor(width / 50));
    
    const video = document.createElement('video');
    video.src = src;
    video.muted = true;
    video.playsInline = true;
    video.crossOrigin = 'anonymous';
    
    video.onloadeddata = async () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      // Calculate scaled dimensions for the thumbnail
      const aspect = video.videoWidth / video.videoHeight || 16/9;
      canvas.width = 60;
      canvas.height = 60 / aspect;
      
      const newThumbnails: string[] = [];
      const interval = duration / numThumbnails;
      
      for (let i = 0; i < numThumbnails; i++) {
        if (!active) break;
        // Seek to the time interval, +0.1 to avoid pure black first frame usually at 0.0s
        video.currentTime = Math.min(i * interval + 0.1, duration - 0.1);
        
        await new Promise(resolve => {
           video.onseeked = resolve;
           video.onerror = resolve;
        });
        
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        newThumbnails.push(canvas.toDataURL('image/jpeg', 0.5));
      }
      
      if (active) {
        setThumbnails(newThumbnails);
      }
    };
    
    return () => {
      active = false;
      video.src = ''; // Clear video source
    };
  }, [src, duration, width]);
  
  return (
    <div className="absolute inset-0 flex overflow-hidden pointer-events-none rounded-md bg-neutral-900">
      {thumbnails.map((t, i) => (
        <img key={i} src={t} alt="" className="h-full object-cover flex-1 min-w-0" />
      ))}
    </div>
  );
}
