"use client";

import React, { useRef, useEffect, useState } from 'react';
import { DndContext, DragEndEvent, useSensor, useSensors, PointerSensor, closestCorners } from '@dnd-kit/core';
import { useEditorStore } from '@/store/useEditorStore';
import TrackRow from './TrackRow';
import { Play, ZoomIn, ZoomOut, Scissors, Trash, Maximize, Plus } from 'lucide-react';

export default function Timeline() {
  const { 
    tracks, 
    moveSegment, 
    currentTime, 
    setCurrentTime, 
    videoDuration, 
    zoomLevel, 
    setZoomLevel,
    selectedSegmentId,
    removeSegment,
    addSegment,
    setIsPlaying,
    transitionModalOpen,
    transitionModalType,
    transitionTargetSegmentId,
    setTransitionModalOpen,
    setTransitionModalType,
    setTransitionTargetSegmentId
  } = useEditorStore();

  const timelineRef = useRef<HTMLDivElement>(null);
  const isPanning = useRef(false);
  const panStartX = useRef(0);
  const panScrollLeftStart = useRef(0);
  
  const [dragOverTime, setDragOverTime] = useState<number | null>(null);
  
  // Setup DndKit sensors for drag and drop
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 5, // Start dragging after moving 5px
      },
    })
  );

  // Auto-scroll timeline to keep playhead in view
  useEffect(() => {
    if (timelineRef.current) {
      const container = timelineRef.current;
      const playheadX = currentTime * zoomLevel + 192; // 192 is track header width
      const scrollLeft = container.scrollLeft;
      const containerWidth = container.clientWidth;
      
      const isPlayingState = useEditorStore.getState().isPlaying;

      // If playing, we want to smoothly scroll as it approaches the right edge.
      // If paused, we only jump if the playhead is completely off-screen (like clicking "Back to beginning")
      if (isPlayingState) {
        if (playheadX > scrollLeft + containerWidth - 50) {
          container.scrollLeft = playheadX - containerWidth + 50;
        } else if (playheadX < scrollLeft + 192) {
          container.scrollLeft = Math.max(0, playheadX - 192);
        }
      } else {
        // When paused, only scroll if playhead is totally invisible
        if (playheadX > scrollLeft + containerWidth || playheadX < scrollLeft + 192) {
          container.scrollLeft = Math.max(0, playheadX - (containerWidth / 2)); // Center it
        }
      }
    }
  }, [currentTime, zoomLevel]);

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over, delta } = event;

    if (over && active.data.current && over.data.current) {
      const segment = active.data.current.segment;
      const targetTrack = over.data.current.track;
      
      // Calculate new start time based on pixel movement and zoom level
      let newStart = Math.max(0, segment.start + (delta.x / zoomLevel));
      
      // Snap to beginning if within ~15px
      const snapThreshold = 15 / zoomLevel;
      const startSnapThreshold = 20 / zoomLevel; // Slight magnetic pull for 00.00
      let snapped = false;
      
      if (newStart < startSnapThreshold) {
        newStart = 0;
        snapped = true;
      } else {
        // Snap to edges of other segments in the target track
        for (const s of targetTrack.segments) {
          if (s.id === segment.id) continue;
          if (Math.abs(newStart - s.end) < snapThreshold) {
            newStart = s.end;
            snapped = true;
            break;
          }
          if (Math.abs(newStart - s.start) < snapThreshold) {
            newStart = s.start;
            snapped = true;
            break;
          }
        }
      }

      // If the user holds Alt, detach the clip and move it independently
      const activatorEvent = event.activatorEvent as MouseEvent | KeyboardEvent | PointerEvent;
      const moveLinked = !activatorEvent.altKey;

      moveSegment(segment.id, segment.trackId, targetTrack.id, newStart, moveLinked);
    }
  };

  const isScrubbing = useRef(false);

  const updateScrubPosition = (e: React.PointerEvent<HTMLDivElement> | React.MouseEvent<HTMLDivElement>) => {
    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const scrollLeft = timelineRef.current.scrollLeft;
    const x = e.clientX - rect.left + scrollLeft - 192; // 192px is the track header width
    
    if (x >= -50) { // Allow slight negative pull to ensure they can snap to 0
      let newTime = Math.max(0, Math.min(x / zoomLevel, videoDuration));
      
      // Magnetic snap to 00.00 for playhead if within 10px
      if (x < 10) {
        newTime = 0;
      }
      
      setCurrentTime(newTime);
    }
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    isScrubbing.current = true;
    updateScrubPosition(e);
    setIsPlaying(false); // Pause when starting to scrub
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isScrubbing.current) return;
    updateScrubPosition(e);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    isScrubbing.current = false;
  };

  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Handled by pointer down/move/up for smooth scrubbing
  };

  const handleDelete = () => {
    if (selectedSegmentId) {
      // Find the track containing this segment
      const track = tracks.find(t => t.segments.some(s => s.id === selectedSegmentId));
      if (track && !track.isLocked) {
        removeSegment(track.id, selectedSegmentId);
      }
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
        handleDelete();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedSegmentId, tracks, removeSegment]);

  const handleSplit = () => {
    let targetSegment = null;
    let targetTrack = null;

    if (selectedSegmentId) {
      targetTrack = tracks.find(t => t.segments.some(s => s.id === selectedSegmentId));
      if (targetTrack) {
        targetSegment = targetTrack.segments.find(s => s.id === selectedSegmentId);
        
        // If the playhead is outside the selected segment, ignore the selection!
        if (targetSegment && (currentTime <= targetSegment.start || currentTime >= targetSegment.end)) {
          targetSegment = undefined;
        }
      }
    } 
    
    if (!targetSegment) {
      // If nothing valid is selected, find any segment under the playhead on the video track
      targetTrack = tracks.find(t => t.id === 'video-1');
      if (targetTrack) {
        targetSegment = targetTrack.segments.find(s => currentTime > s.start && currentTime < s.end);
      }
    }

    if (targetSegment && targetTrack && !targetTrack.isLocked && currentTime > targetSegment.start && currentTime < targetSegment.end) {
      const duration1 = currentTime - targetSegment.start;
      const duration2 = targetSegment.end - currentTime;
      const originalSourceStart = targetSegment.sourceStart || 0;
      
      removeSegment(targetTrack.id, targetSegment.id);
      
      const newId1 = Math.random().toString(36).substr(2, 9);
      
      addSegment(targetTrack.id, {
        ...targetSegment,
        id: newId1,
        start: targetSegment.start,
        end: currentTime,
        duration: duration1,
        sourceStart: originalSourceStart,
        transitionOut: undefined
      });
      
      const newId2 = Math.random().toString(36).substr(2, 9);
      
      addSegment(targetTrack.id, {
        ...targetSegment,
        id: newId2,
        start: currentTime,
        end: targetSegment.end,
        duration: duration2,
        sourceStart: originalSourceStart + duration1
      });
      
      // Auto-select the newly created left segment
      useEditorStore.getState().selectSegment(newId1);
    }
  };
  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';

    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const scrollLeft = timelineRef.current.scrollLeft;
    const x = e.clientX - rect.left + scrollLeft - 192; // 192px is track header
    const hoverTime = Math.max(0, x / zoomLevel);

    const isTransition = Array.from(e.dataTransfer.types).some(t => t.toLowerCase().includes('transition'));

    if (isTransition) {
      const videoTrack = tracks.find(t => t.id === 'video-1');
      if (videoTrack && videoTrack.segments.length > 0) {
        let minDist = Infinity;
        let targetTime = null;
        
        videoTrack.segments.forEach(seg => {
          const distToEnd = Math.abs(hoverTime - seg.end);
          if (distToEnd < minDist) {
            minDist = distToEnd;
            targetTime = seg.end;
          }
        });
        
        if (targetTime !== null) {
          setDragOverTime(targetTime);
        }
      }
    } else {
      // For Audio FX, Text, Media, show the indicator directly at the mouse position
      setDragOverTime(hoverTime);
    }
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    setDragOverTime(null);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOverTime(null);
    
    let data = e.dataTransfer.getData('application/json');
    if (!data) data = e.dataTransfer.getData('text/plain');
    
    let item: any = null;
    if (data) {
      try { item = JSON.parse(data); } catch(err) {}
    }
    
    if (!item) {
      // Ultimate fallback: scan types
      const types = Array.from(e.dataTransfer.types);
      const isTrans = types.some(t => t.toLowerCase().includes('nexuscut-type-transition'));
      if (isTrans) {
        const nameType = types.find(t => t.toLowerCase().includes('nexuscut-name-'));
        const name = nameType ? nameType.split('nexuscut-name-')[1].replace(/-/g, ' ') : 'Cross Dissolve';
        item = { type: 'transition', name };
      }
    }
    
    if (!item) return;

    try {
      if (!timelineRef.current) return;

      const rect = timelineRef.current.getBoundingClientRect();
      const scrollLeft = timelineRef.current.scrollLeft;
      const x = e.clientX - rect.left + scrollLeft - 192; // 192px is track header
      const dropTime = Math.max(0, x / zoomLevel);
      
      if (item.type === 'transition') {
        const videoTrack = tracks.find(t => t.id === 'video-1');
        if (!videoTrack || videoTrack.segments.length === 0) {
          alert("You must have video clips on the timeline to add a transition!");
          return;
        }

        // Find the closest segment end to apply the transition to
        let closestSeg = videoTrack.segments[0];
        let minDist = Infinity;
        
        videoTrack.segments.forEach(seg => {
          const distToEnd = Math.abs(dropTime - seg.end);
          if (distToEnd < minDist) {
            minDist = distToEnd;
            closestSeg = seg;
          }
        });

        // Open the modal to configure duration
        setTransitionTargetSegmentId(closestSeg.id);
        setTransitionModalType(item.name);
        setTransitionModalOpen(true);
        return;
      }

      let trackId = 'video-1';
      if (item.type === 'media') {
        trackId = item.item.type === 'video' ? 'video-1' : item.item.type === 'audio' ? 'audio-1' : 'video-1';
      } else if (item.type === 'audio') {
        trackId = 'audio-1';
      } else if (item.type === 'effect') {
        trackId = 'effect-1';
      } else if (item.type === 'text') {
        trackId = 'text-1';
      }
      
      // Reduced magnetic snap to 15 pixels
      const snapThreshold = 15 / zoomLevel;
      
      // If the target track is empty AND it's the main video track, ALWAYS snap to 0 to save time
      const targetTrack = tracks.find(t => t.id === trackId);
      const isTrackEmpty = !targetTrack || targetTrack.segments.length === 0;
      
      let finalDropTime = dropTime;
      if ((isTrackEmpty && trackId === 'video-1') || dropTime < snapThreshold) {
        finalDropTime = 0;
      } else if (targetTrack) {
        // Snap to edges of other segments in the track
        for (const s of targetTrack.segments) {
          if (Math.abs(dropTime - s.end) < snapThreshold) {
            finalDropTime = s.end;
            break;
          }
          if (Math.abs(dropTime - s.start) < snapThreshold) {
            finalDropTime = s.start;
            break;
          }
        }
      }

      let duration = item.duration || 10;
      if (item.type === 'media') {
        duration = item.item.duration || 10;
      } else if (item.type === 'effect') {
        duration = item.duration || 2;
      }

      // Prevent overlapping by snapping to the end of the track if there's a collision (ONLY FOR VIDEO)
      if (targetTrack && trackId === 'video-1') {
        const isOverlapping = targetTrack.segments.some(s => 
          (finalDropTime >= s.start && finalDropTime < s.end) || 
          (finalDropTime + duration > s.start && finalDropTime + duration <= s.end) ||
          (finalDropTime <= s.start && finalDropTime + duration >= s.end)
        );
        
        if (isOverlapping) {
          const trackEnd = targetTrack.segments.reduce((max, s) => Math.max(max, s.end), 0);
          finalDropTime = trackEnd;
        }
      }

      if (item.type === 'media') {
        addSegment(trackId, {
          id: Math.random().toString(36).substr(2, 9),
          trackId: trackId,
          start: finalDropTime,
          end: finalDropTime + duration,
          duration: duration,
          type: item.item.type as any,
          src: item.item.url,
          name: item.item.name
        });
      } else {
        addSegment(trackId, {
          id: Math.random().toString(36).substr(2, 9),
          trackId: trackId,
          start: finalDropTime,
          end: finalDropTime + duration,
          duration: duration,
          type: item.type as any,
          src: item.url,
          name: item.name
        });
      }

      // Auto-fit if this is the very first clip being dropped onto the timeline
      const isFirstClip = !tracks.some(t => t.segments.length > 0);
      if (isFirstClip && timelineRef.current && duration > 0) {
        const visibleWidth = timelineRef.current.clientWidth - 192; // 192px is track header
        const desiredZoom = (visibleWidth * 0.9) / duration;
        // Clamp to the same 10-300 bounds used by the zoom slider
        const finalZoom = Math.min(300, Math.max(10, desiredZoom));
        useEditorStore.getState().setZoomLevel(finalZoom);
      }

    } catch (err) {
      console.error("Drop error", err);
    }
  };

  const handleTrimExtras = () => {
    // Find the end time of the last video segment
    const videoTrack = tracks.find(t => t.id === 'video-1');
    if (!videoTrack || videoTrack.segments.length === 0) return;
    const videoEnd = Math.max(...videoTrack.segments.map(s => s.end));
    
    // Remove all text and audio segments that start at or after the video end
    tracks.forEach(track => {
      if (track.id === 'video-1') return; // Don't touch video track
      track.segments.forEach(seg => {
        if (seg.start >= videoEnd) {
          removeSegment(track.id, seg.id);
        }
      });
    });
  };

  // Check if there are any segments past the video end (for button state)
  const videoTrack = tracks.find(t => t.id === 'video-1');
  const videoEnd = videoTrack ? Math.max(0, ...videoTrack.segments.map(s => s.end)) : 0;
  const hasExtras = tracks.some(t => t.id !== 'video-1' && t.segments.some(s => s.start >= videoEnd)) && videoEnd > 0;

  return (
    <div className="flex flex-col h-full bg-neutral-950 border-t border-neutral-800">
      
      {/* Timeline Toolbar */}
      <div className="h-12 bg-neutral-900 border-b border-neutral-800 flex items-center justify-between px-4 cursor-default">
        <div className="flex items-center gap-2">
          <button 
            onClick={handleSplit}
            className="px-3 py-1.5 flex items-center gap-2 text-sm font-medium text-neutral-400 hover:text-white hover:bg-neutral-800 rounded transition-colors" 
            title="Split Clip at Playhead"
          >
            <Scissors className="w-4 h-4" /> Split
          </button>
          <button 
            onClick={handleDelete}
            disabled={!selectedSegmentId}
            className={`px-3 py-1.5 flex items-center gap-2 text-sm font-medium rounded transition-colors ${selectedSegmentId ? 'text-neutral-400 hover:text-rose-500 hover:bg-neutral-800' : 'text-neutral-500 cursor-not-allowed'}`} 
            title="Delete Selected"
          >
            <Trash className="w-4 h-4" /> Delete
          </button>
          {hasExtras && (
            <button 
              onClick={handleTrimExtras}
              className="px-3 py-1.5 flex items-center gap-2 text-sm font-medium text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 rounded transition-colors border border-amber-500/30" 
              title="Remove all captions and audio FX that extend past the end of the video"
            >
              <Scissors className="w-4 h-4" /> Trim Extras
            </button>
          )}
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => {
              if (timelineRef.current && videoDuration > 0) {
                const availableWidth = timelineRef.current.clientWidth - 192 - 100;
                const targetZoom = availableWidth / videoDuration;
                setZoomLevel(Math.max(10, Math.min(300, targetZoom)));
              }
            }}
            className="text-xs font-bold px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-md transition-colors flex items-center gap-1.5"
          >
            <Maximize className="w-3.5 h-3.5" /> Fit
          </button>

          <div className="flex items-center gap-2 bg-black/40 rounded-lg p-1 border border-neutral-800">
            <button 
              onClick={() => setZoomLevel(Math.max(10, zoomLevel - 10))}
              className="p-1 text-neutral-400 hover:text-white rounded transition-colors"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <div className="w-32 h-1 bg-neutral-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-indigo-500" 
                style={{ width: `${(zoomLevel / 300) * 100}%` }}
              />
            </div>
            <button 
              onClick={() => setZoomLevel(Math.min(300, zoomLevel + 10))}
              className="p-1 text-neutral-400 hover:text-white rounded transition-colors"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>


      {/* Tracks Container */}
      <div 
        ref={timelineRef}
        className="flex-1 overflow-auto relative custom-scrollbar select-none cursor-ew-resize"
        onClick={handleTimelineClick}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onDragEnter={handleDragEnter}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div 
          className="relative min-w-full"
          style={{ width: `max(100%, ${videoDuration * zoomLevel + 192 + 100}px)` }} // 192 for header + 100px padding
        >
          
          {/* Time Ruler */}
          <div className="h-6 flex border-b border-neutral-800 bg-neutral-900 sticky top-0 z-40 shadow-sm">
            <div className="w-48 flex-shrink-0 bg-neutral-900 border-r border-neutral-800 sticky left-0 z-50 shadow-[4px_0_12px_rgba(0,0,0,0.5)]" />
            <div className="flex-1 relative overflow-hidden pointer-events-none">
              {/* Render ruler ticks */}
              {[...Array(Math.ceil(videoDuration) + 1)].map((_, i) => (
                <div 
                  key={i} 
                  className="absolute bottom-0 border-l border-neutral-700"
                  style={{ left: `${i * zoomLevel}px`, height: i % 5 === 0 ? '10px' : '5px' }}
                >
                  {i % 5 === 0 && (
                    <span className="absolute -top-4 -left-2 text-[10px] text-neutral-500 font-mono">
                      00:{i.toString().padStart(2, '0')}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>

          <DndContext sensors={sensors} collisionDetection={closestCorners} onDragEnd={handleDragEnd}>
            {/* Tracks List */}
            <div className="relative pb-8">
              {tracks.map((track) => (
                <TrackRow key={track.id} track={track} />
              ))}
              
              {/* Transition Drop Indicator */}
              {dragOverTime !== null && (
                <div 
                  className="absolute top-0 bottom-0 w-1 bg-amber-400 z-50 animate-pulse pointer-events-none"
                  style={{ 
                    left: `${dragOverTime * zoomLevel + 192 - 2}px`, 
                    boxShadow: '0 0 15px 4px rgba(251, 191, 36, 0.6)'
                  }}
                />
              )}
              
              {/* Add Track Button */}
              <div className="pl-4 pt-4 sticky left-0 w-48 z-10">
                <button 
                  onClick={() => {
                    const audioTracks = tracks.filter(t => t.type === 'audio').length;
                    useEditorStore.getState().addTrack({
                      id: `audio-${Math.random().toString(36).substr(2, 9)}`,
                      type: 'audio',
                      name: `Audio Track ${audioTracks + 1}`,
                      segments: []
                    });
                  }}
                  className="w-full py-2 border border-dashed border-neutral-700 hover:border-indigo-500 rounded-lg text-xs font-bold text-neutral-400 hover:text-indigo-400 bg-neutral-900 hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2 shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Audio Track
                </button>
              </div>

              {/* Playhead Cursor */}
              <div 
                className="absolute top-0 bottom-0 w-0 border-l-2 border-rose-500 z-50 pointer-events-none"
                style={{ left: `${(currentTime * zoomLevel) + 192}px` }}
              >
                <div className="absolute -top-3 -left-[5px] w-0 h-0 border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-t-[6px] border-t-rose-500" />
                <div className="absolute -top-[18px] -left-[1.5px] w-[3px] h-[6px] bg-rose-500" />
              </div>
            </div>
          </DndContext>
          
        </div>
      </div>

    </div>
  );
}
