"use client";

import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Wand2, Scissors, Music, Layers, Type, Image as ImageIcon, FileAudio, X, Shuffle, Type as TypeIcon, Camera, Video } from 'lucide-react';
import { useEditorStore, MediaItem } from '@/store/useEditorStore';
import { get, set } from 'idb-keyval';
import CaptionEditorModal from './CaptionEditorModal';
import CameraRecorderModal from './CameraRecorderModal';

const TABS = [
  { id: 'media', icon: ImageIcon, label: 'Media' },
  { id: 'magic', icon: Sparkles, label: 'AI Magic' },
  { id: 'text', icon: Type, label: 'Text' },
  { id: 'audio', icon: Music, label: 'Audio' },
  { id: 'transitions', icon: Shuffle, label: 'Trans' },
  { id: 'effects', icon: Wand2, label: 'Effects' },
];

export default function Sidebar() {
  const [activeTab, setActiveTab] = useState('media');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progressText, setProgressText] = useState('');
  const [ttsText, setTtsText] = useState('');
  const [ttsVoice, setTtsVoice] = useState('alloy');
  const [isGeneratingTts, setIsGeneratingTts] = useState(false);
  const [isCaptionEditorOpen, setIsCaptionEditorOpen] = useState(false);
  const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { mediaLibrary, addMediaItem, removeMediaItem, addSegment, setMediaLibrary, tracks, currentTime, selectSegment, transcriptionText, setTranscriptionText } = useEditorStore();

  useEffect(() => {
    get('nexuscut-media').then((files: MediaItem[] | undefined) => {
      if (files && files.length > 0) {
        const hydratedFiles = files.map(item => {
          if (item.file) return { ...item, url: URL.createObjectURL(item.file) };
          return item;
        });
        setMediaLibrary(hydratedFiles);
      }
    }).catch(err => console.error('Failed to load media from IDB', err));
  }, [setMediaLibrary]);

  const processFile = (file: File, explicitDuration?: number) => {
    const url = URL.createObjectURL(file);
    const type = file.type.startsWith('video') ? 'video' : file.type.startsWith('audio') ? 'audio' : 'image';
    
    const finishImport = (duration: number) => {
      const newItem: MediaItem = {
        id: Math.random().toString(36).substr(2, 9),
        url,
        type,
        name: file.name,
        file: file,
        duration: duration
      };

      addMediaItem(newItem);
      const state = useEditorStore.getState();
      const updatedLibrary = state.mediaLibrary;
      set('nexuscut-media', updatedLibrary).catch(err => console.error('Failed to save to IDB', err));
      
      // Auto-relink any broken segments in the timeline
      state.tracks.forEach(t => {
        state.updateAllSegments(
          t.id, 
          { src: url }, 
          (s) => s.name === file.name && (s.src?.startsWith('blob:') || !s.src)
        );
      });
    };

    if (type === 'video' || type === 'audio') {
      const media = document.createElement(type);
      media.src = url;
      media.onloadedmetadata = () => {
        let dur = explicitDuration || media.duration;
        if (!dur || dur === Infinity || isNaN(dur)) {
            dur = 10;
        }
        finishImport(dur);
      };
    } else {
      finishImport(5);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    processFile(file);
  };

  const handleCameraRecordFinish = (file: File, durationSecs: number) => {
    processFile(file, durationSecs);
  };

  const handleMediaClick = (item: MediaItem) => {
    const duration = item.duration || 10;
    
    const state = useEditorStore.getState();
    const isFirstClip = !state.tracks.some(t => t.segments.length > 0);
    
    addSegment('video-1', {
      id: Math.random().toString(36).substr(2, 9),
      trackId: 'video-1',
      start: 0,
      end: duration,
      duration: duration,
      type: item.type as any,
      src: item.url,
      name: item.name
    });
    
    if (isFirstClip && duration > 0) {
      // Assuming a standard screen width since we don't have direct access to timelineRef here
      const visibleWidth = window.innerWidth - 300 - 300 - 192; // Screen minus sidebars minus track headers
      const safeWidth = Math.max(500, visibleWidth); // Fallback if calculation fails
      const desiredZoom = (safeWidth * 0.9) / duration;
      const finalZoom = Math.min(200, Math.max(2, desiredZoom));
      state.setZoomLevel(finalZoom);
    }
  };

  const handleDragStart = (e: React.DragEvent, data: any) => {
    const jsonStr = JSON.stringify(data);
    e.dataTransfer.setData('application/json', jsonStr);
    e.dataTransfer.setData('text/plain', jsonStr);
    e.dataTransfer.effectAllowed = 'copy';
    
    // Add custom type flag so timeline knows what we're dragging over it
    // Some browsers lowercase this, so we'll use lowercase
    e.dataTransfer.setData(`nexuscut-type-${data.type}`, 'true');
    if (data.name) {
      e.dataTransfer.setData(`nexuscut-name-${data.name.replace(/\s+/g, '-')}`, 'true');
    }
  };

  // AI Function implementations
  const handleSmartCut = async () => {
    const videoTrack = tracks.find(t => t.id === 'video-1');
    if (!videoTrack || videoTrack.segments.length === 0) return alert('Please add a video to the timeline first!');
    
    const firstSeg = videoTrack.segments[0];
    const mediaItem = mediaLibrary.find(m => m.url === firstSeg.src);
    if (!mediaItem || !mediaItem.file) return alert('Cannot find original file for this video segment.');

    setIsProcessing(true);
    setProgressText('Analyzing audio for silence...');
    
    try {
      const { fetchFile } = await import('@ffmpeg/util');
      const win = window as any;
      if (!win.sharedFfmpeg) {
        const { FFmpeg } = await import('@ffmpeg/ffmpeg');
        win.sharedFfmpeg = new FFmpeg();
        const { toBlobURL } = await import('@ffmpeg/util');
        const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
        await win.sharedFfmpeg.load({
          coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
          wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
        });
      }
      const ffmpeg = win.sharedFfmpeg;

      await ffmpeg.writeFile('input.mp4', await fetchFile(mediaItem.file));
      
      let silenceStarts: number[] = [];
      let silenceEnds: number[] = [];
      
      ffmpeg.on('log', ({ message }: { message: string }) => {
        const lines = message.split('\n');
        for (const line of lines) {
          if (line.includes('silence_start: ')) {
            const start = parseFloat(line.split('silence_start: ')[1]);
            if (!isNaN(start)) silenceStarts.push(start);
          }
          if (line.includes('silence_end: ')) {
            const endStr = line.split('silence_end: ')[1].split(' ')[0];
            const end = parseFloat(endStr);
            if (!isNaN(end)) silenceEnds.push(end);
          }
        }
      });
      
      await ffmpeg.exec(['-i', 'input.mp4', '-af', `silencedetect=noise=-40dB:d=0.5`, '-f', 'null', '-']);
      
      const sourceStart = firstSeg.sourceStart || 0;
      const sourceEnd = sourceStart + firstSeg.duration;
      
      let newSegments: {start: number, end: number}[] = [];
      let currentPos = sourceStart;
      
      for (let i = 0; i < silenceStarts.length; i++) {
        const sStart = silenceStarts[i];
        let sEnd = silenceEnds[i];
        
        // If a silence_start occurs at the end of the video but never ends, close it at sourceEnd
        if (sEnd === undefined) {
          sEnd = sourceEnd;
        }
        
        if (sEnd <= sourceStart) continue;
        if (sStart >= sourceEnd) break;
        
        const effectiveSilenceStart = Math.max(sStart, sourceStart);
        const effectiveSilenceEnd = Math.min(sEnd, sourceEnd);
        
        if (effectiveSilenceStart > currentPos) {
          newSegments.push({ start: currentPos, end: effectiveSilenceStart });
        }
        currentPos = effectiveSilenceEnd;
      }

      if (currentPos < sourceEnd) {
        newSegments.push({ start: currentPos, end: sourceEnd });
      }
      
      if (newSegments.length === 0) newSegments = [{ start: sourceStart, end: sourceEnd }];
      
      useEditorStore.getState().removeSegment('video-1', firstSeg.id);
      
      let timelineCursor = firstSeg.start;
      for (const seg of newSegments) {
        const dur = seg.end - seg.start;
        useEditorStore.getState().addSegment('video-1', {
          ...firstSeg,
          id: Math.random().toString(36).substr(2, 9),
          start: timelineCursor,
          end: timelineCursor + dur,
          duration: dur,
          sourceStart: seg.start,
        });
        timelineCursor += dur;
      }
      
    } catch(err) {
      console.error(err);
      alert("Silence removal failed.");
    } finally {
      setIsProcessing(false);
      setProgressText("");
    }
  };

  const handleAutoCaptions = async () => {
    const videoTrack = tracks.find(t => t.id === 'video-1');
    if (!videoTrack || videoTrack.segments.length === 0) return alert('Please add a video to the timeline first!');
    const firstSeg = videoTrack.segments[0];
    const mediaItem = mediaLibrary.find(m => m.url === firstSeg.src);
    if (!mediaItem || !mediaItem.file) return alert('Cannot find original file.');

    setIsProcessing(true);
    setProgressText('Uploading and transcribing...');

    try {
      const formData = new FormData();
      formData.append('file', mediaItem.file);
      const res = await fetch('/api/backend-transcribe', { 
        method: 'POST', 
        body: formData
      });
      const data = await res.json();
      
      if (data.error) throw new Error(data.error);

      if (data.transcription && data.transcription.words) {
        const state = useEditorStore.getState();
        
        state.setTranscriptionText(data.transcription.text);

        // Remove existing auto-captions to prevent overlapping duplicates
        const textTrack = state.tracks.find(t => t.id === 'text-1');
        if (textTrack) {
          state.removeAllCaptions('text-1');
        }

        let firstCaptionId: string | null = null;
        
        // Map the words to the actual timeline segments
        data.transcription.words.forEach((word: any, i: number) => {
          // The transcription API returns timestamps relative to the original media file.
          // We need to find which timeline segment this word falls into.
          const wordOriginalStart = word.start;
          const wordOriginalEnd = word.end;
          
          // Find all segments from this source file
          const sourceSegments = state.tracks.find(t => t.id === 'video-1')?.segments.filter(s => s.src === firstSeg.src) || [];
          
          sourceSegments.forEach(seg => {
            const segSourceStart = seg.sourceStart || 0;
            const segSourceEnd = segSourceStart + seg.duration;
            
            // Check if the word overlaps with this segment's source window
            if (wordOriginalStart < segSourceEnd && wordOriginalEnd > segSourceStart) {
              const clipStartInSource = Math.max(wordOriginalStart, segSourceStart);
              const clipEndInSource = Math.min(wordOriginalEnd, segSourceEnd);
              
              const timelineStart = seg.start + (clipStartInSource - segSourceStart);
              const timelineEnd = seg.start + (clipEndInSource - segSourceStart);
              
              if (timelineEnd > timelineStart) {
                const newId = Math.random().toString(36).substr(2, 9);
                if (!firstCaptionId) firstCaptionId = newId;
                state.addSegment('text-1', {
                  id: newId,
                  trackId: 'text-1',
                  start: timelineStart,
                  end: timelineEnd,
                  duration: timelineEnd - timelineStart,
                  type: 'text',
                  name: 'Caption',
                  text: word.word,
                  src: firstSeg.src, // Link caption to the original video source
                  color: '#FFD700',
                  fontSize: 48,
                  y: 80
                });
              }
            }
          });
        });
        
        if (firstCaptionId) {
          state.selectSegment(firstCaptionId);
        }
      }
    } catch (err: any) {
      console.error(err);
      alert(`Error generating captions: ${err.message}`);
    } finally {
      setIsProcessing(false);
      setProgressText("");
    }
  };

  const handleBRoll = async () => {
    setIsProcessing(true);
    setProgressText('AI is fetching B-Roll clips...');
    try {
      const state = useEditorStore.getState();
      const textTrack = state.tracks.find(t => t.id === 'text-1');
      const captions = textTrack?.segments.filter(s => s.name === 'Caption').map(s => ({
        word: s.text,
        start: s.start,
        end: s.end
      })) || [];

      if (captions.length === 0) {
        alert("Please generate Auto Captions first so the AI knows what B-Roll to fetch!");
        return;
      }

      const res = await fetch('/api/b-roll', {
        method: 'POST', 
        headers: { 'Content-Type': 'application/json' }, 
        body: JSON.stringify({ captions })
      });
      
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      if (data.segments && data.segments.length > 0) {
        data.segments.forEach((seg: any) => {
          if (seg.videoUrl) {
            useEditorStore.getState().addSegment('video-1', {
              id: Math.random().toString(36).substr(2, 9),
              trackId: 'video-1',
              start: seg.start,
              end: seg.end,
              duration: seg.end - seg.start,
              type: 'video',
              name: `B-Roll: ${seg.query}`,
              src: seg.videoUrl
            });
          }
        });
      } else {
        alert("No suitable B-Roll moments found for this script.");
      }
    } catch (err: any) {
      console.error(err);
      alert(`B-Roll Error: ${err.message}`);
    } finally {
      setIsProcessing(false);
      setProgressText("");
    }
  };

  return (
    <div className="w-72 bg-neutral-900 border-r border-neutral-800 flex flex-col h-full rounded-l-2xl overflow-hidden shadow-2xl">
      
      {/* Top Nav */}
      <div className="h-16 flex border-b border-neutral-800 bg-neutral-950 px-2 items-center gap-1 overflow-x-auto custom-scrollbar">
        {TABS.map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-shrink-0 w-14 h-12 flex flex-col items-center justify-center rounded-lg transition-colors ${
              activeTab === tab.id 
                ? 'bg-indigo-600/20 text-indigo-400' 
                : 'text-neutral-500 hover:text-neutral-300 hover:bg-white/5'
            }`}
          >
            <tab.icon className="w-5 h-5 mb-1" />
            <span className="text-[9px] font-bold uppercase tracking-wider">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Progress Overlay */}
      {isProcessing && (
        <div className="absolute inset-0 z-50 bg-black/80 flex flex-col items-center justify-center p-4 text-center">
          <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-white font-bold">{progressText}</p>
        </div>
      )}

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
        {activeTab === 'media' && (
          <div className="space-y-4">
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="video/mp4,video/quicktime,video/webm,audio/*,image/*" 
              onChange={handleFileUpload}
            />
            <div className="flex gap-2 w-full">
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 p-3 border-2 border-dashed border-neutral-700 hover:border-indigo-500 rounded-xl flex flex-col items-center justify-center gap-1 text-neutral-300 hover:text-indigo-400 transition-colors bg-neutral-950/50"
              >
                <span className="text-xl font-bold leading-none">+</span>
                <span className="text-xs font-bold text-center">Import</span>
              </button>
              <button 
                onClick={() => setIsCameraModalOpen(true)}
                className="flex-1 p-3 border-2 border-dashed border-neutral-700 hover:border-indigo-500 rounded-xl flex flex-col items-center justify-center gap-1 text-neutral-300 hover:text-indigo-400 transition-colors bg-neutral-950/50"
              >
                <Camera className="w-5 h-5" />
                <span className="text-xs font-bold text-center">Camera</span>
              </button>
            </div>
            
            {mediaLibrary.length > 0 && (
              <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mt-6 mb-2">2. Drag to Timeline</h3>
            )}
            
            <div className="grid grid-cols-2 gap-3">
              {mediaLibrary.map((item) => (
                <div 
                  key={item.id} 
                  draggable
                  onDragStart={(e) => handleDragStart(e, { type: 'media', item })}
                  onClick={() => handleMediaClick(item)}
                  className="aspect-video bg-neutral-800 rounded-lg overflow-hidden relative group cursor-pointer border border-transparent hover:border-indigo-500 transition-colors"
                >
                  <div className="w-full h-full bg-neutral-900 border border-neutral-800 rounded-lg flex items-center justify-center overflow-hidden relative">
                    {item.type === 'video' ? (
                      <>
                        <video src={`${item.url}#t=0.1`} preload="metadata" className="w-full h-full object-cover pointer-events-none" />
                      </>
                    ) : item.type === 'image' ? (
                      <img src={item.url} className="w-full h-full object-cover pointer-events-none" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-neutral-800">
                        <FileAudio className="w-6 h-6 text-neutral-600" />
                      </div>
                    )}
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/40 transition-opacity">
                    <span className="text-xs text-white font-bold bg-indigo-600 px-2 py-1 rounded">Add</span>
                  </div>
                  <button 
                    onClick={(e) => { 
                      e.stopPropagation(); 
                      removeMediaItem(item.id); 
                      const updatedLibrary = useEditorStore.getState().mediaLibrary.filter(i => i.id !== item.id);
                      set('nexuscut-media', updatedLibrary).catch(err => console.error('Failed to update IDB', err));
                    }}
                    className="absolute top-1 right-1 p-1 bg-black/60 rounded text-neutral-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Delete Media"
                  >
                    <X className="w-3 h-3" />
                  </button>
                  <div className="absolute bottom-1 right-1 bg-black/60 px-1.5 py-0.5 rounded text-[10px] text-white font-mono truncate max-w-[80%] pointer-events-none">
                    {item.name}
                  </div>
                </div>
              ))}
              
              {mediaLibrary.length === 0 && (
                <div className="col-span-2 text-center text-xs text-neutral-600 py-4">
                  No media imported yet
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'magic' && (
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-4">AI Tools</h3>
            
            <button 
              onClick={handleSmartCut}
              className="w-full text-left p-4 bg-neutral-950 border border-neutral-800 hover:border-indigo-500 rounded-xl transition-colors group"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center text-indigo-400">
                  <Scissors className="w-4 h-4" />
                </div>
                <span className="font-bold text-white group-hover:text-indigo-400 transition-colors">Smart Cut</span>
              </div>
              <p className="text-xs text-neutral-500">Automatically remove silences and dead space.</p>
            </button>

            <button 
              onClick={handleAutoCaptions}
              className="w-full text-left p-4 bg-neutral-950 border border-neutral-800 hover:border-rose-500 rounded-xl transition-colors group"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-8 h-8 rounded-lg bg-rose-500/20 flex items-center justify-center text-rose-400">
                  <Type className="w-4 h-4" />
                </div>
                <span className="font-bold text-white group-hover:text-rose-400 transition-colors">Auto Captions</span>
              </div>
              <p className="text-xs text-neutral-500">Generate animated dynamic subtitles instantly.</p>
            </button>

            <button 
              onClick={handleBRoll}
              className="w-full text-left p-4 bg-neutral-950 border border-neutral-800 hover:border-emerald-500 rounded-xl transition-colors group"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <Layers className="w-4 h-4" />
                </div>
                <span className="font-bold text-white group-hover:text-emerald-400 transition-colors">B-Roll Generator</span>
              </div>
              <p className="text-xs text-neutral-500">Insert AI-generated stock footage over your script.</p>
            </button>

            {transcriptionText && (
              <div className="mt-4 p-4 bg-neutral-950 border border-neutral-800 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-2">
                    <FileAudio className="w-4 h-4 text-rose-400" />
                    Raw Transcription
                  </h3>
                </div>
                <textarea 
                  value={transcriptionText}
                  onChange={(e) => setTranscriptionText(e.target.value)}
                  className="w-full h-40 bg-black border border-neutral-800 rounded-lg p-3 text-white text-sm focus:border-rose-500 focus:outline-none resize-y transition-colors custom-scrollbar"
                  placeholder="Transcription text will appear here..."
                />
                <button 
                  onClick={() => {
                    const blob = new Blob([transcriptionText], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'transcription.txt';
                    a.click();
                  }}
                  className="w-full mt-2 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold rounded transition-colors"
                >
                  Download Transcript
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'transitions' && (
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-4">Transitions</h3>
            <div className="grid grid-cols-2 gap-3">
              {['Cross Dissolve', 'Dip to Black', 'Fade In', 'Wipe Right', 'Zoom Blur'].map((trans, i) => (
                <div 
                  key={i}
                  draggable
                  onDragStart={(e) => handleDragStart(e, { type: 'transition', name: trans })}
                  onClick={() => {
                    const videoTrack = tracks.find(t => t.id === 'video-1');
                    if (!videoTrack || videoTrack.segments.length === 0) return alert('Add a video segment to apply a transition to.');
                    // Apply to the first segment for demo purposes
                    const firstSeg = videoTrack.segments[0];
                    const transDur = 1;
                    useEditorStore.getState().updateSegment('video-1', firstSeg.id, { transitionOut: { type: trans, duration: transDur } });
                    
                    alert(`Transition "${trans}" applied!`);
                  }}
                  className="p-3 bg-neutral-800 rounded-lg cursor-grab active:cursor-grabbing border border-transparent hover:border-amber-500 text-center transition-colors"
                >
                  <Shuffle className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                  <span className="text-xs font-bold text-white">{trans}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'text' && (
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-4">Text & Titles</h3>
            <div className="grid grid-cols-3 gap-2">
              {(['Headline', 'Subtitle', 'Body Text'] as any[]).map((title, i) => (
                <button 
                  key={i}
                  onClick={() => {
                    const defaults = {
                      'Headline': { fontSize: 80, y: 30, text: 'NEW HEADLINE', fontFamily: 'Oswald', bold: true },
                      'Subtitle': { fontSize: 40, y: 50, text: 'Subtitle Text', fontFamily: 'Montserrat', bold: false },
                      'Body Text': { fontSize: 24, y: 70, text: 'Body text goes here...', fontFamily: 'Inter', bold: false }
                    };
                    const settings = (defaults as any)[title];
                    
                    const { addSegment, addTrack, tracks, currentTime, selectSegment } = useEditorStore.getState();
                    
                    const trackId = title === 'Headline' ? 'text-1' : title === 'Subtitle' ? 'text-2' : 'text-3';
                    const targetTrack = tracks.find(t => t.id === trackId);
                    
                    if (targetTrack) {
                      const existingSeg = targetTrack.segments.find(s => currentTime >= s.start && currentTime < s.end);
                      if (existingSeg) {
                        selectSegment(existingSeg.id);
                        return;
                      }
                    } else {
                      addTrack({ id: trackId, type: 'text', name: title, segments: [] });
                    }
                    
                    const newId = Math.random().toString(36).substr(2, 9);
                    addSegment(trackId, {
                      id: newId,
                      trackId: trackId,
                      start: currentTime,
                      end: currentTime + 5,
                      duration: 5,
                      type: 'text',
                      ...settings,
                      x: 50,
                    });
                    selectSegment(newId);
                  }}
                  className="w-full text-center p-3 bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors group flex flex-col items-center gap-1 border border-transparent hover:border-rose-500"
                >
                  <div className="w-8 h-8 bg-rose-500/20 rounded-full flex items-center justify-center text-rose-400 font-bold mb-1">
                    <TypeIcon className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-[10px] text-white group-hover:text-rose-400 transition-colors uppercase tracking-wider">{title}</span>
                </button>
              ))}
            </div>

            <button 
              onClick={() => setIsCaptionEditorOpen(true)}
              className="w-full mt-4 p-4 bg-neutral-950 border border-neutral-800 hover:border-indigo-500 rounded-xl transition-colors group text-left"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center text-indigo-400">
                  <TypeIcon className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white group-hover:text-indigo-400 transition-colors">Bulk Edit Captions</span>
                  <div className="text-[10px] text-amber-500 font-bold uppercase mt-1">PRO Feature</div>
                </div>
              </div>
              <p className="text-xs text-neutral-500">Review and edit all generated captions in a single spreadsheet view.</p>
            </button>
          </div>
        )}

        {activeTab === 'audio' && (
          <div className="space-y-6">
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Audio FX</h3>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { name: 'Whoosh', src: '/sounds/whoosh.wav', duration: 1.5 },
                  { name: 'Pop', src: '/sounds/pop.wav', duration: 0.5 },
                  { name: 'Ding', src: '/sounds/ding.wav', duration: 1 },
                  { name: 'Boom', src: '/sounds/boom.wav', duration: 2 },
                ].map((sfx, i) => (
                  <div 
                    key={i}
                    draggable
                    onDragStart={(e) => handleDragStart(e, { type: 'audio', name: sfx.name, url: sfx.src, duration: sfx.duration })}
                    onClick={() => {
                      addSegment('audio-1', {
                        id: Math.random().toString(36).substr(2, 9),
                        trackId: 'audio-1',
                        start: currentTime,
                        end: currentTime + sfx.duration,
                        duration: sfx.duration,
                        type: 'audio',
                        name: sfx.name,
                        src: sfx.src
                      });
                    }}
                    className="p-2 bg-neutral-800 rounded-lg cursor-grab active:cursor-grabbing border border-transparent hover:border-emerald-500 flex items-center gap-2 transition-colors"
                  >
                    <div className="w-6 h-6 bg-neutral-900 rounded flex items-center justify-center text-emerald-400"><Music className="w-3 h-3" /></div>
                    <span className="text-[10px] font-bold text-white">{sfx.name}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-3 border-t border-neutral-800 pt-4">
              <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider">AI Voice (TTS)</h3>
              <textarea 
                value={ttsText}
                onChange={(e) => setTtsText(e.target.value)}
                placeholder="Enter text for AI to speak..."
                className="w-full h-20 bg-black border border-neutral-800 rounded-lg p-2 text-white text-xs focus:border-indigo-500 focus:outline-none resize-none transition-colors"
              />
              <div className="flex items-center gap-2">
                <select 
                  value={ttsVoice}
                  onChange={(e) => setTtsVoice(e.target.value)}
                  className="flex-1 bg-black border border-neutral-800 rounded-lg p-2 text-white text-xs focus:border-indigo-500 outline-none"
                >
                  <option value="alloy">Alloy (Neutral)</option>
                  <option value="echo">Echo (Warm)</option>
                  <option value="fable">Fable (British)</option>
                  <option value="onyx">Onyx (Deep)</option>
                  <option value="nova">Nova (Bright)</option>
                  <option value="shimmer">Shimmer (Soft)</option>
                </select>
                <button 
                  disabled={isGeneratingTts || !ttsText}
                  onClick={async () => {
                    setIsGeneratingTts(true);
                    setProgressText('Generating Voice...');
                    try {
                      const res = await fetch('/api/tts', {
                        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: ttsText, voice: ttsVoice })
                      });
                      if (!res.ok) throw new Error("TTS generation failed");
                      const blob = await res.blob();
                      const url = URL.createObjectURL(blob);
                      
                      const audio = new Audio(url);
                      audio.onloadedmetadata = () => {
                        const duration = audio.duration || 5;
                        addSegment('audio-1', {
                          id: Math.random().toString(36).substr(2, 9),
                          trackId: 'audio-1',
                          start: currentTime,
                          end: currentTime + duration,
                          duration: duration,
                          type: 'audio',
                          name: `TTS (${ttsVoice})`,
                          src: url
                        });
                      };
                    } catch (err: any) {
                      alert("TTS failed: " + err.message);
                    } finally {
                      setIsGeneratingTts(false);
                      setProgressText('');
                    }
                  }}
                  className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white p-2 rounded-lg transition-colors flex items-center justify-center shrink-0"
                >
                  {isGeneratingTts ? <span className="text-xs font-bold px-2">Wait</span> : <Wand2 className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        )}

      </div>

      <CaptionEditorModal 
        isOpen={isCaptionEditorOpen} 
        onClose={() => setIsCaptionEditorOpen(false)} 
      />

      <CameraRecorderModal
        isOpen={isCameraModalOpen}
        onClose={() => setIsCameraModalOpen(false)}
        onRecordFinish={handleCameraRecordFinish}
      />
    </div>
  );
}
