import { create } from 'zustand';

export interface MediaItem {
  id: string;
  url: string;
  type: 'video' | 'audio' | 'image';
  name: string;
  file?: File;
  duration?: number;
}

export interface TrackSegment {
  id: string;
  trackId: string;
  start: number; // in seconds
  end: number; // in seconds
  duration: number; // in seconds
  type: 'video' | 'audio' | 'text' | 'effect' | 'transition';
  src?: string;
  text?: string;
  name?: string;
  sourceStart?: number; // the trim offset from the original media file
  // Visual properties
  x?: number; // 0-100 percentage
  y?: number; // 0-100 percentage
  scale?: number;
  opacity?: number;
  // Audio properties
  volume?: number;
  // Text specific
  color?: string;
  fontSize?: number;
  fontFamily?: string;
  bold?: boolean;
  italic?: boolean;
  textAlign?: 'left' | 'center' | 'right';
  letterSpacing?: number; // px
  lineHeight?: number; // multiplier
  textShadow?: boolean;
  shadowColor?: string;
  shadowBlur?: number;
  outlineWidth?: number;
  outlineColor?: string;
  // Effects/Transitions
  transitionOut?: { type: string; duration: number };
  style?: string; // e.g. 'hormozi' etc
}

export interface Track {
  id: string;
  type: 'video' | 'audio' | 'text' | 'effect';
  name: string;
  isHidden?: boolean;
  isLocked?: boolean;
  segments: TrackSegment[];
}

interface EditorState {
  // Playback state
  currentTime: number;
  isPlaying: boolean;
  videoDuration: number;
  
  // Timeline zoom
  zoomLevel: number; // Pixels per second
  
  // Transition Modal State
  transitionModalOpen: boolean;
  transitionModalType: string;
  transitionTargetSegmentId: string | null;

  setTransitionModalOpen: (isOpen: boolean) => void;
  setTransitionModalType: (type: string) => void;
  setTransitionTargetSegmentId: (id: string | null) => void;

  // Media Library
  mediaLibrary: MediaItem[];

  // Project data
  projectName: string;
  setProjectName: (name: string) => void;
  aspectRatio: '9:16' | '16:9' | '1:1';
  setAspectRatio: (ratio: '9:16' | '16:9' | '1:1') => void;

  // Tracks
  tracks: Track[];
  selectedSegmentId: string | null;

  // History
  past: Track[][];
  future: Track[][];
  saveHistory: () => void;
  undo: () => void;
  redo: () => void;
  setTracks: (tracks: Track[]) => void;

  // Transcription
  transcriptionText: string;
  setTranscriptionText: (text: string) => void;

  // Actions
  setCurrentTime: (time: number) => void;
  setIsPlaying: (isPlaying: boolean) => void;
  setVideoDuration: (duration: number) => void;
  setZoomLevel: (zoom: number) => void;
  addMediaItem: (item: MediaItem) => void;
  removeMediaItem: (id: string) => void;
  setMediaLibrary: (items: MediaItem[]) => void;
  addTrack: (track: Track) => void;
  addSegment: (trackId: string, segment: TrackSegment) => void;
  updateSegment: (trackId: string, segmentId: string, updates: Partial<TrackSegment>) => void;
  updateSegmentRealtime: (trackId: string, segmentId: string, updates: Partial<TrackSegment>) => void;
  updateAllSegments: (trackId: string, updates: Partial<TrackSegment>, condition?: (s: TrackSegment) => boolean) => void;
  updateAllSegmentsRealtime: (trackId: string, updates: Partial<TrackSegment>, condition?: (s: TrackSegment) => boolean) => void;
  removeSegment: (trackId: string, segmentId: string) => void;
  removeAllCaptions: (trackId: string) => void;
  selectSegment: (segmentId: string | null) => void;
  moveSegment: (segmentId: string, sourceTrackId: string, targetTrackId: string, newStart: number, moveLinked?: boolean) => void;
  toggleTrackVisibility: (trackId: string) => void;
  toggleTrackLock: (trackId: string) => void;
}

export const useEditorStore = create<EditorState>((set, get) => ({
  currentTime: 0,
  isPlaying: false,
  videoDuration: 0,
  zoomLevel: 100, // 100px per second by default
  projectName: "Project Name:",
  aspectRatio: '9:16',

  // Transition Modal State
  transitionModalOpen: false,
  transitionModalType: 'Cross Dissolve',
  transitionTargetSegmentId: null,

  setTransitionModalOpen: (isOpen) => set({ transitionModalOpen: isOpen }),
  setTransitionModalType: (type) => set({ transitionModalType: type }),
  setTransitionTargetSegmentId: (id) => set({ transitionTargetSegmentId: id }),

  // Start with some default tracks
  tracks: [
    { id: 'video-1', type: 'video', name: 'Main Video', segments: [] },
    { id: 'audio-1', type: 'audio', name: 'Audio Track', segments: [] },
    { id: 'audio-2', type: 'audio', name: 'Audio FX', segments: [] },
    { id: 'text-1', type: 'text', name: 'Captions', segments: [] },
    { id: 'effect-1', type: 'effect', name: 'Transitions & Effects', segments: [] },
  ],
  selectedSegmentId: null,
  mediaLibrary: [],
  transcriptionText: '',

  past: [],
  future: [],

  setProjectName: (name) => set({ projectName: name }),
  setAspectRatio: (ratio) => set({ aspectRatio: ratio }),
  setCurrentTime: (time) => set({ currentTime: time }),
  setIsPlaying: (isPlaying) => set({ isPlaying }),
  setVideoDuration: (duration) => set({ videoDuration: duration }),
  setZoomLevel: (zoom) => set({ zoomLevel: zoom }),
  
  setTranscriptionText: (text) => set({ transcriptionText: text }),

  addMediaItem: (item) => set((state) => ({ mediaLibrary: [...state.mediaLibrary, item] })),
  removeMediaItem: (id) => set((state) => ({ mediaLibrary: state.mediaLibrary.filter(item => item.id !== id) })),
  setMediaLibrary: (items) => set({ mediaLibrary: items }),

  saveHistory: () => {
    const { tracks, past } = get();
    // Keep max 20 history states
    const newPast = [...past, JSON.parse(JSON.stringify(tracks))].slice(-20);
    set({ past: newPast, future: [] });
  },

  undo: () => {
    const { past, future, tracks } = get();
    if (past.length === 0) return;
    const previous = past[past.length - 1];
    const newPast = past.slice(0, past.length - 1);
    set({ 
      past: newPast, 
      future: [JSON.parse(JSON.stringify(tracks)), ...future], 
      tracks: previous 
    });
  },

  redo: () => {
    const { past, future, tracks } = get();
    if (future.length === 0) return;
    const next = future[0];
    const newFuture = future.slice(1);
    set({ 
      past: [...past, JSON.parse(JSON.stringify(tracks))], 
      future: newFuture, 
      tracks: next 
    });
  },

  setTracks: (tracks) => set({ tracks, past: [], future: [] }),

  addTrack: (track) => {
    get().saveHistory();
    set((state) => ({ tracks: [...state.tracks, track] }));
  },
  
  addSegment: (trackId, segment) => {
    const track = get().tracks.find(t => t.id === trackId);
    if (track?.isLocked) return;
    
    get().saveHistory();
    set((state) => ({
      tracks: state.tracks.map(t => 
        t.id === trackId ? { ...t, segments: [...t.segments, segment] } : t
      )
    }));
  },

  updateSegment: (trackId, segmentId, updates) => {
    const track = get().tracks.find(t => t.id === trackId);
    if (track?.isLocked) return;

    get().saveHistory();
    set((state) => ({
      tracks: state.tracks.map(t => 
        t.id === trackId ? {
          ...t,
          segments: t.segments.map(s => s.id === segmentId ? { ...s, ...updates } : s)
        } : t
      )
    }));
  },

  updateSegmentRealtime: (trackId, segmentId, updates) => {
    set((state) => ({
      tracks: state.tracks.map(t => 
        t.id === trackId ? {
          ...t,
          segments: t.segments.map(s => s.id === segmentId ? { ...s, ...updates } : s)
        } : t
      )
    }));
  },

  updateAllSegments: (trackId, updates, condition) => {
    const track = get().tracks.find(t => t.id === trackId);
    if (track?.isLocked) return;

    get().saveHistory();
    set((state) => ({
      tracks: state.tracks.map(t => 
        t.id === trackId ? {
          ...t,
          segments: t.segments.map(s => (!condition || condition(s)) ? { ...s, ...updates } : s)
        } : t
      )
    }));
  },

  updateAllSegmentsRealtime: (trackId, updates, condition) => {
    const track = get().tracks.find(t => t.id === trackId);
    if (track?.isLocked) return;

    set((state) => ({
      tracks: state.tracks.map(t => 
        t.id === trackId ? {
          ...t,
          segments: t.segments.map(s => (!condition || condition(s)) ? { ...s, ...updates } : s)
        } : t
      )
    }));
  },

  removeSegment: (trackId, segmentId) => {
    const track = get().tracks.find(t => t.id === trackId);
    if (track?.isLocked) return;

    get().saveHistory();
    set((state) => ({
      tracks: state.tracks.map(t => 
        t.id === trackId ? {
          ...t,
          segments: t.segments.filter(s => s.id !== segmentId)
        } : t
      ),
      selectedSegmentId: state.selectedSegmentId === segmentId ? null : state.selectedSegmentId
    }));
  },

  removeAllCaptions: (trackId) => {
    const track = get().tracks.find(t => t.id === trackId);
    if (track?.isLocked) return;

    get().saveHistory();
    set((state) => ({
      tracks: state.tracks.map(t => 
        t.id === trackId ? {
          ...t,
          segments: t.segments.filter(s => s.name !== 'Caption')
        } : t
      )
    }));
  },

  selectSegment: (segmentId) => {
    set({ selectedSegmentId: segmentId });
    if (segmentId) {
      const state = get();
      let foundSeg = null;
      for (const t of state.tracks) {
        const s = t.segments.find(x => x.id === segmentId);
        if (s) {
          foundSeg = s;
          break;
        }
      }
      
      // Auto-seek the playhead to the segment if it's not currently visible
      if (foundSeg) {
        const { currentTime } = state;
        if (currentTime < foundSeg.start || currentTime >= foundSeg.end) {
          set({ currentTime: foundSeg.start });
        }
      }
    }
  },

  moveSegment: (segmentId, sourceTrackId, targetTrackId, newStart, moveLinked = true) => {
    const state = get();
    const sourceTrack = state.tracks.find(t => t.id === sourceTrackId);
    const targetTrack = state.tracks.find(t => t.id === targetTrackId);
    
    if (sourceTrack?.isLocked || targetTrack?.isLocked) return;

    state.saveHistory();
    set((state) => {
      let segmentToMove: TrackSegment | undefined;
      
      // Find the segment to move
      for (const t of state.tracks) {
        if (t.id === sourceTrackId) {
          segmentToMove = t.segments.find(s => s.id === segmentId);
          break;
        }
      }

      if (!segmentToMove) return state;

      const timeDelta = newStart - segmentToMove.start;
      const srcToLink = segmentToMove.src;
      const shouldMoveLinked = moveLinked && !!srcToLink;

      const updatedSegment = {
        ...segmentToMove,
        trackId: targetTrackId,
        start: newStart,
        end: newStart + segmentToMove.duration
      };

      const newTracks = state.tracks.map(t => {
        // Remove the dragged segment from its source track
        let newSegments = t.segments;
        if (t.id === sourceTrackId) {
          newSegments = newSegments.filter(s => s.id !== segmentId);
        }

        // If moveLinked is true, shift all matching segments that aren't the dragged one
        if (shouldMoveLinked) {
          newSegments = newSegments.map(s => {
            if (s.src === srcToLink && s.id !== segmentId && Math.abs(s.start - segmentToMove!.start) < 0.01) {
              return {
                ...s,
                start: s.start + timeDelta,
                end: s.end + timeDelta
              };
            }
            return s;
          });
        }

        // Add the dragged segment to its target track
        if (t.id === targetTrackId) {
          newSegments = [...newSegments, updatedSegment];
        }

        return {
          ...t,
          segments: newSegments
        };
      });

      return { tracks: newTracks };
    });
  },

  toggleTrackVisibility: (trackId) => set((state) => ({
    tracks: state.tracks.map(t => 
      t.id === trackId ? { ...t, isHidden: !t.isHidden } : t
    )
  })),

  toggleTrackLock: (trackId) => set((state) => ({
    tracks: state.tracks.map(t => 
      t.id === trackId ? { ...t, isLocked: !t.isLocked } : t
    )
  })),
}));
