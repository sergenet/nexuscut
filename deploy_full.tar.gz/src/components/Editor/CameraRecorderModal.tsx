import React, { useRef, useState, useEffect } from 'react';
import { X, Video, Square, Camera } from 'lucide-react';

interface CameraRecorderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRecordFinish: (file: File, durationSecs: number) => void;
}

export default function CameraRecorderModal({ isOpen, onClose, onRecordFinish }: CameraRecorderModalProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  
  const [isRecording, setIsRecording] = useState(false);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const startTimeRef = useRef<number>(0);

  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [isOpen]);

  const startCamera = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraReady(true);
    } catch (err: any) {
      console.error("Error accessing camera:", err);
      setError(err.message || "Could not access camera and microphone.");
      setIsCameraReady(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsRecording(false);
    setIsCameraReady(false);
  };

  const startRecording = () => {
    if (!streamRef.current) return;
    
    chunksRef.current = [];
    
    let options: MediaRecorderOptions = {};
    if (MediaRecorder.isTypeSupported('video/webm; codecs=vp9,opus')) {
      options = { mimeType: 'video/webm; codecs=vp9,opus' };
    } else if (MediaRecorder.isTypeSupported('video/webm')) {
      options = { mimeType: 'video/webm' };
    } else if (MediaRecorder.isTypeSupported('video/mp4')) {
      options = { mimeType: 'video/mp4' };
    }
        
    try {
      const mediaRecorder = new MediaRecorder(streamRef.current, options);
      
      mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };
      
      mediaRecorder.onstop = () => {
        const actualMimeType = mediaRecorder.mimeType || options.mimeType || 'video/mp4';
        const ext = actualMimeType.includes('webm') ? 'webm' : 'mp4';
        const blob = new Blob(chunksRef.current, { type: actualMimeType });
        const file = new File([blob], `recording_${Date.now()}.${ext}`, { type: actualMimeType });
        
        const durationSecs = (Date.now() - startTimeRef.current) / 1000;
        onRecordFinish(file, durationSecs);
        onClose(); // Automatically close on finish
      };
      
      mediaRecorder.start(500); // 500ms chunks to be safer on Safari
      mediaRecorderRef.current = mediaRecorder;
      startTimeRef.current = Date.now();
      setIsRecording(true);
    } catch (err: any) {
      console.error("Failed to start MediaRecorder:", err);
      setError("Failed to start recording: " + err.message);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 w-full max-w-2xl shadow-2xl relative flex flex-col">
        
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-neutral-400 hover:text-white transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Camera className="w-6 h-6 text-indigo-400" />
          Camera Recording
        </h2>

        {error ? (
          <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-lg mb-4 text-center">
            {error}
          </div>
        ) : (
          <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden border border-neutral-800 mb-6">
            <video 
              ref={videoRef} 
              autoPlay 
              muted 
              playsInline
              className="w-full h-full object-cover transform -scale-x-100"
            />
            {isRecording && (
              <div className="absolute top-4 right-4 flex items-center gap-2 bg-black/50 px-3 py-1.5 rounded-full backdrop-blur-md">
                <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-white text-xs font-bold tracking-wider">REC</span>
              </div>
            )}
          </div>
        )}

        <div className="flex justify-center">
          {!isRecording ? (
            <button 
              onClick={startRecording}
              disabled={!!error || !isCameraReady}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3 rounded-full font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-indigo-500/25"
            >
              <Video className="w-5 h-5" />
              Start Recording
            </button>
          ) : (
            <button 
              onClick={stopRecording}
              className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-8 py-3 rounded-full font-bold transition-all shadow-lg hover:shadow-red-500/25"
            >
              <Square className="w-5 h-5 fill-current" />
              Stop Recording
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
