"use client";

import React from 'react';
import { Layers, Sliders, Undo, Redo } from 'lucide-react';
import { useEditorStore } from '@/store/useEditorStore';

interface MobileActionBarProps {
  onOpenSidebar: () => void;
  onOpenProperties: () => void;
}

export default function MobileActionBar({ onOpenSidebar, onOpenProperties }: MobileActionBarProps) {
  const { undo, redo, past, future } = useEditorStore();

  return (
    <div className="h-16 w-full bg-neutral-950 border-t border-neutral-800 flex items-center justify-around px-2 z-30">
      
      <button 
        onClick={onOpenSidebar}
        className="flex flex-col items-center justify-center text-neutral-400 hover:text-white transition-colors w-16"
      >
        <Layers className="w-5 h-5 mb-1" />
        <span className="text-[10px] font-bold">Tools</span>
      </button>

      <button 
        onClick={onOpenProperties}
        className="flex flex-col items-center justify-center text-neutral-400 hover:text-white transition-colors w-16"
      >
        <Sliders className="w-5 h-5 mb-1" />
        <span className="text-[10px] font-bold">Edit</span>
      </button>

      <div className="w-px h-8 bg-neutral-800" />

      <button 
        onClick={undo}
        disabled={past.length === 0}
        className="flex flex-col items-center justify-center text-neutral-400 hover:text-white transition-colors w-16 disabled:opacity-30"
      >
        <Undo className="w-5 h-5 mb-1" />
        <span className="text-[10px] font-bold">Undo</span>
      </button>

      <button 
        onClick={redo}
        disabled={future.length === 0}
        className="flex flex-col items-center justify-center text-neutral-400 hover:text-white transition-colors w-16 disabled:opacity-30"
      >
        <Redo className="w-5 h-5 mb-1" />
        <span className="text-[10px] font-bold">Redo</span>
      </button>

    </div>
  );
}
