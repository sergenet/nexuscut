import React, { useEffect, useRef } from 'react';
import { TrackSegment } from '@/store/useEditorStore';

interface TrackVideoProps {
  activeVideo: TrackSegment;
  isMuted: boolean;
  setIsPlaying: (playing: boolean) => void;
}

export const TrackVideo = React.memo(React.forwardRef<HTMLVideoElement, TrackVideoProps>(({ activeVideo, isMuted, setIsPlaying }, ref) => {
  const localRef = useRef<HTMLVideoElement>(null);
  
  useEffect(() => {
    return () => {
      if (localRef.current) {
        localRef.current.pause();
      }
    };
  }, []);

  useEffect(() => {
    if (localRef.current && activeVideo.src) {
      localRef.current.load();
    }
  }, [activeVideo.src]);

  const handleRef = React.useCallback((el: HTMLVideoElement | null) => {
    localRef.current = el;
    if (typeof ref === 'function') ref(el);
    else if (ref) ref.current = el;
  }, [ref]);

  return (
    <video 
      ref={handleRef}
      src={activeVideo.src}
      className="w-full h-full object-contain transition-transform"
      style={{
         transform: `scale(${activeVideo.scale ?? 1}) translate3d(${(activeVideo.x || 50) - 50}%, ${(activeVideo.y || 50) - 50}%, 0)`,
         WebkitTransform: `scale(${activeVideo.scale ?? 1}) translate3d(${(activeVideo.x || 50) - 50}%, ${(activeVideo.y || 50) - 50}%, 0)`,
         opacity: activeVideo.opacity ?? 1
      }}
      muted={isMuted}
      playsInline
      preload="auto"
      onEnded={() => setIsPlaying(false)}
    />
  );
}));

TrackVideo.displayName = 'TrackVideo';

interface TrackAudioProps {
  audioSeg: TrackSegment;
  onRef: (el: HTMLAudioElement | null) => void;
}

export const TrackAudio: React.FC<TrackAudioProps> = React.memo(({ audioSeg, onRef }) => {
  const localRef = useRef<HTMLAudioElement>(null);
  
  useEffect(() => {
    return () => {
      if (localRef.current) {
        localRef.current.pause();
        localRef.current.removeAttribute('src');
        localRef.current.load();
      }
    };
  }, []);

  const handleRef = React.useCallback((el: HTMLAudioElement | null) => {
    localRef.current = el;
    onRef(el);
  }, [onRef]);

  return (
    <audio 
      ref={handleRef}
      src={audioSeg.src} 
      preload="auto"
      className="hidden"
    />
  );
});

TrackAudio.displayName = 'TrackAudio';
