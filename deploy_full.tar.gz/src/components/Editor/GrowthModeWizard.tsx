import React, { useState, useEffect } from 'react';
import { Sparkles, X, Wand2, Music, CheckCircle2 } from 'lucide-react';
import { useEditorStore } from '@/store/useEditorStore';

interface GrowthModeWizardProps {
  onClose: () => void;
}

export default function GrowthModeWizard({ onClose }: GrowthModeWizardProps) {
  const [step, setStep] = useState(1);
  const [selectedStyle, setSelectedStyle] = useState('hormozi');
  const [isApplying, setIsApplying] = useState(false);
  const { addSegment } = useEditorStore();

  useEffect(() => {
    if (step === 2) {
      handleApply();
    }
  }, [step]);

  const handleApply = async () => {
    setIsApplying(true);
    
    try {
      const state = useEditorStore.getState();
      const videoTrack = state.tracks.find(t => t.id === 'video-1');
      
      if (!videoTrack || videoTrack.segments.length === 0) {
        alert('Please add a video to the timeline first!');
        setIsApplying(false);
        setStep(1);
        return;
      }
      
      const firstSeg = videoTrack.segments[0];
      const mediaItem = state.mediaLibrary.find(m => m.url === firstSeg.src);
      
      if (!mediaItem || !mediaItem.file) {
        alert('Cannot find original file.');
        setIsApplying(false);
        setStep(1);
        return;
      }

      const formData = new FormData();
      formData.append('file', mediaItem.file);
      const res = await fetch('/api/backend-transcribe', { 
        method: 'POST', 
        body: formData
      });
      const data = await res.json();

      if (data.error) throw new Error(data.error);

      if (data.transcription && data.transcription.words) {
        state.setTranscriptionText(data.transcription.text);
        
        // 1. Extract hook
        const compactTranscript = data.transcription.words.map((w: any) => `[${w.start}s] ${w.word}`).join(' ');
        const hookRes = await fetch('/api/extract-hook', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ transcript: compactTranscript })
        });
        const hookData = await hookRes.json();
        
        let hookStart = 0;
        let hookEnd = 15; // fallback
        
        if (hookData.start !== undefined && hookData.end !== undefined) {
          hookStart = hookData.start;
          hookEnd = hookData.end;
        } else {
          // If OpenAI fails, fallback to first 15 seconds
          const lastWord = data.transcription.words.find((w: any) => w.end > 15);
          hookEnd = lastWord ? lastWord.end : data.transcription.words[data.transcription.words.length - 1].end;
        }
        
        const trimmedDuration = hookEnd - hookStart;

        // 2. Trim video
        const existingVideoSegments = [...(state.tracks.find(t => t.id === 'video-1')?.segments || [])];
        existingVideoSegments.forEach(seg => {
           state.removeSegment('video-1', seg.id);
        });
        
        state.addSegment('video-1', {
           id: `gm-vid-${Date.now()}`,
           trackId: 'video-1',
           start: 0,
           end: trimmedDuration,
           duration: trimmedDuration,
           sourceStart: hookStart,
           type: 'video',
           src: firstSeg.src
        });

        // 3. Remove existing auto-captions
        const textTrack = state.tracks.find(t => t.id === 'text-1');
        if (textTrack) {
          textTrack.segments.forEach(seg => {
            if (seg.name === 'Caption') {
              state.removeSegment('text-1', seg.id);
            }
          });
        }

        // 4. Add Captions ONLY for the hook
        data.transcription.words.forEach((word: any) => {
          const wordOriginalStart = word.start;
          const wordOriginalEnd = word.end;
          
          if (wordOriginalStart >= hookStart && wordOriginalEnd <= (hookEnd + 0.5)) {
             const timelineStart = wordOriginalStart - hookStart;
             const timelineEnd = wordOriginalEnd - hookStart;
             
             if (timelineEnd > timelineStart) {
                const newId = Math.random().toString(36).substr(2, 9);
                state.addSegment('text-1', {
                  id: newId,
                  trackId: 'text-1',
                  start: timelineStart,
                  end: timelineEnd,
                  duration: timelineEnd - timelineStart,
                  type: 'text',
                  name: 'Caption',
                  text: word.word,
                  src: firstSeg.src,
                  color: selectedStyle === 'hormozi' ? '#FFD700' : '#FFFFFF',
                  fontFamily: selectedStyle === 'hormozi' ? 'Inter-Black' : 'Roboto-Regular',
                  fontSize: selectedStyle === 'hormozi' ? 64 : 48,
                  style: selectedStyle,
                  y: 80
                });
             }
          }
        });
      }
      
      // Add a cool sound effect to the start to act as a hook
      state.addSegment('audio-2', {
        id: `gm-sfx-${Date.now()}`,
        trackId: 'audio-2',
        start: 0,
        end: 1.5,
        duration: 1.5,
        type: 'audio',
        name: 'Whoosh SFX',
        src: '/sounds/whoosh.wav'
      });

      setStep(3); // Success step
    } catch (err: any) {
      console.error(err);
      alert('Failed to apply Growth Mode: ' + err.message);
      setStep(1);
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-emerald-500/30 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden shadow-emerald-500/10 flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-gradient-to-r from-emerald-950/40 to-transparent">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white tracking-tight">Growth Mode (Beta)</h2>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6">
          {step === 1 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <div className="text-center">
                <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Wand2 className="w-8 h-8 text-emerald-400" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Automate Viral Hooks</h3>
                <p className="text-neutral-400 text-sm">
                  Growth Mode analyzes your video, extracts the most engaging hook, and automatically applies high-retention captions and sound effects.
                </p>
              </div>

              <div className="space-y-3 pt-4 border-t border-neutral-800">
                <p className="text-sm font-semibold text-white">Select Caption Style:</p>
                <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={() => setSelectedStyle('hormozi')}
                    className={`p-3 rounded-lg border text-left transition-all ${selectedStyle === 'hormozi' ? 'border-emerald-500 bg-emerald-500/10' : 'border-neutral-700 bg-neutral-800 hover:border-neutral-500'}`}
                  >
                    <span className="block font-black text-yellow-400 text-lg mb-1 leading-none uppercase tracking-tighter" style={{ textShadow: '2px 2px 0 #000' }}>The Hormozi</span>
                    <span className="text-xs text-neutral-400">Bold & Dynamic</span>
                  </button>
                  <button 
                    onClick={() => setSelectedStyle('abdaal')}
                    className={`p-3 rounded-lg border text-left transition-all ${selectedStyle === 'abdaal' ? 'border-emerald-500 bg-emerald-500/10' : 'border-neutral-700 bg-neutral-800 hover:border-neutral-500'}`}
                  >
                    <span className="block font-medium text-white text-lg mb-1 leading-none">The Abdaal</span>
                    <span className="text-xs text-neutral-400">Clean & Minimal</span>
                  </button>
                </div>
              </div>

              <button 
                onClick={() => setStep(2)}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition-colors shadow-lg shadow-emerald-600/20"
              >
                Continue
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="py-12 text-center animate-in fade-in duration-300">
              <div className="relative w-24 h-24 mx-auto mb-6">
                <div className="absolute inset-0 border-4 border-neutral-800 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-emerald-500 rounded-full border-t-transparent animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles className="w-8 h-8 text-emerald-400 animate-pulse" />
                </div>
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Analyzing Video...</h3>
              <p className="text-sm text-neutral-400">Finding the perfect hook and applying templates.</p>
            </div>
          )}

          {step === 3 && (
            <div className="py-8 text-center animate-in fade-in zoom-in-95 duration-300">
              <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-10 h-10 text-emerald-400" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Growth Mode Applied!</h3>
              <p className="text-neutral-400 text-sm mb-8">
                Added {selectedStyle === 'hormozi' ? 'dynamic' : 'clean'} captions and a high-impact hook sound effect to the timeline.
              </p>
              <button 
                onClick={onClose}
                className="w-full py-3 bg-neutral-800 hover:bg-neutral-700 text-white font-bold rounded-xl border border-neutral-700 transition-colors"
              >
                Back to Editor
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
