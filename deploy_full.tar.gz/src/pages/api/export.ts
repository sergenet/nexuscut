import { NextApiRequest, NextApiResponse } from 'next';
import Busboy from 'busboy';
import fs from 'fs';
import os from 'os';
import path from 'path';
import ffmpegPath from 'ffmpeg-static';
import { exec } from 'child_process';
import util from 'util';
import prisma from '@/lib/prisma';

const execPromise = util.promisify(exec);


export const config = {
  api: {
    bodyParser: false,
    responseLimit: false,
  },
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method Not Allowed' });
  try {
    
    const data = await new Promise<any>((resolve, reject) => {
      const busboy = Busboy({ headers: req.headers });
      const fields: any = {};
      const files: any = {};

      busboy.on('file', (name, file, info) => {
        const saveTo = path.join(os.tmpdir(), `${name}-${Date.now()}`);
        file.pipe(fs.createWriteStream(saveTo));
        if (!files[name]) files[name] = [];
        files[name].push(saveTo);
      });

      busboy.on('field', (name, val) => {
        fields[name] = val;
      });

      busboy.on('finish', () => resolve({ fields, files }));
      busboy.on('error', reject);
      req.pipe(busboy);
    });

    const formData = {
      has: (name: string) => data.fields[name] !== undefined || data.files[name] !== undefined,
      get: (name: string) => {
        if (data.fields[name] !== undefined) return data.fields[name];
        if (data.files[name] && data.files[name].length > 0) return data.files[name][0];
        return null;
      }
    };

    
    // Extract dynamic video files
    const mainVideoFiles: string[] = [];
    let i = 0;
    while (formData.has(`videoFile_${i}`)) {
      mainVideoFiles.push(formData.get(`videoFile_${i}`) as string);
      i++;
    }
    const bgmFile = formData.get('bgmFile') as string | null;
    const ttsFile = formData.get('ttsFile') as string | null;
    const activeSegmentsStr = formData.get('activeSegments') as string;
    const captionsStr = formData.get('captions') as string;
    const brollSegmentsStr = formData.get('brollSegments') as string;
    const audioFxStr = formData.get('audioFx') as string;
    const autoZoom = formData.get('autoZoom') === 'true';
    const magicColor = formData.get('magicColor') === 'true';
    let captionFont = formData.get('captionFont') as string || 'Roboto-Black';
    const captionSize = formData.get('captionSize') as string || '48';
    const captionColor = formData.get('captionColor') as string || '#FFFF00';
    const mainVolume = formData.get('mainVolume') as string || '1.0';
    const bgmVolume = formData.get('bgmVolume') as string || '0.5';
    let vw = formData.get('vw') as string || '1080';
    let vh = formData.get('vh') as string || '1920';

    // Fetch user for limits & watermark
    const userId = "local-user"; // Hardcoded for no-auth matching user/me
    const user = await prisma.user.upsert({
      where: { clerkId: userId },
      update: {},
      create: { clerkId: userId },
    });

    const isFree = user.planTier === 'free' && !user.isPro;

    if (isFree) {
      if (user.exportCount >= 10) {
        return res.status(403).json({ error: 'You have reached your free tier limit of 10 exports.' });
      }
      // Force 720p max for free tier
      vw = '720';
      vh = '1280';
      // Restrict premium fonts
      captionFont = 'Roboto-Black';
    }

    const activeSegments = JSON.parse(activeSegmentsStr || '[]');
    console.log("activeSegments received:", JSON.stringify(activeSegments, null, 2));
    const captions = JSON.parse(captionsStr || '[]');
    const brollSegments = JSON.parse(brollSegmentsStr || '[]');
    const audioFx = JSON.parse(audioFxStr || '[]');

    // Build a proper source-time to export-time mapping.
    // Each segment in the timeline has a source range (sourceStart..sourceEnd) that maps to
    // an output range. When transitions exist, the output duration is compressed because
    // xfade overlaps the end of one segment with the start of the next.
    // Captions are positioned on the timeline (seg.start..seg.end), so we need to map
    // timeline positions to output positions.
    
    // First compute what the output timeline looks like after xfade compression
    const segDurations = activeSegments.map((seg: any) => seg.end - seg.start);
    const outputSegStarts: number[] = [];
    let outputTime = 0;
    
    for (let i = 0; i < activeSegments.length; i++) {
      outputSegStarts.push(outputTime);
      outputTime += segDurations[i];
    }
    const totalOutputDuration = outputTime;

    // Map a timeline time to an output time
    const mapTimeToExport = (t: number): number => {
      for (let i = 0; i < activeSegments.length; i++) {
        const seg = activeSegments[i];
        if (t >= seg.start && t < seg.end) {
          const offsetInSeg = t - seg.start;
          return outputSegStarts[i] + offsetInSeg;
        }
      }
      // Past the last segment
      const lastSeg = activeSegments[activeSegments.length - 1];
      if (lastSeg && t >= lastSeg.end) {
        const offsetInSeg = lastSeg.end - lastSeg.start;
        return outputSegStarts[outputSegStarts.length - 1] + offsetInSeg;
      }
      return t;
    };

    // Apply mapping to captions, broll, and audio FX
    captions.forEach((c: any) => { c.start = mapTimeToExport(c.start); c.end = mapTimeToExport(c.end); });
    brollSegments.forEach((b: any) => { b.start = mapTimeToExport(b.start); b.end = mapTimeToExport(b.end); });
    audioFx.forEach((a: any) => { a.start = mapTimeToExport(a.start); });

    // Calculate vertical margin for captions to avoid native UI on TikTok/Shorts
    const isVertical = parseInt(vh) > parseInt(vw);
    const marginV = isVertical ? 400 : 80;

    // Setup temp directory
    const tempDir = os.tmpdir();
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
    
    const id = Date.now().toString();
    const outputPath = path.join(tempDir, `output_${id}.mp4`);
    const bgmPath = path.join(tempDir, `bgm_${id}.mp3`);
    const ttsPath = path.join(tempDir, `tts_${id}.mp3`);
    const srtPath = path.join(tempDir, `captions_${id}.srt`);
    // Use a dedicated fonts directory to prevent libass from scanning all of /tmp
    const fontDir = path.join(tempDir, `nexuscut_fonts_${id}`);
    if (!fs.existsSync(fontDir)) fs.mkdirSync(fontDir, { recursive: true });
    const fontPath = path.join(fontDir, `${captionFont}.ttf`);

    // Write all main video files
    const mainVideoPaths: string[] = [];
    for (let j = 0; j < mainVideoFiles.length; j++) {
      const vFile = mainVideoFiles[j];
      const p = path.join(tempDir, `input_${id}_${j}.mp4`);
      const vBuffer = fs.readFileSync(vFile);
      fs.writeFileSync(p, vBuffer);
      mainVideoPaths.push(p);
    }

    // Write BGM
    if (bgmFile) {
      const bgmBuffer = fs.readFileSync(bgmFile);
      fs.writeFileSync(bgmPath, bgmBuffer);
    }
    
    // Write TTS
    if (ttsFile) {
      const ttsBuffer = fs.readFileSync(ttsFile);
      fs.writeFileSync(ttsPath, ttsBuffer);
    }

    // Download Font
    let fontUrl = 'https://raw.githubusercontent.com/googlefonts/roboto-2/main/src/hinted/Roboto-Black.ttf';
    if (captionFont === 'Montserrat-Bold') fontUrl = 'https://github.com/JulietaUla/Montserrat/raw/master/fonts/ttf/Montserrat-Bold.ttf';
    if (captionFont === 'BebasNeue-Regular') fontUrl = 'https://raw.githubusercontent.com/googlefonts/bebasneue/main/fonts/ttf/BebasNeue-Regular.ttf';
    if (captionFont === 'Oswald-Bold') fontUrl = 'https://raw.githubusercontent.com/googlefonts/oswald/main/fonts/ttf/Oswald-Bold.ttf';
    
    try {
      const fontRes = await fetch(fontUrl);
      if (fontRes.ok) {
        const fontBuffer = Buffer.from(await fontRes.arrayBuffer());
        fs.writeFileSync(fontPath, fontBuffer);
      }
    } catch (e) {
      console.warn("Failed to download font", e);
    }

    // Download B-Roll videos
    const brollPaths: any[] = [];
    for (let i = 0; i < brollSegments.length; i++) {
      const seg = brollSegments[i];
      if (seg.videoUrl) {
        const bp = path.join(tempDir, `broll_${id}_${i}.mp4`);
        const bRes = await fetch(seg.videoUrl);
        const bBuf = Buffer.from(await bRes.arrayBuffer());
        fs.writeFileSync(bp, bBuf);
        brollPaths.push({ path: bp, start: seg.start, end: seg.end });
      }
    }

    // (Old SRT writing block removed - handled in pass 2)

    // Write initial status and return Job ID to the client
    const statusPath = path.join(tempDir, `status_${id}.json`);
    fs.writeFileSync(statusPath, JSON.stringify({ status: 'processing', progress: 0 }));
    res.status(200).json({ jobId: id, status: 'processing' });
    
    // Execute FFmpeg asynchronously so it does not block the API response
    (async () => {
      try {
        // Build FFmpeg command
        // Use process.cwd() to reliably find the ffmpeg binary, as Next.js Webpack breaks __dirname
        const ffmpegCmd = path.join(process.cwd(), 'node_modules', 'ffmpeg-static', os.platform() === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');

    // Track inputs as an ordered list of -i arguments. inputIndex is the FFmpeg stream index.
    const inputArgs: string[] = [];
    let inputIndex = 0;

    // Sort segments by their timeline start to ensure correct concatenation order
    activeSegments.sort((a: any, b: any) => a.start - b.start);

    // Provide the input video multiple times using fast-seeking (-ss before -i).
    // This is CRITICAL to prevent OOM. Using multiple 'trim' filters on a single [0:v] 
    // forces FFmpeg to buffer gigabytes of uncompressed frames. Separate inputs eliminate buffering.
    const segmentInputIdxs: number[] = [];
    activeSegments.forEach((seg: any) => {
      const fileIndex = seg.fileIndex || 0;
      const sourceFile = mainVideoPaths[fileIndex];
      
      const duration = seg.end - seg.start;
      const sourceStart = seg.sourceStart || 0;
      
      // Fast seek to the exact segment start and read only the needed duration
      inputArgs.push(`-ss ${sourceStart} -t ${duration} -i "${sourceFile}"`);
      segmentInputIdxs.push(inputIndex++);
    });

    // Add b-roll inputs
    const brollIdxs: number[] = [];
    brollPaths.forEach(b => {
      inputArgs.push(`-i "${b.path}"`);
      brollIdxs.push(inputIndex++);
    });

    // Add BGM input
    let bgmIdx = -1;
    if (bgmFile) {
      inputArgs.push(`-i "${bgmPath}"`);
      bgmIdx = inputIndex++;
    }

    // Add TTS input
    let ttsIdx = -1;
    if (ttsFile) {
      inputArgs.push(`-i "${ttsPath}"`);
      ttsIdx = inputIndex++;
    }

    // Add Audio FX inputs
    const audioFxIdxs: { idx: number, start: number, volume?: number }[] = [];
    audioFx.forEach((fx: any) => {
      if (fx.url) {
        const fxPath = path.join(process.cwd(), 'public', fx.url);
        if (fs.existsSync(fxPath)) {
          inputArgs.push(`-i "${fxPath}"`);
          audioFxIdxs.push({ idx: inputIndex++, start: fx.start, volume: fx.volume });
        }
      }
    });

    // Add swoosh SFX input
    const autoSfx = formData.get('autoSfx') === 'true';
    let swooshIdx = -1;
    if (autoSfx && brollPaths.length > 0) {
      const swooshPath = path.join(process.cwd(), 'public', 'sfx', 'swoosh.mp3');
      inputArgs.push(`-i "${swooshPath}"`);
      swooshIdx = inputIndex++;
    }

    console.log("Pass 1 starting...");

    // Build Filtergraph
    const filterGraph: string[] = [];

    let currentVideoLabel = `0:v`;
    let currentAudioLabel = `0:a`;

    if (activeSegments.length > 0) {
      // Format each individual segment stream to match output resolution
      activeSegments.forEach((seg: any, i: number) => {
        const vidIdx = segmentInputIdxs[i];
        // Since we used -ss and -t on the input, the stream already starts at 0 and has correct duration.
        // We just need to scale/pad it and ensure framerate, and CRITICALLY set the timebase so xfade doesn't crash
        filterGraph.push(`[${vidIdx}:v]fps=30,scale=${vw}:${vh}:force_original_aspect_ratio=decrease,pad=${vw}:${vh}:(ow-iw)/2:(oh-ih)/2:color=black,format=yuv420p,setsar=1/1,settb=1/90000[v_seg${i}]`);
        filterGraph.push(`[${vidIdx}:a]aformat=sample_rates=44100:channel_layouts=stereo[a_seg${i}]`);
      });

      // FAST CONCAT TRANSITION LOGIC
      const concatVideos: string[] = [];
      const concatAudios: string[] = [];
      
      const vLabels = activeSegments.map((_: any, i: number) => `v_seg${i}`);
      const aLabels = activeSegments.map((_: any, i: number) => `a_seg${i}`);
      
      for (let i = 0; i < activeSegments.length; i++) {
        const seg = activeSegments[i];
        const segDuration = seg.end - seg.start;
        
        if (seg.transitionOut && seg.transitionOut.type !== 'None' && i < activeSegments.length - 1) {
            const tDuration = Math.min(seg.transitionOut.duration || 0.5, segDuration / 2, 0.5);
            const fadeOutStart = Math.max(0, segDuration - tDuration);
            
            filterGraph.push(`[${vLabels[i]}]fade=t=out:st=${fadeOutStart}:d=${tDuration}[v_fout${i}]`);
            filterGraph.push(`[${aLabels[i]}]afade=t=out:st=${fadeOutStart}:d=${tDuration}[a_fout${i}]`);
            vLabels[i] = `v_fout${i}`;
            aLabels[i] = `a_fout${i}`;
            
            const nextSeg = activeSegments[i+1];
            const nextDuration = nextSeg.end - nextSeg.start;
            const nextTDur = Math.min(tDuration, nextDuration / 2);
            filterGraph.push(`[${vLabels[i+1]}]fade=t=in:st=0:d=${nextTDur}[v_fin${i+1}]`);
            filterGraph.push(`[${aLabels[i+1]}]afade=t=in:st=0:d=${nextTDur}[a_fin${i+1}]`);
            vLabels[i+1] = `v_fin${i+1}`;
            aLabels[i+1] = `a_fin${i+1}`;
        }
        
        if (i === activeSegments.length - 1 && seg.transitionOut && seg.transitionOut.type !== 'None') {
            const tDuration = Math.min(seg.transitionOut.duration || 0.5, segDuration / 2, 0.5);
            const fadeOutStart = Math.max(0, segDuration - tDuration);
            filterGraph.push(`[${vLabels[i]}]fade=t=out:st=${fadeOutStart}:d=${tDuration}[v_fout${i}]`);
            filterGraph.push(`[${aLabels[i]}]afade=t=out:st=${fadeOutStart}:d=${tDuration}[a_fout${i}]`);
            vLabels[i] = `v_fout${i}`;
            aLabels[i] = `a_fout${i}`;
        }
      }
      
      const n = activeSegments.length;
      let concatStr = '';
      for (let i = 0; i < n; i++) {
        concatStr += `[${vLabels[i]}][${aLabels[i]}]`;
      }
      filterGraph.push(`${concatStr}concat=n=${n}:v=1:a=1[v_concat][a_concat]`);
      
      let lastVideo = `v_concat`;
      let lastAudio = `a_concat`;
      // Normalize framerate to prevent any drift
      filterGraph.push(`[${lastVideo}]fps=30[v_sel]`);

      if (ttsIdx !== -1) {
        filterGraph.push(`[${ttsIdx}:a]volume=${mainVolume}[a_sel]`);
      } else {
        filterGraph.push(`[${lastAudio}]volume=${mainVolume}[a_sel]`);
      }

      currentVideoLabel = `v_sel`;
      currentAudioLabel = `a_sel`;
    } else {
      // Fallback if no cuts were made
      filterGraph.push(`[0:v]fps=30[v_sel]`);

      if (ttsIdx !== -1) {
        filterGraph.push(`[${ttsIdx}:a]volume=${mainVolume}[a_sel]`);
      } else {
        filterGraph.push(`[0:a]volume=${mainVolume}[a_sel]`);
      }

      currentVideoLabel = `v_sel`;
      currentAudioLabel = `a_sel`;
    }

    // 1. Overlay B-Rolls
    for (let i = 0; i < brollPaths.length; i++) {
      const b = brollPaths[i];
      const brollIdx = brollIdxs[i];

      const brollFilter = `[${brollIdx}:v]scale=${vw}:${vh}:force_original_aspect_ratio=increase,crop=${vw}:${vh},tpad=start_duration=${b.start}:color=black[broll${i}]`;
      filterGraph.push(brollFilter);

      const overlayFilter = `[${currentVideoLabel}][broll${i}]overlay=enable='between(t,${b.start},${b.end})':eof_action=pass[v_ovl${i}]`;
      filterGraph.push(overlayFilter);

      currentVideoLabel = `v_ovl${i}`;
    }

    // 2. Zoom
    if (autoZoom) {
      filterGraph.push(`[${currentVideoLabel}]crop='iw/min(1+0.03*t,1.5)':'ih/min(1+0.03*t,1.5)':'(iw-ow)/2':'(ih-oh)/2',scale=${vw}:${vh}[v_zoom]`);
      currentVideoLabel = `v_zoom`;
    }

    // 3. Magic Color
    if (magicColor) {
      filterGraph.push(`[${currentVideoLabel}]eq=contrast=1.15:saturation=1.2:brightness=0.02[v_magic]`);
      currentVideoLabel = `v_magic`;
    }

    // 4. Captions — handled in a second pass to avoid OOM (subtitles + xfade together exceed 1GB VPS RAM)
    const hasCaptions = captions.length > 0;
    let validCaps: any[] = [];
    if (hasCaptions) {
      validCaps = captions.filter((c:any) => c.start < c.end && c.start >= 0 && c.start < totalOutputDuration);
      // CRITICAL: SRT captions MUST be sorted by start time, otherwise libass drops them!
      validCaps.sort((a: any, b: any) => a.start - b.start);
    }

    // 5. Watermark (Free Tier)
    if (isFree) {
      // Free users are limited to 720p, but we cannot use drawtext on the VPS static ffmpeg build
      // because it's compiled without libfreetype.
    }

    let numAudioInputs = 1;
    let audioMixInputs = `[a_sel]`;

    if (bgmIdx !== -1) {
      filterGraph.push(`[${bgmIdx}:a]volume=${bgmVolume}[a_bgm]`);
      audioMixInputs += `[a_bgm]`;
      numAudioInputs++;
    }

    if (swooshIdx !== -1) {
      filterGraph.push(`[${swooshIdx}:a]volume=0.8,asplit=${brollPaths.length}` + brollPaths.map((_: any, i: number) => `[sw${i}]`).join(''));

      brollPaths.forEach((b: any, i: number) => {
        const delayMs = Math.round(b.start * 1000);
        filterGraph.push(`[sw${i}]adelay=${delayMs}|${delayMs}[sfx${i}]`);
        audioMixInputs += `[sfx${i}]`;
        numAudioInputs++;
      });
    }

    audioFxIdxs.forEach((fx: any, i: number) => {
      const delayMs = Math.round(fx.start * 1000);
      const vol = fx.volume !== undefined ? fx.volume : 1.0;
      filterGraph.push(`[${fx.idx}:a]volume=${vol},adelay=${delayMs}|${delayMs}[cust_sfx${i}]`);
      audioMixInputs += `[cust_sfx${i}]`;
      numAudioInputs++;
    });

    if (numAudioInputs > 1) {
      filterGraph.push(`${audioMixInputs}amix=inputs=${numAudioInputs}:duration=first:dropout_transition=2,volume=${numAudioInputs}[a_out]`);
      currentAudioLabel = `a_out`;
    }

    const finalFilterStr = filterGraph.join('; ');

    // Pass 1: Render video with transitions + audio (no captions)
    const pass1Output = hasCaptions && validCaps.length > 0 ? path.join(tempDir, `pass1_${id}.mp4`) : outputPath;
    let command = `"${ffmpegCmd}" -y -threads 4 ${inputArgs.join(' ')} -filter_complex "${finalFilterStr}" -map "[${currentVideoLabel}]" -map "[${currentAudioLabel}]" -c:v libx264 -preset ultrafast -pix_fmt yuv420p -movflags +faststart -c:a aac -b:a 192k "${pass1Output}"`;

    console.log("Pass 1 Command:", command);
    // Execute FFmpeg Pass 1
    console.log("Executing FFmpeg Pass 1...");
    fs.writeFileSync(path.join(process.cwd(), 'ffmpeg-success.log'), command);
    try {
      await execPromise(command, { maxBuffer: 50 * 1024 * 1024 });
    } catch (e: any) {
      fs.writeFileSync(path.join(process.cwd(), 'ffmpeg-error.log'), `COMMAND:\n${command}\n\nERROR:\n${e.message.slice(-5000)}`);
      throw new Error("FFmpeg failed: " + e.message.slice(-1000));
    }

    // Pass 2: Burn captions onto the rendered video (separate pass to avoid OOM)
    if (hasCaptions && validCaps.length > 0) {
      // Fix overlaps that cause collision jumping in libass (especially during transitions)
      for (let i = 0; i < validCaps.length - 1; i++) {
        if (validCaps[i].end > validCaps[i+1].start) {
          validCaps[i].end = validCaps[i+1].start - 0.001;
        }
      }

      // Write ASS file
      const playResX = Number(vw) || 1080;
      const playResY = Number(vh) || 1920;

      let assContent = `[Script Info]
ScriptType: v4.00+
PlayResX: ${playResX}
PlayResY: ${playResY}

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,20,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,3,0,2,10,10,10,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

      validCaps.forEach((c:any) => {
        const formatTimeASS = (seconds: number) => {
          const date = new Date(seconds * 1000);
          const h = String(date.getUTCHours());
          const mm = String(date.getUTCMinutes()).padStart(2, '0');
          const ss = String(date.getUTCSeconds()).padStart(2, '0');
          const cs = String(Math.floor(date.getUTCMilliseconds() / 10)).padStart(2, '0');
          return `${h}:${mm}:${ss}.${cs}`;
        };

        const startTime = formatTimeASS(c.start);
        const endTime = formatTimeASS(c.end);

        // Convert hex color #RRGGBB to ASS &HBBGGRR&
        const hex = c.color || captionColor || '#FFFFFF';
        const r = hex.substring(1, 3);
        const g = hex.substring(3, 5);
        const b = hex.substring(5, 7);
        const assColor = `&H00${b}${g}${r}&`;

        // Scale font size relative to output height (preview UI assumes ~600px height)
        // A font size of 48 in a 600px window is roughly 8% of the height.
        // We'll calculate proportional ASS font size based on PlayResY.
        const uiFontSize = Number(c.fontSize) || Number(captionSize) || 48;
        const proportionalSize = Math.round((uiFontSize / 600) * playResY);

        // Map font filename to actual internal ASS FontName to prevent libass fallback
        const uiFontFamily = c.fontFamily || captionFont || 'Inter-Black';
        let assFontName = uiFontFamily;
        if (uiFontFamily.includes('Roboto')) assFontName = 'Roboto';
        else if (uiFontFamily.includes('Montserrat')) assFontName = 'Montserrat';
        else if (uiFontFamily.includes('Bebas')) assFontName = 'Bebas Neue';
        else if (uiFontFamily.includes('Oswald')) assFontName = 'Oswald';
        else if (uiFontFamily.includes('Playfair')) assFontName = 'Playfair Display';
        else if (uiFontFamily.includes('Inter')) assFontName = 'Inter';

        // Calculate position in PlayRes coordinates based on percentage
        const xPercent = c.x !== undefined ? Number(c.x) : 50;
        const yPercent = c.y !== undefined ? Number(c.y) : 80;
        
        const posX = Math.round((xPercent / 100) * playResX);
        const posY = Math.round((yPercent / 100) * playResY);

        // Build ASS tags
        const tags = `{\\pos(${posX},${posY})\\c${assColor}\\fs${proportionalSize}\\fn${assFontName}}`;
        const textStr = c.emoji ? `${c.text} ${c.emoji}` : c.text;

        assContent += `Dialogue: 0,${startTime},${endTime},Default,,0,0,0,,${tags}${textStr}\n`;
      });

      const assPath = path.join(tempDir, `subs_${id}.ass`);
      fs.writeFileSync(assPath, assContent);

      // Use absolute path for ASS, fontsdir points to the small dedicated font directory.
      // CRITICAL: On Windows, the drive letter colon (C:) must be escaped as C\:, otherwise 
      // FFmpeg parses it as a filter argument separator, breaking the path and causing libass 
      // to scan the entire system Temp directory, which crashes it instantly.
      const escapedAssPath = assPath.replace(/\\/g, '/').replace(/:/g, '\\:').replace(/'/g, "'\\''");
      const escapedFontsDir = fontDir.replace(/\\/g, '/').replace(/:/g, '\\:');

      const pass2Command = `"${ffmpegCmd}" -y -threads 4 -i "${pass1Output}" -filter_complex "[0:v]subtitles='${escapedAssPath}':fontsdir='${escapedFontsDir}'[v_out]" -map "[v_out]" -map "0:a" -c:v libx264 -preset ultrafast -pix_fmt yuv420p -movflags +faststart -c:a copy "${outputPath}"`;

      console.log("Executing FFmpeg Pass 2 (captions)...");
      fs.writeFileSync(path.join(process.cwd(), 'ffmpeg-success.log'), pass2Command);
      
      // DIAGNOSTIC: Copy the SRT file and font directory to process.cwd() so we can inspect them
      try {
        fs.copyFileSync(srtPath, path.join(process.cwd(), 'last-captions.srt'));
      } catch (e) {}

      try {
        const { stdout, stderr } = await execPromise(pass2Command, { maxBuffer: 50 * 1024 * 1024 });
        fs.writeFileSync(path.join(process.cwd(), 'ffmpeg-pass2-output.log'), `STDOUT:\n${stdout}\n\nSTDERR:\n${stderr}`);
      } catch (e: any) {
        fs.writeFileSync(path.join(process.cwd(), 'ffmpeg-error.log'), `COMMAND:\n${pass2Command}\n\nERROR:\n${e.message.slice(-5000)}`);
        // If caption burn fails, fall back to the video without captions
        console.error("Caption burn failed, using video without captions");
        fs.copyFileSync(pass1Output, outputPath);
      }
      // Clean up pass1 intermediate file
      try { fs.unlinkSync(pass1Output); } catch(e) {}
    }

    if (isFree) {
      await prisma.user.update({
        where: { id: user.id },
        data: { exportCount: { increment: 1 } }
      });
    }

    const finalExportPath = path.join(tempDir, `final_${id}.mp4`);
    fs.copyFileSync(outputPath, finalExportPath);

    // Clean up temp files to prevent /tmp from accumulating
    try {
      fs.unlinkSync(outputPath);
      mainVideoPaths.forEach(p => { try { fs.unlinkSync(p); } catch(e) {} });
      try { fs.unlinkSync(srtPath); } catch(e) {}
      try { fs.rmSync(fontDir, { recursive: true, force: true }); } catch(e) {}
    } catch(e) {}

    // Mark job as completed
    fs.writeFileSync(statusPath, JSON.stringify({ status: 'completed' }));
    
      } catch (backgroundError: any) {
        console.error('Background Export error:', backgroundError);
        fs.writeFileSync(statusPath, JSON.stringify({ status: 'error', error: backgroundError.message }));
      }
    })();

  } catch (error: any) {
    console.error('Export request error:', error);
    if (!res.headersSent) {
      return res.status(500).json({ error: error.message });
    }
  }
}
