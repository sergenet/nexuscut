import type { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import path from 'path';
import os from 'os';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { id } = req.query;

  if (!id || typeof id !== 'string') {
    return res.status(400).json({ error: 'Missing Job ID' });
  }

  const tempDir = os.tmpdir();
  const finalPath = path.join(tempDir, `final_${id}.mp4`);

  if (!fs.existsSync(finalPath)) {
    return res.status(404).json({ error: 'File not found or expired' });
  }

  try {
    const stat = fs.statSync(finalPath);
    
    res.writeHead(200, {
      'Content-Type': 'video/mp4',
      'Content-Length': stat.size,
      'Content-Disposition': `attachment; filename="export_${id}.mp4"`
    });
    
    const readStream = fs.createReadStream(finalPath);
    readStream.pipe(res);
    
    // Optional: Delete the file after downloading to free up space
    // We listen to the 'close' event to ensure download is complete
    res.on('close', () => {
      try {
        fs.unlinkSync(finalPath);
        // Also delete the status file
        const statusPath = path.join(tempDir, `status_${id}.json`);
        if (fs.existsSync(statusPath)) {
          fs.unlinkSync(statusPath);
        }
      } catch (err) {
        console.error('Failed to cleanup temp file:', err);
      }
    });

  } catch (error: any) {
    console.error('Error serving download:', error);
    if (!res.headersSent) {
      return res.status(500).json({ error: 'Failed to serve download' });
    }
  }
}
