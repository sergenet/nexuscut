
import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'NexusCut vs NexusClips - Which is Better? | NexusCut',
  description: 'Compare NexusCut and NexusClips for TikTok and Shorts editing. Discover why top creators prefer NexusCut for AI background removal and 9:16 native editing.',
  openGraph: {
    title: 'NexusCut vs NexusClips - Which is Better? | NexusCut',
    description: 'Compare NexusCut and NexusClips for TikTok and Shorts editing. Discover why top creators prefer NexusCut for AI background removal and 9:16 native editing.',
    type: 'website',
  }
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
