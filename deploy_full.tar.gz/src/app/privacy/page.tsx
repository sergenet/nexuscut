import React from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-neutral-950 text-white font-sans flex flex-col">
      <Navigation />
      <main className="flex-grow pt-32 pb-24 px-6 max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-black mb-8">Privacy Policy</h1>
        <div className="prose prose-invert prose-lg text-neutral-300">
          <p>Last updated: {new Date().toLocaleDateString()}</p>
          
          <h2>1. Information We Collect</h2>
          <p>We collect information you provide directly to us when you create an account, use our services, or communicate with us. This includes your name, email address, payment information, and video content you upload for editing.</p>
          
          <h2>2. How We Use Your Information</h2>
          <p>We use the information we collect to operate, maintain, and provide you with the features and functionality of NexusCut. We also use it to communicate with you, process your transactions, and to detect and prevent fraud.</p>
          
          <h2>3. Information Sharing</h2>
          <p>We do not share your personal information with third parties except as described in this privacy policy, such as with our third-party service providers who help us operate our business (like Stripe for payments).</p>
          
          <h2>4. Data Security</h2>
          <p>We use appropriate technical and organizational measures designed to protect the personal information we process about you.</p>

          <h2>5. Contact Us</h2>
          <p>If you have any questions about this Privacy Policy, please contact us at support@nexuscut.io.</p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
