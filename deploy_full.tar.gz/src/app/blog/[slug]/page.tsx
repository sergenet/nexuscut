import React from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { blogPosts } from '@/lib/blogData';
import { notFound } from 'next/navigation';
import { ArrowLeft, Sparkles, FileText, Calendar } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export async function generateStaticParams() {
  return blogPosts.map((post) => ({
    slug: post.slug,
  }));
}

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = blogPosts.find((p) => p.slug === params.slug);

  if (!post) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white font-sans flex flex-col">
      <Navigation />
      
      <main className="flex-grow pt-32 pb-24 px-4 max-w-4xl mx-auto w-full">
        <Link href="/blog" className="inline-flex items-center text-gray-400 hover:text-white mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Blog
        </Link>
        
        <div className="mb-12">
          <div className="flex items-center gap-4 mb-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-fuchsia-500/10 text-fuchsia-400 rounded-full text-sm font-bold tracking-wide uppercase">
              <FileText className="w-4 h-4" /> {post.category}
            </div>
            <div className="text-gray-500 text-sm font-medium flex items-center gap-2">
              <Calendar className="w-4 h-4" /> {new Date(post.date).toLocaleDateString()}
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold mb-6 tracking-tight">
            {post.title}
          </h1>
          <p className="text-xl text-gray-400">
            {post.description}
          </p>
        </div>

        <div className="prose prose-invert prose-lg max-w-none prose-headings:text-fuchsia-400 prose-a:text-fuchsia-500 hover:prose-a:text-fuchsia-400">
          <ReactMarkdown>{post.content}</ReactMarkdown>
        </div>

        <div className="mt-16 bg-gradient-to-br from-gray-900 to-gray-950 border border-gray-800 rounded-2xl p-8 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-fuchsia-500/10 blur-3xl rounded-full"></div>
          <Sparkles className="w-10 h-10 text-fuchsia-500 mx-auto mb-4 relative z-10" />
          <h3 className="text-3xl font-extrabold mb-4 relative z-10">Stop Reading. Start Creating.</h3>
          <p className="text-gray-400 mb-8 max-w-lg mx-auto relative z-10">Put these strategies into practice immediately. NexusCut gives you the tools to edit faster and grow quicker.</p>
          <Link href="/editor" className="inline-flex px-10 py-4 bg-fuchsia-600 hover:bg-fuchsia-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-fuchsia-500/25 relative z-10">
            Start Editing Free
          </Link>
        </div>
      </main>

      <Footer />
    </div>
  );
}
