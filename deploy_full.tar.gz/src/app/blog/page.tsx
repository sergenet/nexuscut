import React from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { blogPosts } from '@/lib/blogData';
import { FileText, ArrowRight } from 'lucide-react';

export const metadata = {
  title: 'Blog - NexusCut',
  description: 'Tips, strategies, and guides on how to edit faster and grow quicker on TikTok, Shorts, and Reels.',
};

export default function BlogIndex() {
  return (
    <div className="min-h-screen bg-gray-950 text-white font-sans flex flex-col">
      <Navigation />
      
      <main className="flex-grow pt-32 pb-24 px-4 max-w-7xl mx-auto w-full">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-fuchsia-500/10 text-fuchsia-400 rounded-full text-sm font-bold tracking-wide uppercase mb-6">
            <FileText className="w-4 h-4" /> Articles
          </div>
          <h1 className="text-5xl md:text-6xl font-extrabold mb-6 tracking-tight">
            NexusCut <span className="text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-400 to-pink-500">Blog</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Insights on AI video editing, retention strategies, and the creator economy.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <Link 
              key={post.slug} 
              href={`/blog/${post.slug}`}
              className="bg-gray-900 border border-gray-800 rounded-2xl p-6 hover:border-fuchsia-500/50 hover:bg-gray-800/50 transition-all group flex flex-col h-full"
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold text-fuchsia-400 uppercase tracking-wider">{post.category}</span>
                <span className="text-xs text-gray-500">{new Date(post.date).toLocaleDateString()}</span>
              </div>
              <h2 className="text-xl font-bold mb-3 group-hover:text-fuchsia-400 transition-colors">{post.title}</h2>
              <p className="text-gray-400 text-sm mb-6 flex-grow">{post.description}</p>
              <div className="flex items-center text-fuchsia-400 font-bold text-sm">
                Read Article <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          ))}
        </div>
      </main>

      <Footer />
    </div>
  );
}
