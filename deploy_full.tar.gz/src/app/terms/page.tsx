import React from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-neutral-950 text-white font-sans flex flex-col">
      <Navigation />
      <main className="flex-grow pt-32 pb-24 px-6 max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-black mb-8">Terms of Service</h1>
        <div className="prose prose-invert prose-lg text-neutral-300">
          <p>Last updated: {new Date().toLocaleDateString()}</p>
          <h2>1. Introduction</h2>
          <p>Welcome to NexusCut. By accessing our website and using our video editing services, you agree to be bound by these Terms of Service.</p>
          
          <h2>2. Use License</h2>
          <p>Permission is granted to temporarily download one copy of the materials (information or software) on NexusCut's website for personal, non-commercial transitory viewing only.</p>
          
          <h2>3. User Content</h2>
          <p>You retain all your ownership rights in your User Content. However, by submitting User Content to NexusCut, you hereby grant NexusCut a worldwide, non-exclusive, royalty-free, sublicenseable and transferable license to use, reproduce, distribute, prepare derivative works of, display, and perform the User Content in connection with the Service.</p>

          <h2>4. Disclaimer</h2>
          <p>The materials on NexusCut's website are provided on an 'as is' basis. NexusCut makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
