
import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Free AI TikTok Video Editor | NexusCut',
  description: 'Edit viral TikTok videos in seconds with our free AI TikTok video editor. Auto-captions, remove background, and export perfect 9:16 vertical videos.',
  openGraph: {
    title: 'Free AI TikTok Video Editor | NexusCut',
    description: 'Edit viral TikTok videos in seconds with our free AI TikTok video editor. Auto-captions, remove background, and export perfect 9:16 vertical videos.',
    type: 'website',
  }
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
