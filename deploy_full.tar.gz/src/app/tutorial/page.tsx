import React from 'react';
import Link from 'next/link';
import { ArrowLeft, BookOpen, Sparkles, Scissors, Wand2, Type, Music, Download, Camera, LayoutDashboard, MonitorPlay } from 'lucide-react';

export default function TutorialPage() {
  return (
    <div className="min-h-screen bg-black text-neutral-300 font-sans">
      {/* Navbar */}
      <nav className="h-16 bg-neutral-950 border-b border-neutral-800 flex items-center px-8 sticky top-0 z-50">
        <Link href="/editor" className="flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors font-medium">
          <ArrowLeft className="w-5 h-5" />
          Back to Editor
        </Link>
        <div className="mx-auto flex items-center gap-3">
          <BookOpen className="w-6 h-6 text-white" />
          <h1 className="text-xl font-bold text-white tracking-tight">NexusCut Beginner's Guide</h1>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        <header className="mb-16 text-center">
          <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-6 tracking-tight">
            How to Edit Your First Video with <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-purple-500">NexusCut</span>
          </h2>
          <p className="text-xl text-neutral-400">
            Complete newbie? No problem. Follow this step-by-step guide to go from zero to a fully exported, viral-ready video.
          </p>
        </header>

        <div className="space-y-12">
          
          {/* Step 1 */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-indigo-500 text-white rounded-full flex items-center justify-center font-bold text-xl">1</div>
              <h3 className="text-2xl font-bold text-white">Starting Your Project & Setting the Canvas</h3>
            </div>
            <div className="space-y-3 text-lg text-neutral-300 pl-14">
              <p>Before you add any videos, you need to tell NexusCut what kind of video you are making.</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Look at the top bar in the editor. You'll see an aspect ratio dropdown (usually defaults to <strong>9:16</strong>).</li>
                <li><strong>9:16</strong> is perfect for TikTok, YouTube Shorts, and Instagram Reels (tall videos).</li>
                <li><strong>16:9</strong> is for standard YouTube videos or TV (wide videos).</li>
                <li><strong>1:1</strong> is for square Instagram posts.</li>
                <li>Select the one you need. The black Canvas in the center will immediately change its shape to match.</li>
              </ul>
            </div>
          </section>

          {/* Step 2 */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-indigo-500 text-white rounded-full flex items-center justify-center font-bold text-xl">2</div>
              <h3 className="text-2xl font-bold text-white">Getting Your Video into NexusCut</h3>
            </div>
            <div className="space-y-3 text-lg text-neutral-300 pl-14">
              <p>You can't edit without footage! In the top-left corner (in the Sidebar), you'll see the <strong>Media</strong> tab.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800">
                  <h4 className="font-bold text-white flex items-center gap-2 mb-2"><Download className="w-5 h-5 text-indigo-400" /> Option A: Upload Files</h4>
                  <p className="text-sm">If you already have a video recorded on your phone or computer, simply click the <strong>Upload</strong> area in the Media tab and select your video or audio file.</p>
                </div>
                <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800">
                  <h4 className="font-bold text-white flex items-center gap-2 mb-2"><Camera className="w-5 h-5 text-emerald-400" /> Option B: Use Your Camera</h4>
                  <p className="text-sm">Don't have a video yet? Click the <strong>Camera</strong> icon in the Media tab. You can instantly record yourself using your webcam and microphone right inside the browser. When you click Stop, it will automatically save to your Media Library!</p>
                </div>
              </div>
            </div>
          </section>

          {/* Step 3 */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-indigo-500 text-white rounded-full flex items-center justify-center font-bold text-xl">3</div>
              <h3 className="text-2xl font-bold text-white">Building the Timeline (Cutting & Trimming)</h3>
            </div>
            <div className="space-y-3 text-lg text-neutral-300 pl-14">
              <p>The Timeline (the bottom half of the screen) is where the actual editing happens.</p>
              <ul className="list-decimal pl-6 space-y-2">
                <li>Once your video is in the Media Library, click and <strong>drag it down</strong> onto the track labeled <strong>Video 1</strong> in the Timeline.</li>
                <li>Your video is now a "clip" on the timeline. If you press the Play button (or Spacebar), you'll see it play in the Canvas above.</li>
                <li><strong>To trim the beginning or end:</strong> Hover your mouse over the left or right edge of the clip until your cursor changes. Click and drag inwards to trim off the boring parts.</li>
                <li><strong>To split a clip in half:</strong> Click on the spot in the timeline where you want to make a cut to move the red line (the Playhead) there. Then click the <strong>Split (Scissors)</strong> icon on the toolbar just above the timeline. You can now delete one half by selecting it and pressing Backspace/Delete.</li>
              </ul>
            </div>
          </section>

          {/* Step 4 */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-indigo-500 text-white rounded-full flex items-center justify-center font-bold text-xl">4</div>
              <h3 className="text-2xl font-bold text-white">Positioning & Resizing</h3>
            </div>
            <div className="space-y-3 text-lg text-neutral-300 pl-14">
              <p>Sometimes your video doesn't perfectly fit the Canvas (for example, if you imported a wide video into a tall 9:16 Canvas).</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Click on your video clip in the Timeline to select it.</li>
                <li>Look at the <strong>Canvas</strong> (the center preview window). You'll see a bounding box around your video.</li>
                <li>Click and drag the video to move it around.</li>
                <li>Grab any of the corner handles and drag to resize the video until it fills the screen perfectly.</li>
              </ul>
            </div>
          </section>

          {/* Step 5 */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-indigo-500 text-white rounded-full flex items-center justify-center font-bold text-xl">5</div>
              <h3 className="text-2xl font-bold text-white">Using AI Magic (Auto-Captions & Background Removal)</h3>
            </div>
            <div className="space-y-3 text-lg text-neutral-300 pl-14">
              <p>This is where NexusCut shines. Instead of doing things manually, let our AI help.</p>
              <ul className="list-disc pl-6 space-y-3">
                <li><strong>Auto-Captions:</strong> In the left Sidebar, click the <strong>AI Magic</strong> tab (the wand icon). Click "Generate Captions". The AI will listen to your video and create perfectly timed subtitles. You can click on these subtitles in the timeline to change their font, color, and style in the Properties panel on the right.</li>
                <li><strong>Remove Background:</strong> Also in the AI Magic tab. Select your video clip, click "Remove Background", and watch as the AI perfectly cuts you out without needing a green screen! You can then drag an image or another video onto the timeline *underneath* your clip to create a new background.</li>
                <li><strong>Magic Cuts:</strong> Uploaded a 10-minute long vlog? Click Magic Cuts, and the AI will analyze the video to automatically find and extract the most exciting 30-second highlight to turn into a short.</li>
              </ul>
            </div>
          </section>

          {/* Step 6 */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-indigo-500 text-white rounded-full flex items-center justify-center font-bold text-xl">6</div>
              <h3 className="text-2xl font-bold text-white">Adding Text & Titles</h3>
            </div>
            <div className="space-y-3 text-lg text-neutral-300 pl-14">
              <p>Want to add a big title or manual text?</p>
              <ul className="list-decimal pl-6 space-y-2">
                <li>Open the <strong>Text</strong> tab in the sidebar (the "T" icon).</li>
                <li>Click <strong>Add Title</strong> or choose a preset style. A text clip will appear on your timeline.</li>
                <li>Look at the <strong>Properties Panel</strong> on the right side of the screen. Here you can change what the text says, pick a font, change colors, and add shadows.</li>
                <li>Drag the text on the Canvas to move it, and drag the text clip's edges on the Timeline to control how long it stays on screen.</li>
              </ul>
            </div>
          </section>

          {/* Step 7 */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-indigo-500 text-white rounded-full flex items-center justify-center font-bold text-xl">7</div>
              <h3 className="text-2xl font-bold text-white">Audio & AI Voice Generation (TTS)</h3>
            </div>
            <div className="space-y-3 text-lg text-neutral-300 pl-14">
              <p>Great video needs great audio. Here is how to manage it:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Adjust Volume:</strong> Click any clip (video or audio) on the timeline. The Properties panel on the right will show a volume slider. You can turn the volume up, down, or mute it entirely.</li>
                <li><strong>AI Voice (TTS):</strong> Don't want to use your own voice? Open the <strong>Audio</strong> tab in the sidebar. Look for the "AI Voice Generator". Type your script into the box, pick a voice actor (like Alloy or Echo), and click Generate. A professional voiceover clip will instantly drop onto your timeline!</li>
              </ul>
            </div>
          </section>
          
          {/* Step 8 */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-indigo-500 text-white rounded-full flex items-center justify-center font-bold text-xl">8</div>
              <h3 className="text-2xl font-bold text-white">Transitions & Effects</h3>
            </div>
            <div className="space-y-3 text-lg text-neutral-300 pl-14">
              <p>Add some polish to your video by adding transitions between clips.</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Open the <strong>Transitions</strong> tab in the sidebar.</li>
                <li>If you have two video clips next to each other on the timeline, simply drag a transition (like a Fade or a Wipe) and drop it right between them. If you want audio on your transitions, you can add your choice of audio manually from the Audio tab.</li>
                <li>Open the <strong>Effects</strong> tab to find visual filters like VHS or Glitch, which you can drag onto any video clip to change its look.</li>
              </ul>
            </div>
          </section>

          {/* Step 9 */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-indigo-500 text-white rounded-full flex items-center justify-center font-bold text-xl">9</div>
              <h3 className="text-2xl font-bold text-white">Saving and Loading Your Project</h3>
            </div>
            <div className="space-y-3 text-lg text-neutral-300 pl-14">
              <p>Don't lose your hard work! NexusCut runs in the browser, so you should save your project to continue later.</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>To save your current progress, click the <strong>Save Local</strong> button at the top of the editor. This will download a small project file to your computer.</li>
                <li>When you come back later to finish editing, simply click <strong>Load Local</strong> and select that project file. Your entire timeline, clips, and edits will instantly restore exactly how you left them!</li>
              </ul>
            </div>
          </section>

          {/* Step 10 */}
          <section className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-indigo-500 text-white rounded-full flex items-center justify-center font-bold text-xl">10</div>
              <h3 className="text-2xl font-bold text-white">Exporting Your Masterpiece</h3>
            </div>
            <div className="space-y-3 text-lg text-neutral-300 pl-14">
              <p>Once you are happy with how your video looks and sounds when you press play, it's time to save it as a final video file!</p>
              <ul className="list-decimal pl-6 space-y-2">
                <li>Look at the top right corner of the screen for the big <strong>Export Video</strong> button.</li>
                <li>Click it! A progress bar will appear.</li>
                <li>Our powerful cloud rendering engine will take all your clips, text, audio, and effects and bake them into a single high-quality MP4 file.</li>
                <li>Once it reaches 100%, the file will automatically download to your computer. You are now ready to post it to social media!</li>
              </ul>
            </div>
          </section>

        </div>

        <div className="mt-20 text-center pb-20">
          <Link href="/editor" className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-indigo-600 text-white font-bold text-lg hover:bg-indigo-500 transition-all shadow-[0_0_40px_rgba(79,70,229,0.4)] hover:-translate-y-1">
            Start Your First Project
          </Link>
        </div>

      </main>
    </div>
  );
}
