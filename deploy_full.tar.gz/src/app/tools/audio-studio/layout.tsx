import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'AI Audio Studio & Voiceover - NexusCut',
  description: 'Generate ultra-realistic AI voiceovers and edit audio tracks effortlessly for your videos.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">Professional Sound Design with the AI Audio Studio</h2>
                <p className="mb-4 leading-relaxed">Great video with terrible audio will always underperform. That is why we built the AI Audio Studio—your all-in-one solution for voiceovers, sound effects, and audio mixing. Whether you are running a faceless YouTube channel, creating TikTok storytelling videos, or producing professional marketing materials, our hyper-realistic text-to-speech engine is a game changer.</p>
        <p className="mb-4 leading-relaxed">Simply type or paste your script, and our AI will generate a voiceover that sounds completely human. We offer dozens of voices across various accents, tones, and energy levels. Need an enthusiastic narrator for a top-10 list? Or a calm, authoritative voice for a documentary? You can select the exact vibe you need. Furthermore, the audio studio automatically levels your tracks, removes background noise, and lets you layer sound effects effortlessly.</p>
        <p className="mb-4 leading-relaxed">Do not let expensive microphones or a lack of recording space hold you back. With NexusCut's Audio Studio, you can produce broadcast-quality sound directly from your browser. The tool also supports automatic audio ducking—lowering your background music automatically when the voiceover speaks. Level up your production value today and keep your audience fully immersed with pristine, professional-grade audio.</p>
      </section>
      <Footer />
    </>
  );
}
