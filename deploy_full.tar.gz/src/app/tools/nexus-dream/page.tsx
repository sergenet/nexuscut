"use client";

import React, { useState } from "react";
import { Sparkles, Layers, LayoutTemplate, MousePointer2, Loader2, ArrowRight } from "lucide-react";
import Link from "next/link";

export default function NexusDreamPage() {
  const [status, setStatus] = useState<"idle" | "loading" | "ready">("idle");

  const launchDream = () => {
    setStatus("loading");
    setTimeout(() => {
      setStatus("ready");
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-neutral-950 pt-32 pb-24 overflow-hidden relative">
      
      {/* Background decorations */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-fuchsia-600/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Left: Copy */}
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 text-white rounded-full text-sm font-bold tracking-wide uppercase mb-6 backdrop-blur-md">
              <Sparkles className="w-4 h-4 text-fuchsia-400" /> The Future of Design
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-white mb-6 tracking-tight leading-tight">
              Meet <span className="text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-400 to-blue-500">NexusDream</span> 2.0
            </h1>
            <p className="text-xl text-neutral-400 mb-10 leading-relaxed">
              An infinite canvas powered by generative AI. Design thumbnails, social posts, and branding assets simply by describing them. No layers or complex tools required.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              {status === "idle" ? (
                <button 
                  onClick={launchDream}
                  className="bg-white text-black hover:bg-neutral-200 font-bold py-4 px-8 rounded-full transition-colors flex items-center justify-center gap-2 text-lg"
                >
                  <Sparkles className="w-5 h-5" /> Launch Canvas
                </button>
              ) : status === "loading" ? (
                <button disabled className="bg-neutral-800 text-neutral-400 font-bold py-4 px-8 rounded-full flex items-center justify-center gap-2 text-lg">
                  <Loader2 className="w-5 h-5 animate-spin" /> Initializing AI Engine...
                </button>
              ) : (
                <div className="bg-green-500/10 border border-green-500/30 text-green-400 px-6 py-4 rounded-2xl flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="font-semibold">Engine Ready. Open in desktop app for full experience.</span>
                </div>
              )}
              
              <Link href="/templates" className="bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-white font-bold py-4 px-8 rounded-full transition-all flex items-center justify-center gap-2 text-lg">
                <LayoutTemplate className="w-5 h-5" /> Browse Templates
              </Link>
            </div>

            <div className="mt-16 grid grid-cols-2 gap-8">
              <div>
                <Layers className="w-8 h-8 text-fuchsia-400 mb-4" />
                <h4 className="text-white font-bold mb-2">Smart Layouts</h4>
                <p className="text-sm text-neutral-500">Auto-arranges text and images for maximum visual hierarchy.</p>
              </div>
              <div>
                <MousePointer2 className="w-8 h-8 text-blue-400 mb-4" />
                <h4 className="text-white font-bold mb-2">Generative Fill</h4>
                <p className="text-sm text-neutral-500">Erase or replace anything in your image with a simple prompt.</p>
              </div>
            </div>
          </div>

          {/* Right: Interactive Mockup */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-fuchsia-500 to-blue-500 rounded-3xl blur-2xl opacity-20 animate-pulse" />
            <div className="bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl relative overflow-hidden aspect-[4/3] flex flex-col">
              
              {/* Fake UI Header */}
              <div className="h-12 bg-neutral-950 border-b border-neutral-800 flex items-center px-4 justify-between">
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500"></div>
                  <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                  <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                </div>
                <div className="text-xs font-semibold text-neutral-500">Untitled Design - NexusDream</div>
                <div className="w-16"></div>
              </div>

              {/* Fake UI Body */}
              <div className="flex-1 flex">
                {/* Fake Sidebar */}
                <div className="w-16 border-r border-neutral-800 bg-neutral-950/50 flex flex-col items-center py-4 gap-4">
                  <div className="w-8 h-8 rounded bg-neutral-800" />
                  <div className="w-8 h-8 rounded bg-neutral-800" />
                  <div className="w-8 h-8 rounded bg-neutral-800" />
                  <div className="w-8 h-8 rounded bg-fuchsia-600 shadow-[0_0_15px_rgba(192,38,211,0.5)]" />
                </div>
                
                {/* Fake Canvas */}
                <div className="flex-1 bg-black p-6 relative">
                  <div className="w-full h-full bg-neutral-900 rounded-xl border border-neutral-800 flex flex-col items-center justify-center relative overflow-hidden">
                    <img 
                      src="https://source.unsplash.com/800x600/?abstract,neon" 
                      alt="Canvas" 
                      className="w-full h-full object-cover opacity-60"
                    />
                    <div className="absolute bottom-6 w-[80%] max-w-sm bg-neutral-950/80 backdrop-blur-md border border-neutral-700 rounded-2xl p-2 flex items-center shadow-2xl">
                      <div className="flex-1 px-3 text-sm text-neutral-400">Add neon typography saying "VIBE"...</div>
                      <div className="w-8 h-8 bg-white rounded-xl flex items-center justify-center">
                        <ArrowRight className="w-4 h-4 text-black" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
