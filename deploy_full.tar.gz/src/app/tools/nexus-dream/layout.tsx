import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Nexus Dream: AI Video Generation - NexusCut',
  description: 'Generate high-quality video clips purely from text prompts with Nexus Dream. The future of B-roll.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">The Future of Content: Nexus Dream Text-to-Video</h2>
                <p className="mb-4 leading-relaxed">Imagine being able to type a sentence and instantly receive a high-definition video clip matching your exact description. That is the power of Nexus Dream. Built on the latest generative AI video models, this tool allows you to create custom B-roll, cinematic establishing shots, and surreal visual effects purely from text prompts.</p>
        <p className="mb-4 leading-relaxed">For video editors and creators, finding the right stock footage can be incredibly frustrating and expensive. Nexus Dream solves this by generating bespoke video assets on demand. Need a drone shot of a neon city at night? Or a close-up of coffee pouring in slow motion? Just type it in. The AI understands complex motion dynamics, lighting, and camera angles, delivering incredibly realistic results.</p>
        <p className="mb-4 leading-relaxed">This technology is a massive competitive advantage for YouTubers, marketers, and storytellers. You are no longer limited by your camera gear or travel budget. Your imagination is the only limit. Generate your unique footage, drop it into the NexusCut editor, add some auto-captions, and you have a viral masterpiece ready to publish.</p>
      </section>
      <Footer />
    </>
  );
}
