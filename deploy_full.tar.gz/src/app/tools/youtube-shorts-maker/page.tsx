import React from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { PlaySquare, Scissors, MonitorPlay } from 'lucide-react';

export default function YouTubeShortsMakerPage() {
  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col font-sans">
      <Navigation />
      
      <main className="flex-grow pt-32 pb-20 px-4 md:px-8 max-w-5xl mx-auto w-full text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold mb-6 tracking-tight">
          YouTube Shorts <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500">Maker</span>
        </h1>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-12">
          Repurpose your podcasts, streams, and long-form videos into engaging Shorts that drive subscribers. Completely free.
        </p>

        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 mb-16 shadow-2xl">
          <div className="max-w-xl mx-auto text-center">
            <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <PlaySquare className="w-10 h-10 text-red-500" />
            </div>
            <h2 className="text-2xl font-bold mb-4">Create Your First Short</h2>
            <p className="text-gray-400 mb-8">
              Upload your 16:9 video, and our AI will automatically center the speaker, format it to 9:16, and add engaging captions.
            </p>
            <Link href="/editor" className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white font-bold px-8 py-4 rounded-full transition-all text-lg shadow-lg shadow-red-600/20">
              Start Creating
              <Scissors className="w-5 h-5" />
            </Link>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 text-left">
          <div className="p-6 bg-gray-900 rounded-xl border border-gray-800">
            <h3 className="text-xl font-bold mb-2 text-white">Auto-Reframing</h3>
            <p className="text-gray-400">Our AI tracks the main subject and automatically centers them for the perfect vertical format.</p>
          </div>
          <div className="p-6 bg-gray-900 rounded-xl border border-gray-800">
            <h3 className="text-xl font-bold mb-2 text-white">B-Roll Injection</h3>
            <p className="text-gray-400">Keep viewers hooked by seamlessly overlaying relevant B-Roll automatically.</p>
          </div>
          <div className="p-6 bg-gray-900 rounded-xl border border-gray-800">
            <h3 className="text-xl font-bold mb-2 text-white">Shorts SEO</h3>
            <p className="text-gray-400">Export with optimized titles and metadata templates tailored for the Shorts algorithm.</p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
