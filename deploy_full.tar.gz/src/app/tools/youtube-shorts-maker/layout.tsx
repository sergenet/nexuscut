import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'YouTube Shorts Maker & Editor - NexusCut',
  description: 'The ultimate editor for YouTube Shorts. Repurpose long-form content, add captions, and export fast.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">The Ultimate Toolkit for YouTube Shorts Creation</h2>
                <p className="mb-4 leading-relaxed">YouTube Shorts is currently the fastest way to grow a channel and reach new audiences. Our YouTube Shorts Maker is a purpose-built environment optimized specifically for the 9:16 vertical format. It combines all the essential tools—auto-captions, B-roll insertion, automatic reframing, and viral hooks—into one seamless workflow.</p>
        <p className="mb-4 leading-relaxed">One of the most powerful features is our AI-driven long-to-short repurposing. You can upload a long-form podcast or video essay, and the AI will automatically identify the most engaging moments, crop the video to keep the speaker centered, and generate bite-sized Shorts complete with animated subtitles. What used to take hours of manual cutting can now be done in minutes.</p>
        <p className="mb-4 leading-relaxed">The editor is incredibly fast, allowing you to quickly trim dead air, insert trending sound effects, and apply color grading. Exporting is lightning fast, giving you a perfectly formatted MP4 file ready to upload directly to YouTube. Maximize your output, repurpose your existing content library, and dominate the YouTube Shorts algorithm with the most efficient editor on the market.</p>
      </section>
      <Footer />
    </>
  );
}
