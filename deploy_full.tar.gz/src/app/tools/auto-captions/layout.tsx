import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Auto Captions & Subtitles Free - NexusCut',
  description: 'Automatically transcribe and add captions to your videos with 99% accuracy. Perfect for social media.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">Save Hours of Editing with AI Auto Captions</h2>
                <p className="mb-4 leading-relaxed">Typing out subtitles manually is one of the most tedious tasks in video editing. Our Auto Captions tool eliminates this bottleneck entirely. Powered by state-of-the-art speech recognition technology, NexusCut analyzes your video's audio track and generates perfectly timed, highly accurate captions in seconds.</p>
        <p className="mb-4 leading-relaxed">Over 80% of social media videos are watched on mute. If you do not have captions, you are instantly losing a massive portion of your potential audience. Our tool ensures your message is heard, even when the sound is off. It supports multiple languages, making it easy to localize your content and reach a global audience.</p>
        <p className="mb-4 leading-relaxed">Once the auto-captions are generated, you have complete creative control. You can edit the text for spelling, split or merge caption blocks for better pacing, and apply custom styling to match your brand. Our intelligent engine even detects pauses and emphasizes keywords automatically. Stop wasting hours scrubbing through the timeline. Let our AI handle the heavy lifting so you can focus on creating more amazing content.</p>
      </section>
      <Footer />
    </>
  );
}
