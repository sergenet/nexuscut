import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Free AI Image Generator - NexusCut',
  description: 'Generate stunning hyper-realistic AI images from text prompts instantly. Perfect for YouTube thumbnails, backgrounds, and creative assets.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">Unlock Your Creativity with the AI Image Generator</h2>
                <p className="mb-4 leading-relaxed">Welcome to the ultimate AI Image Generator designed specifically for video creators, YouTubers, and social media influencers. In today's fast-paced digital landscape, having eye-catching thumbnails and background assets is crucial for maximizing your click-through rates (CTR) and viewer retention. Our AI-powered image generation tool allows you to type a simple text prompt and instantly receive high-resolution, hyper-realistic, or stylized artwork in seconds.
        
Whether you need a cinematic background for your next YouTube essay, a vibrant anime-style illustration for a TikTok story, or a photorealistic element to drop into your video timeline, this tool has you covered. Forget spending hours searching stock photo sites for the perfect image. Simply describe what you want, choose your aspect ratio, and let our advanced neural networks do the rest.</p>
        <p className="mb-4 leading-relaxed">We have fine-tuned our model to understand complex creative instructions, ensuring that lighting, composition, and subject matter align perfectly with modern aesthetic trends. It is entirely free to use and integrated directly into your NexusCut workflow. Once generated, you can download your image in 4K resolution or drop it right into the timeline. Start generating today and elevate your visual storytelling to new heights without needing any graphic design skills!</p>
      </section>
      <Footer />
    </>
  );
}
