"use client";

import React, { useState } from "react";
import { Upload, Video, Wand2, ArrowRight, Sparkles, Play, SlidersHorizontal, Loader2, Download } from "lucide-react";

const EFFECTS = [
  { id: "glitch", name: "Cyber Glitch", color: "from-cyan-500 to-blue-500" },
  { id: "vhs", name: "Retro VHS", color: "from-orange-500 to-amber-500" },
  { id: "neon", name: "Neon Glow", color: "from-fuchsia-500 to-pink-500" },
  { id: "film", name: "35mm Film", color: "from-neutral-400 to-neutral-600" },
  { id: "blur", name: "Motion Blur", color: "from-indigo-500 to-purple-500" },
  { id: "comic", name: "Comic Book", color: "from-yellow-400 to-red-500" },
];

export default function VideoEffectsPage() {
  const [file, setFile] = useState<File | null>(null);
  const [activeEffect, setActiveEffect] = useState<string>("glitch");
  const [status, setStatus] = useState<"idle" | "rendering" | "done">("idle");
  const [intensity, setIntensity] = useState(50);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const applyEffect = () => {
    if (!file) return;
    setStatus("rendering");
    
    setTimeout(() => {
      setStatus("done");
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-neutral-950 pt-32 pb-24">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-cyan-500/10 text-cyan-400 rounded-full text-sm font-bold tracking-wide uppercase mb-6">
            <Wand2 className="w-4 h-4" /> Cinematic VFX
          </div>
          <h1 className="text-5xl md:text-6xl font-black text-white mb-6 tracking-tight">
            Pro Video <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Effects</span>
          </h1>
          <p className="text-xl text-neutral-400 max-w-2xl mx-auto">
            Apply Hollywood-grade color grading, filters, and dynamic visual effects with a single click.
          </p>
        </div>

        {/* Workspace */}
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          
          {/* Left Panel: Effects Library */}
          <div className="xl:col-span-1 bg-neutral-900 border border-neutral-800 rounded-3xl p-6 h-[600px] flex flex-col">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400" /> Effects Library
            </h3>
            
            <div className="flex-1 overflow-y-auto pr-2 space-y-3 custom-scrollbar">
              {EFFECTS.map(effect => (
                <button
                  key={effect.id}
                  onClick={() => { setActiveEffect(effect.id); setStatus("idle"); }}
                  className={`w-full text-left p-4 rounded-xl border transition-all ${
                    activeEffect === effect.id 
                      ? 'bg-neutral-800 border-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.2)]' 
                      : 'bg-neutral-950 border-neutral-800 hover:border-neutral-600'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-white">{effect.name}</span>
                    <div className={`w-3 h-3 rounded-full bg-gradient-to-br ${effect.color}`} />
                  </div>
                  <p className="text-xs text-neutral-500">Apply instantly</p>
                </button>
              ))}
            </div>
          </div>

          {/* Center Panel: Canvas */}
          <div className="xl:col-span-2">
            <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl relative h-[600px] flex flex-col">
              
              <div className="flex-1 p-8 flex items-center justify-center relative bg-black">
                {!file ? (
                  <label 
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={handleDrop}
                    className="w-full h-full border-2 border-dashed border-neutral-700 hover:border-cyan-500 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-colors bg-neutral-950/50 group"
                  >
                    <div className="w-20 h-20 bg-neutral-800 group-hover:bg-cyan-500/20 rounded-full flex items-center justify-center mb-6 transition-colors">
                      <Video className="w-10 h-10 text-neutral-400 group-hover:text-cyan-500 transition-colors" />
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-2">Upload Video</h3>
                    <p className="text-neutral-500">MP4, MOV, or WEBM</p>
                    <input type="file" accept="video/*" className="hidden" onChange={(e) => setFile(e.target.files?.[0] || null)} />
                  </label>
                ) : (
                  <div className="relative w-full h-full flex items-center justify-center">
                    
                    {status === "done" ? (
                      <div className="relative w-full h-full overflow-hidden rounded-xl border border-neutral-800 group">
                        {/* Placeholder video layout with CSS filter effect */}
                        <div className="absolute inset-0 bg-neutral-800 flex items-center justify-center" 
                             style={{ filter: activeEffect === 'glitch' ? 'hue-rotate(90deg) contrast(1.5)' : activeEffect === 'vhs' ? 'sepia(0.5) blur(1px)' : 'none' }}>
                          <Video className="w-24 h-24 text-neutral-600" />
                          <div className="absolute inset-x-0 bottom-4 text-center">
                            <span className="bg-black/80 text-cyan-400 px-4 py-2 rounded-lg font-mono text-sm tracking-widest uppercase">
                              {EFFECTS.find(e => e.id === activeEffect)?.name} ACTIVE
                            </span>
                          </div>
                        </div>
                        
                        {/* Play button overlay */}
                        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button className="w-20 h-20 bg-cyan-600/90 hover:bg-cyan-500 backdrop-blur-md rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(6,182,212,0.5)] hover:scale-110 transition-transform">
                            <Play className="w-8 h-8 text-white ml-2" />
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Video className="w-16 h-16 text-neutral-600 mx-auto mb-4" />
                        <p className="text-white font-semibold mb-2">{file.name}</p>
                        <p className="text-neutral-500 text-sm mb-6">Ready to apply {EFFECTS.find(e => e.id === activeEffect)?.name}</p>
                      </div>
                    )}

                    {/* Rendering Overlay */}
                    {status === "rendering" && (
                      <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center z-20 rounded-xl">
                        <Loader2 className="w-12 h-12 text-cyan-500 animate-spin mb-4" />
                        <h3 className="text-xl font-bold text-white mb-2">Rendering Engine Active</h3>
                        <p className="text-cyan-400 text-sm font-mono tracking-widest mb-4">PROCESSING FRAMES</p>
                        <div className="w-64 h-1 bg-neutral-800 rounded-full overflow-hidden">
                          <div className="h-full bg-cyan-500 animate-[loading_2s_ease-in-out_infinite]" style={{ width: "50%" }}></div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Panel: Controls */}
          <div className="xl:col-span-1 bg-neutral-900 border border-neutral-800 rounded-3xl p-6 flex flex-col h-[600px]">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <SlidersHorizontal className="w-5 h-5 text-cyan-400" /> Controls
            </h3>
            
            <div className="flex-1 space-y-8">
              <div>
                <div className="flex justify-between items-center mb-3">
                  <label className="text-sm font-semibold text-neutral-400">Effect Intensity</label>
                  <span className="text-xs font-mono text-cyan-400">{intensity}%</span>
                </div>
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  value={intensity}
                  onChange={(e) => setIntensity(parseInt(e.target.value))}
                  className="w-full accent-cyan-500" 
                />
              </div>

              <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800">
                <p className="text-xs text-neutral-500 leading-relaxed">
                  <span className="text-white font-bold block mb-1">Hardware Acceleration</span>
                  NexusCut automatically utilizes WebGL and GPU processing to render effects in real-time.
                </p>
              </div>
            </div>

            <div className="pt-6 border-t border-neutral-800">
              {status === "done" ? (
                <button 
                  onClick={() => { setStatus("idle"); setFile(null); }}
                  className="w-full bg-neutral-800 hover:bg-neutral-700 text-white font-bold py-4 rounded-xl transition-all shadow-lg flex items-center justify-center gap-2 mb-3"
                >
                  Reset
                </button>
              ) : null}
              
              <button 
                onClick={applyEffect}
                disabled={!file || status !== "idle"}
                className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {status === "done" ? <Download className="w-5 h-5" /> : <Wand2 className="w-5 h-5" />}
                {status === "idle" ? "Apply Effect" : status === "rendering" ? "Rendering..." : "Export Video"}
              </button>
            </div>
          </div>

        </div>
      </div>
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(0,0,0,0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255,255,255,0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255,255,255,0.2);
        }
      `}} />
    </div>
  );
}
