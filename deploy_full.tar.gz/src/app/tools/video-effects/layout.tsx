import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Free Video Effects & Filters - NexusCut',
  description: 'Apply cinematic video effects, transitions, and color grading filters to your footage in one click.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">Transform Your Footage with Cinematic Video Effects</h2>
                <p className="mb-4 leading-relaxed">Raw footage rarely looks perfect straight out of the camera. The Video Effects tool provides a comprehensive suite of cinematic filters, color grading presets, and dynamic visual effects to elevate your content from amateur to professional in seconds.</p>
        <p className="mb-4 leading-relaxed">Whether you want to add a retro VHS glitch for a stylized edit, apply a moody cinematic LUT to a short film, or use dynamic zoom effects to emphasize a punchline, our library has everything you need. Color grading is made simple with our one-click presets, adjusting the contrast, saturation, and temperature to give your video a cohesive, polished look.</p>
        <p className="mb-4 leading-relaxed">Beyond colors, you can add dynamic overlays like film grain, light leaks, and lens flares to add texture and depth to your scenes. All effects are hardware-accelerated, meaning you get real-time playback in the browser without any annoying lag. Give your videos that premium, studio-quality finish and keep your audience visually stimulated from the first frame to the last.</p>
      </section>
      <Footer />
    </>
  );
}
