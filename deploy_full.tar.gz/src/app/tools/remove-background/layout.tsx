import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Remove Video Background AI - NexusCut',
  description: 'Instantly remove the background from any video without a green screen. Fast, free, and accurate.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">Green Screen Magic Without the Green Screen</h2>
                <p className="mb-4 leading-relaxed">Shooting with a green screen requires perfect lighting, expensive equipment, and a lot of space. Our Remove Background tool uses advanced AI rotoscoping to magically separate you from your background with a single click—no green screen required.</p>
        <p className="mb-4 leading-relaxed">Whether you are filming in a messy bedroom, an office, or outdoors, the AI intelligently detects human subjects and creates a perfect cutout. You can then replace your background with anything: an epic gaming footage clip, a professional studio setup, a presentation slide, or an AI-generated image. This is essential for reaction videos, gaming streams, and educational content where you need to overlay yourself on top of other media.</p>
        <p className="mb-4 leading-relaxed">The precision of our neural network ensures clean edges around hair and clothing, previously only achievable by professional VFX artists manually masking frame by frame. It processes the video quickly right in your browser. Elevate your production quality instantly and transport yourself anywhere in the world with the NexusCut Remove Background tool.</p>
      </section>
      <Footer />
    </>
  );
}
