import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Viral Hook Generator for Shorts & Reels - NexusCut',
  description: 'Generate irresistible, data-backed hooks for your videos. Stop the scroll and double your retention.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">Stop the Scroll with the Viral Hook Generator</h2>
                <p className="mb-4 leading-relaxed">The first three seconds of your video dictate 90% of its success. If you do not capture the viewer's attention immediately, they will scroll past, killing your retention metrics and signaling the algorithm to stop pushing your content. The Viral Hook Generator is your secret weapon for crafting irresistible, scroll-stopping openings.</p>
        <p className="mb-4 leading-relaxed">Drawing on data from millions of highly successful short-form videos, our AI generates powerful, psychologically proven hooks tailored to your specific topic. Whether you need a curiosity gap ("The dark secret about..."), a bold claim ("Why everything you know about X is wrong"), or a relatable scenario, the tool provides dozens of variations designed to maximize initial viewer retention.</p>
        <p className="mb-4 leading-relaxed">You can use these hooks as text-on-screen titles, as the opening line of your spoken script, or both. Stop relying on guesswork and start engineering virality into your content from the very beginning. Hook your audience instantly and watch your average view duration and subscriber count skyrocket.</p>
      </section>
      <Footer />
    </>
  );
}
