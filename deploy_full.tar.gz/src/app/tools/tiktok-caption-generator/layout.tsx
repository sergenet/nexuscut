import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'TikTok Caption & Hashtag Generator - NexusCut',
  description: 'Generate viral TikTok captions, descriptions, and trending hashtags with AI. Boost your reach instantly.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">Optimize Your Reach with the TikTok Caption Generator</h2>
                <p className="mb-4 leading-relaxed">Creating a great video is only half the battle; getting the algorithm to push it to the For You Page requires the right metadata. Our TikTok Caption Generator analyzes the context of your video and generates highly optimized, engaging text descriptions designed to maximize reach and drive comments.</p>
        <p className="mb-4 leading-relaxed">The AI is trained on thousands of viral TikToks, understanding the psychology of a great hook, the importance of a clear call-to-action (CTA), and the strategic use of trending hashtags. Instead of staring at a blank screen wondering what to write, simply input a brief summary of your video. The tool will provide multiple variations of captions—from witty and controversial to educational and inspiring.</p>
        <p className="mb-4 leading-relaxed">Furthermore, the tool suggests the most relevant, high-volume hashtags for your specific niche, ensuring your video is categorized correctly by the platform's algorithm. Save time, eliminate writer's block, and give your videos the best possible chance of going viral with perfectly crafted captions tailored for the fast-paced world of TikTok and Instagram Reels.</p>
      </section>
      <Footer />
    </>
  );
}
