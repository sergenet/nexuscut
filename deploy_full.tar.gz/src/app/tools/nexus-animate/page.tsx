"use client";

import React, { useState } from "react";
import { Upload, Film, Wand2, ArrowRight, Play, Download, Loader2 } from "lucide-react";
import Image from "next/image";

export default function NexusAnimatePage() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [status, setStatus] = useState<"idle" | "uploading" | "processing" | "done">("idle");

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (selectedFile: File) => {
    setFile(selectedFile);
    const objectUrl = URL.createObjectURL(selectedFile);
    setPreview(objectUrl);
    setStatus("idle");
  };

  const handleAnimate = () => {
    if (!file) return;
    setStatus("uploading");
    
    // Simulate upload
    setTimeout(() => {
      setStatus("processing");
      
      // Simulate heavy AI processing
      setTimeout(() => {
        setStatus("done");
      }, 4000);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-neutral-950 pt-32 pb-24">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-rose-500/10 text-rose-400 rounded-full text-sm font-bold tracking-wide uppercase mb-6">
            <Film className="w-4 h-4" /> NexusAnimate Pro
          </div>
          <h1 className="text-5xl md:text-6xl font-black text-white mb-6 tracking-tight">
            Bring Static Images to <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-500 to-indigo-500">Life</span>
          </h1>
          <p className="text-xl text-neutral-400 max-w-2xl mx-auto">
            Upload any photo and let our advanced AI generate cinematic camera movements, particle effects, and dynamic motion.
          </p>
        </div>

        {/* Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Uploader */}
          <div className="lg:col-span-2">
            <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl relative min-h-[500px] flex flex-col">
              
              {/* Toolbar */}
              <div className="h-14 bg-neutral-950 border-b border-neutral-800 flex items-center px-4 justify-between">
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500"></div>
                  <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                  <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                </div>
                <div className="text-sm font-semibold text-neutral-500">NexusAnimate Engine v2.0</div>
              </div>

              {/* Main Canvas */}
              <div className="flex-1 p-8 flex items-center justify-center relative">
                {!preview ? (
                  <label 
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={handleDrop}
                    className="w-full h-full min-h-[300px] border-2 border-dashed border-neutral-700 hover:border-rose-500 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-colors bg-neutral-950/50 group"
                  >
                    <div className="w-20 h-20 bg-neutral-800 group-hover:bg-rose-500/20 rounded-full flex items-center justify-center mb-6 transition-colors">
                      <Upload className="w-10 h-10 text-neutral-400 group-hover:text-rose-500 transition-colors" />
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-2">Drag & Drop Image</h3>
                    <p className="text-neutral-500">or click to browse (JPG, PNG, WEBP)</p>
                    <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
                  </label>
                ) : (
                  <div className="relative w-full h-full min-h-[400px] rounded-2xl overflow-hidden bg-black">
                    {/* The Image/Video output */}
                    {status === "done" ? (
                      <div className="absolute inset-0 flex items-center justify-center group">
                        {/* We use an image with a slow zoom CSS animation to simulate the video for the MVP */}
                        <div className="absolute inset-0 overflow-hidden">
                          <img 
                            src={preview} 
                            alt="Animated Output" 
                            className="w-full h-full object-cover animate-[zoom_10s_ease-in-out_infinite_alternate]"
                          />
                        </div>
                        {/* Overlay elements */}
                        <div className="absolute inset-0 bg-black/20" />
                        <button className="relative z-10 w-20 h-20 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center hover:scale-110 transition-transform">
                          <Play className="w-8 h-8 text-white ml-2" />
                        </button>
                      </div>
                    ) : (
                      <img src={preview} alt="Preview" className="w-full h-full object-contain opacity-50" />
                    )}

                    {/* Loading Overlay */}
                    {(status === "uploading" || status === "processing") && (
                      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center z-20">
                        <Loader2 className="w-12 h-12 text-rose-500 animate-spin mb-4" />
                        <h3 className="text-xl font-bold text-white mb-2">
                          {status === "uploading" ? "Analyzing Image Depth..." : "Generating Motion Frames..."}
                        </h3>
                        <div className="w-64 h-2 bg-neutral-800 rounded-full overflow-hidden mt-4">
                          <div className="h-full bg-gradient-to-r from-rose-500 to-indigo-500 animate-[loading_2s_ease-in-out_infinite]" style={{ width: "50%" }}></div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: Settings */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 flex flex-col h-[500px]">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <Wand2 className="w-5 h-5 text-indigo-400" /> Animation Settings
            </h3>
            
            <div className="flex-1 space-y-6">
              <div>
                <label className="block text-sm font-semibold text-neutral-400 mb-3">Motion Style</label>
                <div className="grid grid-cols-2 gap-2">
                  <button className="bg-rose-500 text-white font-semibold py-3 px-4 rounded-xl text-sm border border-rose-400">Cinematic Pan</button>
                  <button className="bg-neutral-800 hover:bg-neutral-700 text-white font-semibold py-3 px-4 rounded-xl text-sm transition-colors border border-neutral-700">Dolly Zoom</button>
                  <button className="bg-neutral-800 hover:bg-neutral-700 text-white font-semibold py-3 px-4 rounded-xl text-sm transition-colors border border-neutral-700">Orbit</button>
                  <button className="bg-neutral-800 hover:bg-neutral-700 text-white font-semibold py-3 px-4 rounded-xl text-sm transition-colors border border-neutral-700">Parallax</button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-neutral-400 mb-3">Duration</label>
                <input type="range" min="1" max="10" defaultValue="5" className="w-full accent-rose-500" />
                <div className="flex justify-between text-xs text-neutral-500 mt-2 font-medium">
                  <span>1s</span>
                  <span>5s</span>
                  <span>10s</span>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-neutral-800">
              {status === "done" ? (
                <button 
                  onClick={() => {
                    setFile(null);
                    setPreview(null);
                    setStatus("idle");
                  }}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-4 rounded-xl transition-all shadow-lg flex items-center justify-center gap-2"
                >
                  <Download className="w-5 h-5" /> Export MP4
                </button>
              ) : (
                <button 
                  onClick={handleAnimate}
                  disabled={!preview || status !== "idle"}
                  className="w-full bg-gradient-to-r from-rose-600 to-indigo-600 hover:from-rose-500 hover:to-indigo-500 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-rose-500/20 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed group"
                >
                  <Wand2 className="w-5 h-5 group-hover:rotate-12 transition-transform" /> 
                  {status === "idle" ? "Generate Animation" : "Processing..."}
                </button>
              )}
            </div>
          </div>

        </div>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes zoom {
          0% { transform: scale(1); }
          100% { transform: scale(1.15); }
        }
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }
      `}} />
    </div>
  );
}
