import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Nexus Animate: AI Video Animation - NexusCut',
  description: 'Animate static images into moving videos with Nexus Animate. The ultimate AI video generator.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">Bring Static Images to Life with Nexus Animate</h2>
                <p className="mb-4 leading-relaxed">Welcome to Nexus Animate, the cutting-edge tool that transforms static images into dynamic, moving video clips. In the modern era of content creation, standing out requires visual innovation. With Nexus Animate, you can take a simple photograph, artwork, or AI-generated image and breathe life into it with realistic motion.</p>
        <p className="mb-4 leading-relaxed">How does it work? Our advanced depth-estimation AI analyzes your 2D image, builds a 3D depth map, and generates subtle camera movements, parallax effects, and particle animations. This is perfect for creating engaging B-roll footage, dramatic documentary pans, or eye-catching intros for YouTube.</p>
        <p className="mb-4 leading-relaxed">You no longer need expensive stock footage to make your videos visually engaging. By combining our AI Image Generator with Nexus Animate, you can conjure entirely new video assets out of thin air. It is fully integrated into your editing timeline, allowing you to string together animated scenes with cinematic transitions. Unlock a new dimension of storytelling and keep your viewers captivated with stunning visual motion.</p>
      </section>
      <Footer />
    </>
  );
}
