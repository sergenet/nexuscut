"use client";

import React, { useState } from "react";
import { Upload, Type, ArrowRight, Video, Captions, Loader2, Download, Sparkles } from "lucide-react";
import Link from "next/link";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

export default function AnimatedSubtitlesPage() {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<"idle" | "uploading" | "animating" | "done">("idle");

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleGenerate = () => {
    if (!file) return;
    setStatus("uploading");
    
    setTimeout(() => {
      setStatus("animating");
      
      setTimeout(() => {
        setStatus("done");
      }, 4000);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-white font-sans flex flex-col">
      <Navigation />
      <div className="pt-32 pb-24 flex-grow">
        <div className="max-w-6xl mx-auto px-6">
          
          {/* Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-fuchsia-500/10 text-fuchsia-400 rounded-full text-sm font-bold tracking-wide uppercase mb-6">
              <Sparkles className="w-4 h-4" /> Word-by-Word Animation
            </div>
            <h1 className="text-5xl md:text-6xl font-black text-white mb-6 tracking-tight">
              AI <span className="text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-400 to-pink-500">Animated Subtitles</span>
            </h1>
            <p className="text-xl text-neutral-400 max-w-2xl mx-auto">
              Keep viewers hooked. Upload your video and instantly apply dynamic, bouncy, word-by-word subtitles that increase retention by up to 40%.
            </p>
          </div>

          {/* Workspace */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Main Area */}
            <div className="lg:col-span-2">
              <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl relative min-h-[500px] flex flex-col">
                
                {/* Canvas */}
                <div className="flex-1 p-8 flex items-center justify-center relative">
                  {!file ? (
                    <label 
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={handleDrop}
                      className="w-full h-full min-h-[300px] border-2 border-dashed border-neutral-700 hover:border-fuchsia-500 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-colors bg-neutral-950/50 group"
                    >
                      <div className="w-20 h-20 bg-neutral-800 group-hover:bg-fuchsia-500/20 rounded-full flex items-center justify-center mb-6 transition-colors">
                        <Video className="w-10 h-10 text-neutral-400 group-hover:text-fuchsia-500 transition-colors" />
                      </div>
                      <h3 className="text-2xl font-bold text-white mb-2">Upload Video</h3>
                      <p className="text-neutral-500">MP4, MOV, or WEBM up to 2GB</p>
                      <input type="file" accept="video/*" className="hidden" onChange={(e) => setFile(e.target.files?.[0] || null)} />
                    </label>
                  ) : (
                    <div className="relative w-full h-full min-h-[400px] rounded-2xl overflow-hidden bg-black flex items-center justify-center">
                      
                      {status === "done" ? (
                        <div className="w-full h-full relative">
                          {/* Placeholder video layout */}
                          <div className="absolute inset-0 bg-neutral-800 flex items-center justify-center">
                            <Video className="w-16 h-16 text-neutral-600" />
                          </div>
                          {/* Simulated Captions overlay */}
                          <div className="absolute bottom-10 inset-x-0 flex justify-center">
                            <div className="bg-black/40 px-8 py-4 rounded-2xl">
                              <p className="text-3xl font-black text-white tracking-widest uppercase text-center" style={{ textShadow: "4px 4px 0 #db2777" }}>
                                <span className="text-yellow-300 scale-110 inline-block transform">BOOST</span> YOUR RETENTION!
                              </p>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center">
                          <Video className="w-16 h-16 text-neutral-600 mx-auto mb-4" />
                          <p className="text-white font-semibold">{file.name}</p>
                          <p className="text-neutral-500 text-sm">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
                        </div>
                      )}

                      {/* Loading Overlay */}
                      {(status === "uploading" || status === "animating") && (
                        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center z-20">
                          <Loader2 className="w-12 h-12 text-fuchsia-500 animate-spin mb-4" />
                          <h3 className="text-xl font-bold text-white mb-2">
                            {status === "uploading" ? "Uploading Video..." : "Applying Animations..."}
                          </h3>
                          <div className="w-64 h-2 bg-neutral-800 rounded-full overflow-hidden mt-4">
                            <div className="h-full bg-fuchsia-500 animate-[loading_2s_ease-in-out_infinite]" style={{ width: "50%" }}></div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right Column: Settings & Output */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 flex flex-col h-[500px]">
              <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-fuchsia-400" /> Animation Styles
              </h3>
              
              <div className="flex-1 space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-neutral-400 mb-3">Choose Style</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button className="bg-fuchsia-600 text-white font-bold py-4 px-3 rounded-xl text-sm border border-fuchsia-500 shadow-[0_0_15px_rgba(217,70,239,0.4)]">Neon Bounce</button>
                    <button className="bg-neutral-800 hover:bg-neutral-700 text-white font-bold py-4 px-3 rounded-xl text-sm transition-colors border border-neutral-700">Hormozi Pop</button>
                    <button className="bg-neutral-800 hover:bg-neutral-700 text-white font-bold py-4 px-3 rounded-xl text-sm transition-colors border border-neutral-700">Beast Glow</button>
                    <button className="bg-neutral-800 hover:bg-neutral-700 text-white font-bold py-4 px-3 rounded-xl text-sm transition-colors border border-neutral-700">Meme Drop</button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-neutral-400 mb-3">Color Accent</label>
                  <div className="flex gap-2">
                    <button className="w-8 h-8 rounded-full bg-yellow-400 ring-2 ring-white ring-offset-2 ring-offset-neutral-900"></button>
                    <button className="w-8 h-8 rounded-full bg-green-400"></button>
                    <button className="w-8 h-8 rounded-full bg-cyan-400"></button>
                    <button className="w-8 h-8 rounded-full bg-fuchsia-500"></button>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-neutral-800">
                {status === "done" ? (
                  <div className="flex gap-2">
                    <button className="flex-1 bg-neutral-800 hover:bg-neutral-700 text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2">
                      <Download className="w-5 h-5" /> Download MP4
                    </button>
                    <Link href="/pricing" className="flex-1 bg-fuchsia-600 hover:bg-fuchsia-500 text-white font-bold py-4 rounded-xl transition-all shadow-lg flex items-center justify-center gap-2">
                      Edit in Pro
                    </Link>
                  </div>
                ) : (
                  <button 
                    onClick={handleGenerate}
                    disabled={!file || status !== "idle"}
                    className="w-full bg-gradient-to-r from-fuchsia-600 to-pink-500 hover:from-fuchsia-500 hover:to-pink-400 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-fuchsia-500/25 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed group"
                  >
                    <Sparkles className="w-5 h-5 group-hover:scale-110 transition-transform" /> 
                    {status === "idle" ? "Animate Subtitles" : "Processing..."}
                  </button>
                )}
              </div>
            </div>

          </div>
        </div>
      </div>
      <Footer />
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }
      `}} />
    </div>
  );
}
