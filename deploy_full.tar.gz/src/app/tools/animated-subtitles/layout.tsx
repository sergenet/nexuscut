import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Animated Subtitles Generator - NexusCut',
  description: 'Add dynamic, Hormozi-style animated subtitles to your videos. Boost viewer retention on TikTok, Reels, and Shorts.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">Boost Retention with Dynamic Animated Subtitles</h2>
                <p className="mb-4 leading-relaxed">If you are creating short-form content for TikTok, Instagram Reels, or YouTube Shorts, you already know that animated subtitles are no longer optional—they are a requirement for high retention. Our Animated Subtitles Generator makes it incredibly easy to add professional, dynamic text to your videos in just one click.</p>
        <p className="mb-4 leading-relaxed">Inspired by top creators like Alex Hormozi and Ali Abdaal, our tool automatically synchronizes the text with your speech, highlighting words exactly as they are spoken. You can customize the fonts, colors, stroke thickness, and drop shadows to perfectly match your brand kit. Choose from energetic pop-in animations for fast-paced motivational clips, or smooth slide transitions for educational and productivity content.</p>
        <p className="mb-4 leading-relaxed">Why do animated subtitles work so well? They create a visual anchor for your viewers. By constantly updating the screen with kinetic typography, you prevent the viewer's eye from drifting away, significantly lowering your swipe-away rate. Our AI engine ensures over 99% accuracy in transcription, so you spend less time correcting text and more time publishing. Upload your video today and watch your engagement metrics soar with perfectly timed, highly engaging animated captions.</p>
      </section>
      <Footer />
    </>
  );
}
