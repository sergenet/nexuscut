import type { Metadata } from 'next';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Subtitle Style Generator - NexusCut',
  description: 'Create custom, viral subtitle styles for your short-form videos. Export presets for TikTok and Reels.',
};

export default function ToolLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <section className="max-w-4xl mx-auto px-6 py-24 text-gray-300">
        <h2 className="text-3xl font-bold text-white mb-6">Design Viral Captions with the Subtitle Style Generator</h2>
                <p className="mb-4 leading-relaxed">The look of your subtitles can make or break your video's performance on TikTok, Instagram Reels, and YouTube Shorts. The Subtitle Style Generator gives you absolute control over the typography, colors, animations, and pacing of your on-screen text.</p>
        <p className="mb-4 leading-relaxed">While we offer preset styles modeled after top creators, this tool allows you to build your own signature look from scratch. Choose from hundreds of premium fonts, adjust the stroke width, configure multi-layered drop shadows for readability, and set up dynamic keyword highlighting. You can customize the exact animation curve for how words pop onto the screen, ensuring the energy of the text matches the energy of your voice.</p>
        <p className="mb-4 leading-relaxed">Once you have crafted the perfect subtitle style, you can save it as a preset to your Brand Kit. This ensures consistency across all your future videos, allowing you to edit faster and maintain a recognizable visual identity. Stand out in the crowded social media feed with bespoke, eye-catching captions that demand attention and drive massive engagement.</p>
      </section>
      <Footer />
    </>
  );
}
