
import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Free YouTube Shorts Editor with AI | NexusCut',
  description: 'Create engaging YouTube Shorts faster. Add animated captions, remove backgrounds, and edit shorts perfectly formatted for YouTube.',
  openGraph: {
    title: 'Free YouTube Shorts Editor with AI | NexusCut',
    description: 'Create engaging YouTube Shorts faster. Add animated captions, remove backgrounds, and edit shorts perfectly formatted for YouTube.',
    type: 'website',
  }
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
