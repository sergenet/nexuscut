import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET() {
  try {
    const userId = "local-user"; // Hardcoded for no-auth

    // Ensure the user exists
    const user = await prisma.user.upsert({
      where: { clerkId: userId },
      update: {},
      create: { clerkId: userId },
    });

    const brandKit = await prisma.brandKit.findUnique({
      where: { userId: user.id },
    });

    return NextResponse.json({ brandKit });
  } catch (error) {
    console.error('Error fetching brand kit:', error);
    return NextResponse.json({ error: 'Failed to fetch brand kit' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const userId = "local-user"; // Hardcoded for no-auth

    // Ensure the user exists
    const user = await prisma.user.upsert({
      where: { clerkId: userId },
      update: {},
      create: { clerkId: userId },
    });

    const { primaryColor, secondaryColor, fontUrl, logoUrl } = await req.json();

    const brandKit = await prisma.brandKit.upsert({
      where: { userId: user.id },
      update: {
        primaryColor,
        secondaryColor,
        fontUrl,
        logoUrl,
      },
      create: {
        userId: user.id,
        primaryColor,
        secondaryColor,
        fontUrl,
        logoUrl,
      },
    });

    return NextResponse.json({ brandKit });
  } catch (error) {
    console.error('Error updating brand kit:', error);
    return NextResponse.json({ error: 'Failed to update brand kit' }, { status: 500 });
  }
}
