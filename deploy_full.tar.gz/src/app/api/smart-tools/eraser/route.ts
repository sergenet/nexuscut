import { NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promises as fs } from 'fs';
import path from 'path';
import os from 'os';

export async function POST(req: Request) {
  try {
    const formData = await req.formData() as any;
    const videoFile = formData.get('video') as File;
    const rectsJson = formData.get('rects') as string;
    
    if (!videoFile || !rectsJson) {
      return NextResponse.json({ error: 'No video file or coordinates provided' }, { status: 400 });
    }

    const tmpDir = path.join(os.tmpdir(), 'nexuscut_ai');
    await fs.mkdir(tmpDir, { recursive: true });

    const inputPath = path.join(tmpDir, `input_erase_${Date.now()}.mp4`);
    const outputPath = path.join(tmpDir, `output_erase_${Date.now()}.mp4`);

    const arrayBuffer = await videoFile.arrayBuffer();
    await fs.writeFile(inputPath, Buffer.from(arrayBuffer));

    // The Python script will handle processing the video
    const pythonScript = path.join(process.cwd(), 'src', 'ai', 'eraser.py');
    const command = `python ${pythonScript} "${inputPath}" "${outputPath}" '${rectsJson}'`;

    await new Promise((resolve, reject) => {
      exec(command, (error, stdout, stderr) => {
        if (error) {
          console.error(`AI Error: ${stderr}`);
          reject(error);
        } else {
          resolve(stdout);
        }
      });
    });

    const outputBuffer = await fs.readFile(outputPath);

    // Clean up
    await fs.unlink(inputPath).catch(console.error);
    await fs.unlink(outputPath).catch(console.error);

    return new NextResponse(outputBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'video/mp4',
        'Content-Disposition': 'attachment; filename="erased.mp4"'
      }
    });

  } catch (error: any) {
    console.error('Smart Tool Error:', error);
    return NextResponse.json({ error: error.message || 'Processing failed' }, { status: 500 });
  }
}
