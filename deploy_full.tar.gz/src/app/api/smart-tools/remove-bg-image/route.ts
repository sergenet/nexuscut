import { NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promises as fs } from 'fs';
import path from 'path';
import os from 'os';

export async function POST(req: Request) {
  try {
    const formData = await req.formData() as any;
    const imageFile = formData.get('image') as File;
    if (!imageFile) {
      return NextResponse.json({ error: 'No image file provided' }, { status: 400 });
    }

    const tmpDir = path.join(os.tmpdir(), 'nexuscut_ai');
    await fs.mkdir(tmpDir, { recursive: true });

    const inputPath = path.join(tmpDir, `input_${Date.now()}.png`);
    const outputPath = path.join(tmpDir, `output_${Date.now()}.png`);

    const arrayBuffer = await imageFile.arrayBuffer();
    await fs.writeFile(inputPath, Buffer.from(arrayBuffer));

    const pythonScript = path.join(process.cwd(), 'src', 'ai', 'remove_bg_image.py');
    const command = `python3 ${pythonScript} "${inputPath}" "${outputPath}"`;

    await new Promise((resolve, reject) => {
      exec(command, (error, stdout, stderr) => {
        if (error) {
          console.error(`AI Error: ${stderr}`);
          reject(error);
        } else {
          resolve(stdout);
        }
      });
    });

    const outputBuffer = await fs.readFile(outputPath);

    // Clean up
    await fs.unlink(inputPath).catch(console.error);
    await fs.unlink(outputPath).catch(console.error);

    return new NextResponse(outputBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'image/png',
        'Content-Disposition': 'inline; filename="removed_bg.png"'
      }
    });

  } catch (error: any) {
    console.error('Smart Tool Error:', error);
    return NextResponse.json({ error: error.message || 'Processing failed' }, { status: 500 });
  }
}
