import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { cookies } from 'next/headers';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const token = searchParams.get('token');

    if (!token) {
      return NextResponse.redirect(`${process.env.NEXT_PUBLIC_APP_URL || 'https://nexuscut.io'}/marketplace?error=missing_token`);
    }

    // 1. Validate token
    const magicLink = await prisma.magicLink.findUnique({
      where: { token }
    });

    if (!magicLink) {
      return NextResponse.redirect(`${process.env.NEXT_PUBLIC_APP_URL || 'https://nexuscut.io'}/marketplace?error=invalid_token`);
    }

    if (new Date() > magicLink.expiresAt) {
      await prisma.magicLink.delete({ where: { id: magicLink.id } });
      return NextResponse.redirect(`${process.env.NEXT_PUBLIC_APP_URL || 'https://nexuscut.io'}/marketplace?error=expired_token`);
    }

    // 2. Find the user by email
    const user = await prisma.user.findUnique({
      where: { email: magicLink.email }
    });

    if (!user) {
      return NextResponse.redirect(`${process.env.NEXT_PUBLIC_APP_URL || 'https://nexuscut.io'}/marketplace?error=user_not_found`);
    }

    // 3. Bind the current browser's nexus_session_id to this user
    const cookieStore = await cookies();
    const currentSessionId = cookieStore.get('nexus_session_id')?.value;

    if (currentSessionId) {
      await prisma.user.update({
        where: { id: user.id },
        data: { clerkId: currentSessionId }
      });
    }

    // 4. Clean up token
    await prisma.magicLink.delete({
      where: { id: magicLink.id }
    });

    // 5. Redirect to downloads
    return NextResponse.redirect(`${process.env.NEXT_PUBLIC_APP_URL || 'https://nexuscut.io'}/downloads?success=recovered`);

  } catch (error: any) {
    console.error('Verify error:', error);
    return NextResponse.redirect(`${process.env.NEXT_PUBLIC_APP_URL || 'https://nexuscut.io'}/marketplace?error=server_error`);
  }
}
