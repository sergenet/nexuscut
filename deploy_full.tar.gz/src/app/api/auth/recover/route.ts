import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import crypto from 'crypto';
import nodemailer from 'nodemailer';

export async function POST(req: Request) {
  try {
    const { email } = await req.json();

    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }

    // 1. Check if user exists
    const user = await prisma.user.findUnique({
      where: { email }
    });

    if (!user) {
      // Return success even if user doesn't exist to prevent email enumeration attacks
      return NextResponse.json({ success: true });
    }

    // 2. Generate a secure token
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

    // 3. Save token in database
    await prisma.magicLink.create({
      data: {
        email,
        token,
        expiresAt
      }
    });

    // 4. Send email using Namecheap SMTP via nodemailer
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || 'mail.privateemail.com',
      port: parseInt(process.env.SMTP_PORT || '465'),
      secure: parseInt(process.env.SMTP_PORT || '465') === 465, // true for 465, false for other ports
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });

    const verifyUrl = `${process.env.NEXT_PUBLIC_APP_URL || 'https://nexuscut.io'}/api/auth/verify?token=${token}`;

    const mailOptions = {
      from: `"NexusCut" <${process.env.SMTP_USER}>`,
      to: email,
      subject: 'Recover Your NexusCut Purchases',
      html: `
        <div style="font-family: Arial, sans-serif; max-w: 600px; margin: 0 auto; padding: 20px; background-color: #000; color: #fff; border-radius: 10px;">
          <h2 style="color: #39ff14;">NexusCut Recovery</h2>
          <p style="color: #ccc; font-size: 16px;">Click the button below to recover your NexusCut session and access your purchased downloads.</p>
          <p style="color: #888; font-size: 14px;">This link will expire in 15 minutes.</p>
          <a href="${verifyUrl}" style="display: inline-block; padding: 12px 24px; background-color: #39ff14; color: #000; text-decoration: none; font-weight: bold; border-radius: 5px; margin-top: 20px;">
            Access My Downloads
          </a>
        </div>
      `,
    };

    if (process.env.SMTP_USER && process.env.SMTP_PASS) {
      await transporter.sendMail(mailOptions);
    } else {
      console.log('Missing SMTP credentials. Magic Link URL:', verifyUrl);
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Recovery error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
