import { NextResponse } from 'next/server';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST(req: Request) {
  try {
    const { transcript } = await req.json();
    if (!transcript) {
      return NextResponse.json({ error: 'Transcript is required' }, { status: 400 });
    }

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: 'OpenAI API key is missing' }, { status: 500 });
    }

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: `You are an expert short-form video strategist. Given a transcript of a video where each segment is preceded by its start time like [1.5s], your job is to find the single most engaging hook (a 1-3 sentence snippet that grabs attention, typically under 15 seconds long). Return ONLY a JSON object with two keys: "start" (a number representing the start time in seconds of the hook) and "end" (a number representing the end time in seconds). Do not include markdown formatting.`
        },
        {
          role: 'user',
          content: transcript
        }
      ],
      temperature: 0.7,
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content?.trim();
    if (!content) {
      throw new Error('No content returned from OpenAI');
    }

    const result = JSON.parse(content);

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error extracting hook:', error);
    return NextResponse.json({ error: 'Failed to extract hook' }, { status: 500 });
  }
}
