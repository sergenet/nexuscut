import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import prisma from '@/lib/prisma';

export async function GET() {
  try {
    const cookieStore = await cookies();
    let userId = cookieStore.get('nexus_session_id')?.value;
    
    // Fallback if middleware didn't run
    if (!userId) {
      userId = `anon-${Math.random().toString(36).substring(2, 15)}`;
    }

    const user = await prisma.user.findUnique({ where: { clerkId: userId } });
    if (!user) {
      return NextResponse.json({ projects: [] });
    }

    const projects = await prisma.project.findMany({
      where: { userId: user.id },
      orderBy: { updatedAt: 'desc' },
      select: { id: true, name: true, updatedAt: true }
    });

    return NextResponse.json({ projects });
  } catch (error: any) {
    console.error("Fetch projects error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const cookieStore = await cookies();
    let userId = cookieStore.get('nexus_session_id')?.value;
    
    // Fallback if middleware didn't run
    if (!userId) {
      userId = `anon-${Math.random().toString(36).substring(2, 15)}`;
    }

    const body = await req.json();
    const { name, editorState } = body;

    const user = await prisma.user.upsert({
      where: { clerkId: userId },
      update: {},
      create: { clerkId: userId },
    });

    // Check if we want to create a new project or overwrite an existing one by name
    const existing = await prisma.project.findFirst({
      where: { userId: user.id, name }
    });

    let project;
    if (existing) {
      project = await prisma.project.update({
        where: { id: existing.id },
        data: { editorState: JSON.stringify(editorState) }
      });
    } else {
      project = await prisma.project.create({
        data: {
          name: name || "Untitled Project",
          editorState: JSON.stringify(editorState),
          userId: user.id
        }
      });
    }

    return NextResponse.json({ success: true, projectId: project.id });
  } catch (error: any) {
    console.error("Save project error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
