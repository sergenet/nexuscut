import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import prisma from '@/lib/prisma';

export async function POST(req: Request) {
  try {
    const cookieStore = await cookies();
    let userId = cookieStore.get('nexus_session_id')?.value;
    
    // Fallback if middleware didn't run
    if (!userId) {
      userId = `anon-${Math.random().toString(36).substring(2, 15)}`;
    }

    const body = await req.json();
    const { id, name, editorState } = body;

    // Upsert the user in our DB if they don't exist
    const user = await prisma.user.upsert({
      where: { clerkId: userId },
      update: {},
      create: { clerkId: userId },
    });

    const serializedState = JSON.stringify(editorState);

    let project;
    if (id) {
      // Update existing project
      project = await prisma.project.update({
        where: { id: id },
        data: {
          name: name || undefined,
          editorState: serializedState,
        },
      });
    } else {
      // Create new project
      project = await prisma.project.create({
        data: {
          name: name || "Untitled Project",
          editorState: serializedState,
          userId: user.id,
        },
      });
    }

    return NextResponse.json({ success: true, project });
  } catch (error: any) {
    console.error("Save project error:", error);
    return NextResponse.json({ error: error.message || 'Failed to save project' }, { status: 500 });
  }
}
