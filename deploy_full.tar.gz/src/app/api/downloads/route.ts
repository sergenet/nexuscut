import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import prisma from '@/lib/prisma';
import fs from 'fs';
import path from 'path';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const itemId = searchParams.get('itemId');

    if (!itemId) {
      return NextResponse.json({ error: 'Missing itemId' }, { status: 400 });
    }

    const cookieStore = await cookies();
    const clerkId = cookieStore.get('nexus_session_id')?.value;

    if (!clerkId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { clerkId },
      include: {
        purchases: {
          where: { itemId }
        }
      }
    });

    if (!user || user.purchases.length === 0) {
      return NextResponse.json({ error: 'Purchase not found or unauthorized' }, { status: 403 });
    }

    // Security: Map itemIds to actual filenames to prevent directory traversal
    const fileMap: Record<string, string> = {
      'cap-hormozi': 'hormozi_template.zip',
      'cap-abdaal': 'abdaal_template.zip',
      'bg-gta': 'gta_backgrounds.zip',
      'bg-asmr': 'asmr_backgrounds.zip',
      'addon-growth-mode': 'growth_mode_guide.pdf'
    };

    const filename = fileMap[itemId];
    if (!filename) {
      return NextResponse.json({ error: 'Asset not configured' }, { status: 404 });
    }

    // Serve from a secure non-public directory
    const filePath = path.join(process.cwd(), 'secure_assets', filename);

    if (!fs.existsSync(filePath)) {
      return NextResponse.json({ error: 'File not found on server' }, { status: 404 });
    }

    const fileBuffer = fs.readFileSync(filePath);
    
    return new NextResponse(fileBuffer, {
      headers: {
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Type': 'application/octet-stream',
      },
    });

  } catch (error: any) {
    console.error('Download error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
