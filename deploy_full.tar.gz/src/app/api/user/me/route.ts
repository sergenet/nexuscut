import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import prisma from '@/lib/prisma';

export async function GET() {
  try {
    const cookieStore = await cookies();
    let userId = cookieStore.get('nexus_session_id')?.value;
    
    // Fallback if middleware didn't run (e.g. edge cases)
    if (!userId) {
      userId = `anon-${Math.random().toString(36).substring(2, 15)}`;
    }

    const user = await prisma.user.upsert({
      where: { clerkId: userId },
      update: {},
      create: { clerkId: userId },
    });

    return NextResponse.json({ isPro: user.isPro });
  } catch (error: any) {
    console.error("User me error:", error);
    return NextResponse.json({ isPro: false });
  }
}
