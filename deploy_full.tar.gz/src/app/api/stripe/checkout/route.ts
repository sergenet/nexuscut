import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import prisma from '@/lib/prisma';
import { cookies } from 'next/headers';

const getStripe = () => {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error('STRIPE_SECRET_KEY is not configured in the environment variables');
  }
  return new Stripe(process.env.STRIPE_SECRET_KEY as string, {
    apiVersion: '2026-06-24.dahlia' as any,
  });
};

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const tier = searchParams.get('plan') || 'pro';
    
    const cookieStore = await cookies();
    const userId = cookieStore.get('nexus_session_id')?.value || `anon-${Math.random().toString(36).substring(2, 15)}`;
    const affiliateCode = cookieStore.get('nexuscut_affiliate')?.value;

    await prisma.user.upsert({
      where: { clerkId: userId },
      update: {},
      create: { clerkId: userId },
    });

    let priceId = process.env.STRIPE_PRO_PRICE_ID || process.env.NEXT_PUBLIC_STRIPE_PRO_PRICE_ID;
    
    if (tier === 'creator') {
      priceId = process.env.STRIPE_CREATOR_PRICE_ID || process.env.NEXT_PUBLIC_STRIPE_CREATOR_PRICE_ID;
    } else if (tier === 'agency') {
      priceId = process.env.STRIPE_AGENCY_PRICE_ID || process.env.NEXT_PUBLIC_STRIPE_AGENCY_PRICE_ID;
    }

    if (!priceId) {
      return NextResponse.json({ error: 'Price ID not configured' }, { status: 500 });
    }

    const stripe = getStripe();
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      mode: 'subscription',
      success_url: `${process.env.NEXT_PUBLIC_APP_URL || "https://nexuscut.io"}/editor?success=true`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL || "https://nexuscut.io"}/pricing`,
      client_reference_id: userId,
      customer_email: "test@example.com",
      metadata: { 
        tier,
        ...(affiliateCode && { affiliate_code: affiliateCode }) 
      }
    });

    return NextResponse.redirect(session.url as string);
  } catch (error: any) {
    console.error('Stripe checkout GET error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get('nexus_session_id')?.value || `anon-${Math.random().toString(36).substring(2, 15)}`;

    // Read affiliate code from cookies
    const affiliateCode = cookieStore.get('nexuscut_affiliate')?.value;

    await prisma.user.upsert({
      where: { clerkId: userId },
      update: {},
      create: { clerkId: userId },
    });

    const body = await req.json().catch(() => ({}));
    const tier = body.tier || 'pro'; // 'pro', 'creator', 'agency'

    let priceId = process.env.STRIPE_PRO_PRICE_ID || process.env.NEXT_PUBLIC_STRIPE_PRO_PRICE_ID;
    
    if (tier === 'creator') {
      priceId = process.env.STRIPE_CREATOR_PRICE_ID || process.env.NEXT_PUBLIC_STRIPE_CREATOR_PRICE_ID;
    } else if (tier === 'agency') {
      priceId = process.env.STRIPE_AGENCY_PRICE_ID || process.env.NEXT_PUBLIC_STRIPE_AGENCY_PRICE_ID;
    }

    if (!priceId) {
      return NextResponse.json({ error: 'Price ID not configured' }, { status: 500 });
    }

    const stripe = getStripe();
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${process.env.NEXT_PUBLIC_APP_URL || "https://nexuscut.io"}/editor?success=true`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL || "https://nexuscut.io"}/pricing`,
      client_reference_id: userId,
      customer_email: "test@example.com",
      metadata: { 
        tier,
        ...(affiliateCode && { affiliate_code: affiliateCode }) 
      }
    });

    return NextResponse.json({ url: session.url });
  } catch (error: any) {
    console.error('Stripe checkout error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
