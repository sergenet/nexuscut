import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import Stripe from 'stripe';
import prisma from '@/lib/prisma';

const getStripe = () => {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error('STRIPE_SECRET_KEY is not configured in the environment variables');
  }
  return new Stripe(process.env.STRIPE_SECRET_KEY as string, {
    apiVersion: '2026-06-24.dahlia' as any,
  });
};

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { itemId, name, price } = body;
    
    const cookieStore = await cookies();
    let userId = cookieStore.get('nexus_session_id')?.value;
    if (!userId) userId = `anon-${Math.random().toString(36).substring(2, 15)}`; // Replace with clerk/auth ID when authentication is wired up

    // Ensure user exists in DB for foreign keys
    await prisma.user.upsert({
      where: { clerkId: userId },
      update: {},
      create: { clerkId: userId },
    });


    if (!itemId || !name || !price) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Convert decimal price (e.g. 9.99) to cents (999)
    const unitAmount = Math.round(parseFloat(price) * 100);

    const stripe = getStripe();
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: name,
              description: `NexusCut Add-on: ${name}`,
              // You can add an image array here if you want the product image to show in checkout
            },
            unit_amount: unitAmount,
          },
          quantity: 1,
        },
      ],
      mode: 'payment', // One-time payment, not subscription
      payment_intent_data: {
        statement_descriptor: 'NEXUSCUT', // Must be 22 chars max and contain no special characters like < > \ ' " *
      },
      success_url: `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/marketplace/success?session_id={CHECKOUT_SESSION_ID}&item_id=${itemId}`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/marketplace`,
      client_reference_id: userId,
      metadata: { itemId }
    });

    return NextResponse.json({ url: session.url });
  } catch (error: any) {
    console.error('Stripe addon checkout error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
