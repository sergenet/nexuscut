import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import prisma from '@/lib/prisma';

const getStripe = () => {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error('STRIPE_SECRET_KEY is not configured in the environment variables');
  }
  return new Stripe(process.env.STRIPE_SECRET_KEY as string, {
    apiVersion: '2026-06-24.dahlia',
  });
};

// Since we are running locally, we can bypass webhook signature verification or use a secret if provided.
// For Phase 4, we'll just check the event type for simplicity or verify if STRIPE_WEBHOOK_SECRET is available.

export async function POST(req: Request) {
  try {
    const body = await req.text();
    const sig = req.headers.get('stripe-signature') as string;
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    let event;

    if (webhookSecret) {
      const stripe = getStripe();
      try {
        event = stripe.webhooks.constructEvent(body, sig, webhookSecret);
      } catch (err: any) {
        console.error(`Webhook Error: ${err.message}`);
        return NextResponse.json({ error: `Webhook Error: ${err.message}` }, { status: 400 });
      }
    } else {
      event = JSON.parse(body);
    }

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object as Stripe.Checkout.Session;
      const clerkId = session.client_reference_id;
      const stripeCustomerId = typeof session.customer === 'string' ? session.customer : session.customer?.id;
      const tier = session.metadata?.tier || 'pro';
      const affiliateCode = session.metadata?.affiliate_code;

      const itemId = session.metadata?.itemId;
      const customerEmail = session.customer_details?.email || session.customer_email;

      if (clerkId) {
        let user;

        if (customerEmail) {
          // Look for an existing user with this email
          user = await prisma.user.findUnique({
            where: { email: customerEmail }
          });

          if (user) {
            // Check if they are purchasing on a new browser session
            if (user.clerkId !== clerkId) {
              // We could optionally update the clerkId to instantly grant access to this browser
              // But doing so might "log out" their other browser. For a guest session app, it's usually fine
              // to just bind the session to the new browser.
              user = await prisma.user.update({
                where: { id: user.id },
                data: { 
                  clerkId: clerkId,
                  ...(stripeCustomerId && { stripeCustomerId })
                }
              });
            }
          } else {
            // Look for existing user with this clerkId (the current browser session)
            user = await prisma.user.findUnique({
              where: { clerkId }
            });

            if (user) {
              // Add the email to their existing guest account
              user = await prisma.user.update({
                where: { id: user.id },
                data: { 
                  email: customerEmail,
                  ...(stripeCustomerId && { stripeCustomerId })
                }
              });
            } else {
              // Create brand new user
              user = await prisma.user.create({
                data: { 
                  clerkId, 
                  email: customerEmail,
                  ...(stripeCustomerId && { stripeCustomerId })
                }
              });
            }
          }
        } else {
          // Fallback if Stripe didn't capture email
          user = await prisma.user.upsert({
            where: { clerkId },
            update: { ...(stripeCustomerId && { stripeCustomerId }) },
            create: { clerkId, ...(stripeCustomerId && { stripeCustomerId }) }
          });
        }

        if (itemId) {
          // This is a marketplace item purchase
          const amountPaid = session.amount_total ? session.amount_total / 100 : 0;
          await prisma.purchase.upsert({
            where: {
              userId_itemId: {
                userId: user.id,
                itemId: itemId
              }
            },
            update: { amount: amountPaid },
            create: {
              userId: user.id,
              itemId: itemId,
              amount: amountPaid
            }
          });
        } else {
          // This is a subscription purchase
          await prisma.user.update({
            where: { clerkId },
            data: { 
              isPro: true,
              planTier: tier,
              ...(affiliateCode && { referredByCode: affiliateCode })
            },
          });
        }

        if (affiliateCode) {
          const affiliate = await prisma.affiliate.findUnique({
            where: { affiliateCode }
          });

          if (affiliate) {
            // Check if referral already exists to prevent duplicates for this user
            const existingReferral = await prisma.referral.findUnique({
              where: { referredUserId: user.id }
            });

            if (!existingReferral) {
              const amountPaid = session.amount_total ? session.amount_total / 100 : 0;
              const commissionAmount = amountPaid * affiliate.commissionRate;

              await prisma.referral.create({
                data: {
                  affiliateId: affiliate.id,
                  referredUserId: user.id,
                  amount: commissionAmount,
                  status: 'pending' // Will remain pending until threshold check in a cron or admin dashboard
                }
              });
            }
          }
        }
      }
    } else if (event.type === 'customer.subscription.deleted') {
      const subscription = event.data.object as Stripe.Subscription;
      const stripeCustomerId = typeof subscription.customer === 'string' ? subscription.customer : subscription.customer?.id;

      if (stripeCustomerId) {
        const user = await prisma.user.findFirst({
          where: { stripeCustomerId }
        });

        if (user) {
          await prisma.user.update({
            where: { id: user.id },
            data: { isPro: false, planTier: 'free' }
          });

          // Mark any pending referrals as cancelled
          await prisma.referral.updateMany({
            where: { referredUserId: user.id, status: 'pending' },
            data: { status: 'cancelled', cancelledAt: new Date() }
          });
        }
      }
    }

    return NextResponse.json({ received: true });
  } catch (err: any) {
    console.error('Webhook payload parsing error:', err);
    return NextResponse.json({ error: 'Webhook payload error' }, { status: 400 });
  }
}
