import { NextResponse } from 'next/server';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { exec } from 'child_process';
import util from 'util';

const execPromise = util.promisify(exec);

export async function POST(req: Request) {
  console.log('[EXPORT V2] Received export request');
  try {
    const formData = await req.formData() as any;
    
    let ffmpegCommand = formData.get('ffmpegCommand') as string;
    const blobMapStr = formData.get('blobMap') as string;
    
    if (!ffmpegCommand || !blobMapStr) {
      return NextResponse.json({ error: 'Missing ffmpegCommand or blobMap' }, { status: 400 });
    }

    const blobMap = JSON.parse(blobMapStr); // Record<string, string> mapping blob URL to fileKey
    const tempDir = os.tmpdir();
    const id = Date.now().toString();
    const outputPath = path.join(tempDir, `output_${id}.mp4`);
    const writtenFiles: string[] = []; // Track files for cleanup
    
    // Save all uploaded files to disk and replace their blob URLs in the command string
    for (const [blobUrl, fileKey] of Object.entries(blobMap)) {
      const file = formData.get(fileKey as string) as File | null;
      if (file) {
        const ext = file.name.split('.').pop()?.toLowerCase() || 'mp4';
        const safeExt = ['mp4', 'mov', 'webm', 'mp3', 'wav', 'aac', 'm4a'].includes(ext) ? ext : 'mp4';
        const localPath = path.join(tempDir, `${fileKey}_${id}.${safeExt}`);
        
        const buffer = Buffer.from(await file.arrayBuffer());
        fs.writeFileSync(localPath, buffer);
        writtenFiles.push(localPath); // Track for cleanup
        
        ffmpegCommand = ffmpegCommand.split(blobUrl).join(localPath);
        console.log(`[EXPORT V2] Saved ${fileKey} to ${localPath}`);
      }
    }

    const finalCommand = `ffmpeg ${ffmpegCommand} -threads 1 -preset ultrafast -max_muxing_queue_size 1024 -y "${outputPath}"`;
    
    console.log(`[EXPORT V2] Executing: ${finalCommand}`);
    
    try {
      await execPromise(finalCommand);
    } catch (ffmpegError: any) {
      console.error('[EXPORT V2] FFmpeg Error:', ffmpegError);
      // Clean up inputs on error
      writtenFiles.forEach(f => { if(fs.existsSync(f)) fs.unlinkSync(f); });
      return NextResponse.json({ error: 'FFmpeg execution failed', details: ffmpegError.message }, { status: 500 });
    }

    if (!fs.existsSync(outputPath)) {
      writtenFiles.forEach(f => { if(fs.existsSync(f)) fs.unlinkSync(f); });
      return NextResponse.json({ error: 'Output file was not generated' }, { status: 500 });
    }

    const videoBuffer = fs.readFileSync(outputPath);
    
    // Cleanup temporary files
    try {
      if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
      writtenFiles.forEach(f => { if(fs.existsSync(f)) fs.unlinkSync(f); });
    } catch (e) {
      console.warn('[EXPORT V2] Cleanup warning:', e);
    }

    return new NextResponse(videoBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'video/mp4',
        'Content-Disposition': `attachment; filename="nexuscut_export_${id}.mp4"`
      }
    });

  } catch (error: any) {
    console.error('[EXPORT V2] Fatal Error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
