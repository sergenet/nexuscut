import React from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { Check } from 'lucide-react';

export const metadata = {
  title: 'Pricing - NexusCut',
  description: 'Simple pricing. Powerful results. Choose the plan that fits your creator journey.',
};

const plans = [
  {
    name: 'Free',
    price: '$0',
    description: 'Perfect for new creators',
    features: [
      'Web Video Editor Access',
      'Standard Auto-Captions',
      '720p Exports',
      '10 Exports / Month (Watermarked)',
    ],
    cta: 'Start Free',
    href: '/editor',
    popular: false,
  },
  {
    name: 'Pro',
    price: '$12',
    period: '/mo',
    description: 'For consistent content creators',
    features: [
      'Everything in Free',
      'No Watermarks',
      'Unlimited 1080p Exports',
      'AI Background Removal Tool',
      'AI Audio Studio & Voiceovers',
    ],
    cta: 'Upgrade to Pro',
    href: '/api/stripe/checkout?plan=pro',
    popular: true,
  },
  {
    name: 'Creator+',
    price: '$29',
    period: '/mo',
    description: 'For creators who want growth',
    features: [
      'Everything in Pro',
      'Viral Hook Generator Tool',
      'Subtitle Style Generator Tool',
      'AI Image & Animation Generators',
      '4K Ultra HD Exports',
    ],
    cta: 'Get Creator+',
    href: '/api/stripe/checkout?plan=creator',
    popular: false,
  }
];

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col font-sans">
      <Navigation />
      
      <main className="flex-grow pt-32 pb-24 px-4 max-w-7xl mx-auto w-full">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-extrabold mb-6 tracking-tight">
            Simple pricing. <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-500">Powerful results.</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Start free. Upgrade when you're ready to scale. No complex timelines, no steep learning curve.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, idx) => (
            <div 
              key={idx} 
              className={`relative bg-gray-900 border rounded-3xl p-8 flex flex-col transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl ${
                plan.popular 
                  ? 'border-indigo-500 shadow-[0_0_40px_rgba(99,102,241,0.2)] scale-105 z-10' 
                  : 'border-gray-700 hover:border-gray-500 hover:shadow-white/5'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white text-sm font-bold py-1.5 px-6 rounded-full shadow-lg">
                  Most Popular
                </div>
              )}
              <h3 className="text-2xl font-bold mb-2 text-white">{plan.name}</h3>
              <p className="text-gray-400 mb-6 text-sm min-h-[40px] leading-relaxed">{plan.description}</p>
              
              <div className="mb-6 flex items-baseline">
                <span className="text-5xl font-extrabold text-white tracking-tight">{plan.price}</span>
                {plan.period && <span className="text-gray-400 font-medium ml-1">{plan.period}</span>}
              </div>

              <a 
                href={plan.href} 
                className={`w-full py-4 rounded-xl font-bold text-center transition-all duration-300 mb-8 flex items-center justify-center gap-2 ${
                  plan.popular 
                    ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/40 hover:scale-105' 
                    : 'bg-gray-800 hover:bg-white text-gray-300 hover:text-black border border-gray-700 hover:border-white shadow-lg hover:scale-105'
                }`}
              >
                {plan.cta}
              </a>

              <div className="flex-grow">
                <ul className="space-y-4">
                  {plan.features.map((feature, fIdx) => (
                    <li key={fIdx} className="flex items-start text-sm">
                      <div className={`mt-0.5 shrink-0 mr-3 rounded-full p-1 ${plan.popular ? 'bg-indigo-500/20 text-indigo-400' : 'bg-gray-800 text-gray-400'}`}>
                        <Check className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-gray-300 leading-snug">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-24 text-center">
          <h2 className="text-3xl font-bold mb-8">Frequently Asked Questions</h2>
          <div className="max-w-3xl mx-auto text-left space-y-4">
            <details className="group bg-gray-900 border border-gray-800 rounded-lg p-6 open:border-indigo-500 transition-colors cursor-pointer">
              <summary className="font-bold text-lg marker:content-none flex justify-between items-center outline-none">
                How does the free plan work?
                <span className="text-indigo-400 group-open:rotate-180 transition-transform">▼</span>
              </summary>
              <p className="text-gray-400 text-sm mt-4">You can export up to 10 videos per month at 720p. All free exports include a small NexusCut watermark to help support our platform.</p>
            </details>
            <details className="group bg-gray-900 border border-gray-800 rounded-lg p-6 open:border-indigo-500 transition-colors cursor-pointer">
              <summary className="font-bold text-lg marker:content-none flex justify-between items-center outline-none">
                Can I cancel anytime?
                <span className="text-indigo-400 group-open:rotate-180 transition-transform">▼</span>
              </summary>
              <p className="text-gray-400 text-sm mt-4">Absolutely. There are no contracts or hidden fees. You can cancel your subscription from your dashboard at any time.</p>
            </details>
            <details className="group bg-gray-900 border border-gray-800 rounded-lg p-6 open:border-indigo-500 transition-colors cursor-pointer">
              <summary className="font-bold text-lg marker:content-none flex justify-between items-center outline-none">
                Do you support team accounts?
                <span className="text-indigo-400 group-open:rotate-180 transition-transform">▼</span>
              </summary>
              <p className="text-gray-400 text-sm mt-4">Yes! Our Agency plan includes up to 10 seats, shared libraries, and client folders for seamless collaboration.</p>
            </details>
            <details className="group bg-gray-900 border border-gray-800 rounded-lg p-6 open:border-indigo-500 transition-colors cursor-pointer">
              <summary className="font-bold text-lg marker:content-none flex justify-between items-center outline-none">
                Do you offer discounts?
                <span className="text-indigo-400 group-open:rotate-180 transition-transform">▼</span>
              </summary>
              <p className="text-gray-400 text-sm mt-4">We occasionally offer promotional discounts. Join our newsletter to stay updated. We also offer a 7-day refund policy if you aren't satisfied.</p>
            </details>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
