
import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Free Instagram Reels Editor | AI Video Editing | NexusCut',
  description: 'Grow your Instagram with high-retention Reels. Our free AI Reels editor adds captions and trendy effects instantly.',
  openGraph: {
    title: 'Free Instagram Reels Editor | AI Video Editing | NexusCut',
    description: 'Grow your Instagram with high-retention Reels. Our free AI Reels editor adds captions and trendy effects instantly.',
    type: 'website',
  }
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
