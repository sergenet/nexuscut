import prisma from '@/lib/prisma';
import { NextRequest } from 'next/server';

export async function checkGuestLimit(req: NextRequest | Request, maxLimit: number = 3): Promise<{ allowed: boolean, error?: string }> {
  try {
    let ip = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown';

    // Clean up IP if it's a list (x-forwarded-for can be a comma-separated list)
    if (ip.includes(',')) {
      ip = ip.split(',')[0].trim();
    }

    const fingerprint = req.headers.get('x-device-fingerprint') || 'unknown';

    // Check IP
    if (ip !== 'unknown' && ip !== '127.0.0.1' && ip !== '::1') {
      const ipUsage = await prisma.guestUsage.upsert({
        where: { identifier: `IP:${ip}` },
        update: {},
        create: { identifier: `IP:${ip}`, type: 'IP' }
      });

      if (ipUsage.usageCount >= maxLimit) {
        return { allowed: false, error: 'IP address usage limit reached.' };
      }
    }

    // Check Fingerprint
    if (fingerprint !== 'unknown') {
      const fpUsage = await prisma.guestUsage.upsert({
        where: { identifier: `FP:${fingerprint}` },
        update: {},
        create: { identifier: `FP:${fingerprint}`, type: 'FINGERPRINT' }
      });

      if (fpUsage.usageCount >= maxLimit) {
        return { allowed: false, error: 'Device usage limit reached.' };
      }
    }

    return { allowed: true };
  } catch (err) {
    console.error("Rate limit check failed:", err);
    // If DB fails, fail open to not break the app for everyone
    return { allowed: true };
  }
}

export async function incrementGuestUsage(req: NextRequest | Request) {
  try {
    let ip = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown';

    if (ip.includes(',')) {
      ip = ip.split(',')[0].trim();
    }
    
    const fingerprint = req.headers.get('x-device-fingerprint') || 'unknown';

    if (ip !== 'unknown' && ip !== '127.0.0.1' && ip !== '::1') {
      await prisma.guestUsage.update({
        where: { identifier: `IP:${ip}` },
        data: { usageCount: { increment: 1 }, lastUsedAt: new Date() }
      });
    }

    if (fingerprint !== 'unknown') {
      await prisma.guestUsage.update({
        where: { identifier: `FP:${fingerprint}` },
        data: { usageCount: { increment: 1 }, lastUsedAt: new Date() }
      });
    }
  } catch (err) {
    console.error("Failed to increment usage:", err);
  }
}
