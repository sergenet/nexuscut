export interface MarketplaceItem {
  id: string;
  name: string;
  description: string;
  type: 'caption_style' | 'background_pack' | 'effect' | 'subscription';
  price: number;
  previewUrl: string;
  features: string[];
}

export const marketplaceCatalog: MarketplaceItem[] = [
  {
    id: 'cap-hormozi',
    name: 'The Hormozi',
    description: 'Bold, dynamic yellow text with a heavy black stroke and punchy pop-in animations. Perfect for high-energy motivational shorts.',
    type: 'caption_style',
    price: 9.99,
    previewUrl: '/marketplace/hormozi.jpg',
    features: ['Bold Impact Font', 'Yellow & White Highlights', 'Pop-in Animation', 'Heavy Drop Shadow']
  },
  {
    id: 'cap-abdaal',
    name: 'The Abdaal',
    description: 'Clean, minimalist typography with subtle slide animations and soft highlights. Ideal for educational and productivity content.',
    type: 'caption_style',
    price: 9.99,
    previewUrl: '/marketplace/abdaal.jpg',
    features: ['Minimalist Font', 'Soft Color Palette', 'Smooth Slide Animations', 'Professional Look']
  },
  {
    id: 'bg-gta',
    name: 'Viral Gameplay (GTA)',
    description: 'A collection of 50+ high-quality GTA V racing and stunt clips to use as satisfying split-screen backgrounds.',
    type: 'background_pack',
    price: 4.99,
    previewUrl: '/marketplace/gta.jpg',
    features: ['50+ Seamless Loops', '1080p 60fps', 'Highly Engaging', 'Commercial Use Allowed']
  },
  {
    id: 'bg-asmr',
    name: 'ASMR Satisfying',
    description: 'Kinetic sand, soap cutting, and satisfying loop footage designed to retain viewer attention in the second half of the screen.',
    type: 'background_pack',
    price: 4.99,
    previewUrl: '/marketplace/asmr.jpg',
    features: ['30+ Relaxing Clips', '1080p 60fps', 'Attention Retaining', 'Commercial Use Allowed']
  },
  {
    id: 'addon-growth-mode',
    name: 'Growth Mode (Beta)',
    description: 'Auto-detect viral moments, generate hooks, and optimize pacing for maximum retention. Post and watch the views come in.',
    type: 'subscription',
    price: 19.99,
    previewUrl: '/marketplace/growth.jpg',
    features: ['Auto-Detect Viral Moments', 'AI Hook Generation', 'Pacing Optimization', 'Algorithm Formatting']
  }
];
