import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export default function proxy(request: NextRequest) {
  const response = NextResponse.next();
  
  // Check for session cookie
  const sessionCookie = request.cookies.get('nexus_session_id');
  
  if (!sessionCookie) {
    // Generate a unique session ID
    const sessionId = crypto.randomUUID();
    
    // Set cookie on the response so it's sent to the client
    response.cookies.set({
      name: 'nexus_session_id',
      value: sessionId,
      httpOnly: true, // secure against XSS
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24 * 365, // 1 year
    });
  }

  return response;
}

export const config = {
  matcher: [
    // Apply to all routes except static files, images, etc. and /api/export
    '/((?!_next/static|_next/image|favicon.ico|api/export|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};
